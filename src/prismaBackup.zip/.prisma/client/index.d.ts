
/**
 * Client
**/

import * as runtime from '@prisma/client/runtime/index';
declare const prisma: unique symbol
export type PrismaPromise<A> = Promise<A> & {[prisma]: true}
type UnwrapPromise<P extends any> = P extends Promise<infer R> ? R : P
type UnwrapTuple<Tuple extends readonly unknown[]> = {
  [K in keyof Tuple]: K extends `${number}` ? Tuple[K] extends PrismaPromise<infer X> ? X : UnwrapPromise<Tuple[K]> : UnwrapPromise<Tuple[K]>
};


/**
 * Model answers
 * 
 */
export type answers = {
  id: string
  churchId: string | null
  formSubmissionId: string | null
  questionId: string | null
  value: string | null
}

/**
 * Model formSubmissions
 * 
 */
export type formSubmissions = {
  id: string
  churchId: string | null
  formId: string | null
  contentType: string | null
  contentId: string | null
  submissionDate: Date | null
  submittedBy: string | null
  revisionDate: Date | null
  revisedBy: string | null
}

/**
 * Model forms
 * 
 */
export type forms = {
  id: string
  churchId: string | null
  name: string | null
  contentType: string | null
  createdTime: Date | null
  modifiedTime: Date | null
  removed: boolean | null
}

/**
 * Model groupMembers
 * 
 */
export type groupMembers = {
  id: string
  churchId: string | null
  groupId: string | null
  personId: string | null
  joinDate: Date | null
}

/**
 * Model groups
 * 
 */
export type groups = {
  id: string
  churchId: string | null
  categoryName: string | null
  name: string | null
  trackAttendance: boolean | null
  parentPickup: boolean | null
  removed: boolean | null
}

/**
 * Model households
 * 
 */
export type households = {
  id: string
  churchId: string | null
  name: string | null
}

/**
 * Model notes
 * 
 */
export type notes = {
  id: string
  churchId: string | null
  contentType: string | null
  contentId: string | null
  noteType: string | null
  addedBy: string | null
  createdAt: Date | null
  updatedAt: Date | null
  contents: string | null
}

/**
 * Model people
 * 
 */
export type people = {
  id: string
  churchId: string | null
  displayName: string | null
  firstName: string | null
  middleName: string | null
  lastName: string | null
  nickName: string | null
  prefix: string | null
  suffix: string | null
  birthDate: Date | null
  gender: string | null
  maritalStatus: string | null
  anniversary: Date | null
  membershipStatus: string | null
  homePhone: string | null
  mobilePhone: string | null
  workPhone: string | null
  email: string | null
  address1: string | null
  address2: string | null
  city: string | null
  state: string | null
  zip: string | null
  photoUpdated: Date | null
  householdId: string | null
  householdRole: string | null
  removed: boolean | null
}

/**
 * Model questions
 * 
 */
export type questions = {
  id: string
  churchId: string | null
  formId: string | null
  parentId: string | null
  title: string | null
  description: string | null
  fieldType: string | null
  placeholder: string | null
  sort: string | null
  choices: string | null
  removed: boolean | null
}

/**
 * Model customers
 * 
 */
export type customers = {
  id: string
  churchId: string | null
  personId: string | null
}

/**
 * Model donationBatches
 * 
 */
export type donationBatches = {
  id: string
  churchId: string | null
  name: string | null
  batchDate: Date | null
}

/**
 * Model donations
 * 
 */
export type donations = {
  id: string
  churchId: string | null
  batchId: string | null
  personId: string | null
  donationDate: Date | null
  amount: number | null
  method: string | null
  methodDetails: string | null
  notes: string | null
}

/**
 * Model eventLogs
 * 
 */
export type eventLogs = {
  id: string
  churchId: string | null
  customerId: string | null
  provider: string | null
  status: string | null
  eventType: string | null
  message: string | null
  created: Date | null
  resolved: boolean | null
}

/**
 * Model fundDonations
 * 
 */
export type fundDonations = {
  id: string
  churchId: string | null
  donationId: string | null
  fundId: string | null
  amount: number | null
}

/**
 * Model funds
 * 
 */
export type funds = {
  id: string
  churchId: string | null
  name: string | null
  productId: string | null
  removed: boolean | null
}

/**
 * Model gateways
 * 
 */
export type gateways = {
  id: string
  churchId: string | null
  provider: string | null
  publicKey: string | null
  privateKey: string | null
  webhookKey: string | null
  productId: string | null
}

/**
 * Model subscriptionFunds
 * 
 */
export type subscriptionFunds = {
  id: string
  churchId: string
  subscriptionId: string | null
  fundId: string | null
  amount: number | null
}

/**
 * Model subscriptions
 * 
 */
export type subscriptions = {
  id: string
  churchId: string | null
  personId: string | null
  customerId: string | null
}

/**
 * Model campuses
 * 
 */
export type campuses = {
  id: string
  churchId: string | null
  name: string | null
  address1: string | null
  address2: string | null
  city: string | null
  state: string | null
  zip: string | null
  removed: boolean | null
}

/**
 * Model groupServiceTimes
 * 
 */
export type groupServiceTimes = {
  id: string
  churchId: string | null
  groupId: string | null
  serviceTimeId: string | null
}

/**
 * Model serviceTimes
 * 
 */
export type serviceTimes = {
  id: string
  churchId: string | null
  serviceId: string | null
  name: string | null
  removed: boolean | null
}

/**
 * Model services
 * 
 */
export type services = {
  id: string
  churchId: string | null
  campusId: string | null
  name: string | null
  removed: boolean | null
}

/**
 * Model sessions
 * 
 */
export type sessions = {
  id: string
  churchId: string | null
  groupId: string | null
  serviceTimeId: string | null
  sessionDate: Date | null
}

/**
 * Model visitSessions
 * 
 */
export type visitSessions = {
  id: string
  churchId: string | null
  visitId: string | null
  sessionId: string | null
}

/**
 * Model visits
 * 
 */
export type visits = {
  id: string
  churchId: string | null
  personId: string | null
  serviceId: string | null
  groupId: string | null
  visitDate: Date | null
  checkinTime: Date | null
  addedBy: string | null
}


/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Answers
 * const answers = await prisma.answers.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  T extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof T ? T['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<T['log']> : never : never,
  GlobalReject = 'rejectOnNotFound' extends keyof T
    ? T['rejectOnNotFound']
    : false
      > {
      /**
       * @private
       */
      private fetcher;
      /**
       * @private
       */
      private readonly dmmf;
      /**
       * @private
       */
      private connectionPromise?;
      /**
       * @private
       */
      private disconnectionPromise?;
      /**
       * @private
       */
      private readonly engineConfig;
      /**
       * @private
       */
      private readonly measurePerformance;

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Answers
   * const answers = await prisma.answers.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<T, Prisma.PrismaClientOptions>);
  $on<V extends (U | 'beforeExit')>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : V extends 'beforeExit' ? () => Promise<void> : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): Promise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): Promise<void>;

  /**
   * Add a middleware
   */
  $use(cb: Prisma.Middleware): void

  /**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): PrismaPromise<T>;

  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends PrismaPromise<any>[]>(arg: [...P]): Promise<UnwrapTuple<P>>;


      /**
   * `prisma.answers`: Exposes CRUD operations for the **answers** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Answers
    * const answers = await prisma.answers.findMany()
    * ```
    */
  get answers(): Prisma.answersDelegate<GlobalReject>;

  /**
   * `prisma.formSubmissions`: Exposes CRUD operations for the **formSubmissions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more FormSubmissions
    * const formSubmissions = await prisma.formSubmissions.findMany()
    * ```
    */
  get formSubmissions(): Prisma.formSubmissionsDelegate<GlobalReject>;

  /**
   * `prisma.forms`: Exposes CRUD operations for the **forms** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Forms
    * const forms = await prisma.forms.findMany()
    * ```
    */
  get forms(): Prisma.formsDelegate<GlobalReject>;

  /**
   * `prisma.groupMembers`: Exposes CRUD operations for the **groupMembers** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more GroupMembers
    * const groupMembers = await prisma.groupMembers.findMany()
    * ```
    */
  get groupMembers(): Prisma.groupMembersDelegate<GlobalReject>;

  /**
   * `prisma.groups`: Exposes CRUD operations for the **groups** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Groups
    * const groups = await prisma.groups.findMany()
    * ```
    */
  get groups(): Prisma.groupsDelegate<GlobalReject>;

  /**
   * `prisma.households`: Exposes CRUD operations for the **households** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Households
    * const households = await prisma.households.findMany()
    * ```
    */
  get households(): Prisma.householdsDelegate<GlobalReject>;

  /**
   * `prisma.notes`: Exposes CRUD operations for the **notes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Notes
    * const notes = await prisma.notes.findMany()
    * ```
    */
  get notes(): Prisma.notesDelegate<GlobalReject>;

  /**
   * `prisma.people`: Exposes CRUD operations for the **people** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more People
    * const people = await prisma.people.findMany()
    * ```
    */
  get people(): Prisma.peopleDelegate<GlobalReject>;

  /**
   * `prisma.questions`: Exposes CRUD operations for the **questions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Questions
    * const questions = await prisma.questions.findMany()
    * ```
    */
  get questions(): Prisma.questionsDelegate<GlobalReject>;

  /**
   * `prisma.customers`: Exposes CRUD operations for the **customers** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Customers
    * const customers = await prisma.customers.findMany()
    * ```
    */
  get customers(): Prisma.customersDelegate<GlobalReject>;

  /**
   * `prisma.donationBatches`: Exposes CRUD operations for the **donationBatches** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more DonationBatches
    * const donationBatches = await prisma.donationBatches.findMany()
    * ```
    */
  get donationBatches(): Prisma.donationBatchesDelegate<GlobalReject>;

  /**
   * `prisma.donations`: Exposes CRUD operations for the **donations** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Donations
    * const donations = await prisma.donations.findMany()
    * ```
    */
  get donations(): Prisma.donationsDelegate<GlobalReject>;

  /**
   * `prisma.eventLogs`: Exposes CRUD operations for the **eventLogs** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more EventLogs
    * const eventLogs = await prisma.eventLogs.findMany()
    * ```
    */
  get eventLogs(): Prisma.eventLogsDelegate<GlobalReject>;

  /**
   * `prisma.fundDonations`: Exposes CRUD operations for the **fundDonations** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more FundDonations
    * const fundDonations = await prisma.fundDonations.findMany()
    * ```
    */
  get fundDonations(): Prisma.fundDonationsDelegate<GlobalReject>;

  /**
   * `prisma.funds`: Exposes CRUD operations for the **funds** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Funds
    * const funds = await prisma.funds.findMany()
    * ```
    */
  get funds(): Prisma.fundsDelegate<GlobalReject>;

  /**
   * `prisma.gateways`: Exposes CRUD operations for the **gateways** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Gateways
    * const gateways = await prisma.gateways.findMany()
    * ```
    */
  get gateways(): Prisma.gatewaysDelegate<GlobalReject>;

  /**
   * `prisma.subscriptionFunds`: Exposes CRUD operations for the **subscriptionFunds** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SubscriptionFunds
    * const subscriptionFunds = await prisma.subscriptionFunds.findMany()
    * ```
    */
  get subscriptionFunds(): Prisma.subscriptionFundsDelegate<GlobalReject>;

  /**
   * `prisma.subscriptions`: Exposes CRUD operations for the **subscriptions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Subscriptions
    * const subscriptions = await prisma.subscriptions.findMany()
    * ```
    */
  get subscriptions(): Prisma.subscriptionsDelegate<GlobalReject>;

  /**
   * `prisma.campuses`: Exposes CRUD operations for the **campuses** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Campuses
    * const campuses = await prisma.campuses.findMany()
    * ```
    */
  get campuses(): Prisma.campusesDelegate<GlobalReject>;

  /**
   * `prisma.groupServiceTimes`: Exposes CRUD operations for the **groupServiceTimes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more GroupServiceTimes
    * const groupServiceTimes = await prisma.groupServiceTimes.findMany()
    * ```
    */
  get groupServiceTimes(): Prisma.groupServiceTimesDelegate<GlobalReject>;

  /**
   * `prisma.serviceTimes`: Exposes CRUD operations for the **serviceTimes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ServiceTimes
    * const serviceTimes = await prisma.serviceTimes.findMany()
    * ```
    */
  get serviceTimes(): Prisma.serviceTimesDelegate<GlobalReject>;

  /**
   * `prisma.services`: Exposes CRUD operations for the **services** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Services
    * const services = await prisma.services.findMany()
    * ```
    */
  get services(): Prisma.servicesDelegate<GlobalReject>;

  /**
   * `prisma.sessions`: Exposes CRUD operations for the **sessions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Sessions
    * const sessions = await prisma.sessions.findMany()
    * ```
    */
  get sessions(): Prisma.sessionsDelegate<GlobalReject>;

  /**
   * `prisma.visitSessions`: Exposes CRUD operations for the **visitSessions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VisitSessions
    * const visitSessions = await prisma.visitSessions.findMany()
    * ```
    */
  get visitSessions(): Prisma.visitSessionsDelegate<GlobalReject>;

  /**
   * `prisma.visits`: Exposes CRUD operations for the **visits** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Visits
    * const visits = await prisma.visits.findMany()
    * ```
    */
  get visits(): Prisma.visitsDelegate<GlobalReject>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql

  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  /**
   * Prisma Client JS version: 3.8.1
   * Query Engine version: 34df67547cf5598f5a6cd3eb45f14ee70c3fb86f
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON object.
   * This type can be useful to enforce some input to be JSON-compatible or as a super-type to be extended from. 
   */
  export type JsonObject = {[Key in string]?: JsonValue}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON array.
   */
  export interface JsonArray extends Array<JsonValue> {}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches any valid JSON value.
   */
  export type JsonValue = string | number | boolean | JsonObject | JsonArray | null

  /**
   * Matches a JSON object.
   * Unlike `JsonObject`, this type allows undefined and read-only properties.
   */
  export type InputJsonObject = {readonly [Key in string]?: InputJsonValue | null}

  /**
   * Matches a JSON array.
   * Unlike `JsonArray`, readonly arrays are assignable to this type.
   */
  export interface InputJsonArray extends ReadonlyArray<InputJsonValue | null> {}

  /**
   * Matches any valid value that can be used as an input for operations like
   * create and update as the value of a JSON field. Unlike `JsonValue`, this
   * type allows read-only arrays and read-only object properties and disallows
   * `null` at the top level.
   *
   * `null` cannot be used as the value of a JSON field because its meaning
   * would be ambiguous. Use `Prisma.JsonNull` to store the JSON null value or
   * `Prisma.DbNull` to clear the JSON value and set the field to the database
   * NULL value instead.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-by-null-values
   */
  export type InputJsonValue = string | number | boolean | InputJsonObject | InputJsonArray

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: 'DbNull'

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: 'JsonNull'

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: 'AnyNull'

  type SelectAndInclude = {
    select: any
    include: any
  }
  type HasSelect = {
    select: any
  }
  type HasInclude = {
    include: any
  }
  type CheckSelect<T, S, U> = T extends SelectAndInclude
    ? 'Please either choose `select` or `include`'
    : T extends HasSelect
    ? U
    : T extends HasInclude
    ? U
    : S

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => Promise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = {
    [key in keyof T]: T[key] extends false | undefined | null ? never : key
  }[keyof T]

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> = (T | U) extends object ? (Without<T, U> & U) | (Without<U, T> & T) : T | U;


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Buffer
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Exact<A, W = unknown> = 
  W extends unknown ? A extends Narrowable ? Cast<A, W> : Cast<
  {[K in keyof A]: K extends keyof W ? Exact<A[K], W[K]> : never},
  {[K in keyof W]: K extends keyof A ? Exact<A[K], W[K]> : W[K]}>
  : never;

  type Narrowable = string | number | boolean | bigint;

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;

  export function validator<V>(): <S>(select: Exact<S, V>) => S;

  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but with an array
   */
  type PickArray<T, K extends Array<keyof T>> = Prisma__Pick<T, TupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T

  class PrismaClientFetcher {
    private readonly prisma;
    private readonly debug;
    private readonly hooks?;
    constructor(prisma: PrismaClient<any, any>, debug?: boolean, hooks?: Hooks | undefined);
    request<T>(document: any, dataPath?: string[], rootField?: string, typeName?: string, isList?: boolean, callsite?: string): Promise<T>;
    sanitizeMessage(message: string): string;
    protected unpack(document: any, data: any, path: string[], rootField?: string, isList?: boolean): any;
  }

  export const ModelName: {
    answers: 'answers',
    formSubmissions: 'formSubmissions',
    forms: 'forms',
    groupMembers: 'groupMembers',
    groups: 'groups',
    households: 'households',
    notes: 'notes',
    people: 'people',
    questions: 'questions',
    customers: 'customers',
    donationBatches: 'donationBatches',
    donations: 'donations',
    eventLogs: 'eventLogs',
    fundDonations: 'fundDonations',
    funds: 'funds',
    gateways: 'gateways',
    subscriptionFunds: 'subscriptionFunds',
    subscriptions: 'subscriptions',
    campuses: 'campuses',
    groupServiceTimes: 'groupServiceTimes',
    serviceTimes: 'serviceTimes',
    services: 'services',
    sessions: 'sessions',
    visitSessions: 'visitSessions',
    visits: 'visits'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  export type RejectOnNotFound = boolean | ((error: Error) => Error)
  export type RejectPerModel = { [P in ModelName]?: RejectOnNotFound }
  export type RejectPerOperation =  { [P in "findUnique" | "findFirst"]?: RejectPerModel | RejectOnNotFound } 
  type IsReject<T> = T extends true ? True : T extends (err: Error) => Error ? True : False
  export type HasReject<
    GlobalRejectSettings extends Prisma.PrismaClientOptions['rejectOnNotFound'],
    LocalRejectSettings,
    Action extends PrismaAction,
    Model extends ModelName
  > = LocalRejectSettings extends RejectOnNotFound
    ? IsReject<LocalRejectSettings>
    : GlobalRejectSettings extends RejectPerOperation
    ? Action extends keyof GlobalRejectSettings
      ? GlobalRejectSettings[Action] extends boolean
        ? IsReject<GlobalRejectSettings[Action]>
        : GlobalRejectSettings[Action] extends RejectPerModel
        ? Model extends keyof GlobalRejectSettings[Action]
          ? IsReject<GlobalRejectSettings[Action][Model]>
          : False
        : False
      : False
    : IsReject<GlobalRejectSettings>
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'

  export interface PrismaClientOptions {
    /**
     * Configure findUnique/findFirst to throw an error if the query returns null. 
     *  * @example
     * ```
     * // Reject on both findUnique/findFirst
     * rejectOnNotFound: true
     * // Reject only on findFirst with a custom error
     * rejectOnNotFound: { findFirst: (err) => new Error("Custom Error")}
     * // Reject on user.findUnique with a custom error
     * rejectOnNotFound: { findUnique: {User: (err) => new Error("User not found")}}
     * ```
     */
    rejectOnNotFound?: RejectOnNotFound | RejectPerOperation
    /**
     * Overwrites the datasource url from your prisma.schema file
     */
    datasources?: Datasources

    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat

    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: Array<LogLevel | LogDefinition>
  }

  export type Hooks = {
    beforeRequest?: (options: { query: string, path: string[], rootField?: string, typeName?: string, document: any }) => any
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findMany'
    | 'findFirst'
    | 'create'
    | 'createMany'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'

  /**
   * These options are being passed in to the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => Promise<T>,
  ) => Promise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined; 
  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type GroupsCountOutputType
   */


  export type GroupsCountOutputType = {
    users: number
  }

  export type GroupsCountOutputTypeSelect = {
    users?: boolean
  }

  export type GroupsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | GroupsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? GroupsCountOutputType
    : S extends undefined
    ? never
    : S extends GroupsCountOutputTypeArgs
    ?'include' extends U
    ? GroupsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof GroupsCountOutputType ?GroupsCountOutputType [P]
  : 
     never
  } 
    : GroupsCountOutputType
  : GroupsCountOutputType




  // Custom InputTypes

  /**
   * GroupsCountOutputType without action
   */
  export type GroupsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the GroupsCountOutputType
     * 
    **/
    select?: GroupsCountOutputTypeSelect | null
  }



  /**
   * Count Type HouseholdsCountOutputType
   */


  export type HouseholdsCountOutputType = {
    people: number
  }

  export type HouseholdsCountOutputTypeSelect = {
    people?: boolean
  }

  export type HouseholdsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | HouseholdsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? HouseholdsCountOutputType
    : S extends undefined
    ? never
    : S extends HouseholdsCountOutputTypeArgs
    ?'include' extends U
    ? HouseholdsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof HouseholdsCountOutputType ?HouseholdsCountOutputType [P]
  : 
     never
  } 
    : HouseholdsCountOutputType
  : HouseholdsCountOutputType




  // Custom InputTypes

  /**
   * HouseholdsCountOutputType without action
   */
  export type HouseholdsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the HouseholdsCountOutputType
     * 
    **/
    select?: HouseholdsCountOutputTypeSelect | null
  }



  /**
   * Count Type PeopleCountOutputType
   */


  export type PeopleCountOutputType = {
    groups: number
  }

  export type PeopleCountOutputTypeSelect = {
    groups?: boolean
  }

  export type PeopleCountOutputTypeGetPayload<
    S extends boolean | null | undefined | PeopleCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? PeopleCountOutputType
    : S extends undefined
    ? never
    : S extends PeopleCountOutputTypeArgs
    ?'include' extends U
    ? PeopleCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof PeopleCountOutputType ?PeopleCountOutputType [P]
  : 
     never
  } 
    : PeopleCountOutputType
  : PeopleCountOutputType




  // Custom InputTypes

  /**
   * PeopleCountOutputType without action
   */
  export type PeopleCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the PeopleCountOutputType
     * 
    **/
    select?: PeopleCountOutputTypeSelect | null
  }



  /**
   * Count Type DonationBatchesCountOutputType
   */


  export type DonationBatchesCountOutputType = {
    donations: number
  }

  export type DonationBatchesCountOutputTypeSelect = {
    donations?: boolean
  }

  export type DonationBatchesCountOutputTypeGetPayload<
    S extends boolean | null | undefined | DonationBatchesCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? DonationBatchesCountOutputType
    : S extends undefined
    ? never
    : S extends DonationBatchesCountOutputTypeArgs
    ?'include' extends U
    ? DonationBatchesCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof DonationBatchesCountOutputType ?DonationBatchesCountOutputType [P]
  : 
     never
  } 
    : DonationBatchesCountOutputType
  : DonationBatchesCountOutputType




  // Custom InputTypes

  /**
   * DonationBatchesCountOutputType without action
   */
  export type DonationBatchesCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the DonationBatchesCountOutputType
     * 
    **/
    select?: DonationBatchesCountOutputTypeSelect | null
  }



  /**
   * Count Type DonationsCountOutputType
   */


  export type DonationsCountOutputType = {
    fundDonations: number
  }

  export type DonationsCountOutputTypeSelect = {
    fundDonations?: boolean
  }

  export type DonationsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | DonationsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? DonationsCountOutputType
    : S extends undefined
    ? never
    : S extends DonationsCountOutputTypeArgs
    ?'include' extends U
    ? DonationsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof DonationsCountOutputType ?DonationsCountOutputType [P]
  : 
     never
  } 
    : DonationsCountOutputType
  : DonationsCountOutputType




  // Custom InputTypes

  /**
   * DonationsCountOutputType without action
   */
  export type DonationsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the DonationsCountOutputType
     * 
    **/
    select?: DonationsCountOutputTypeSelect | null
  }



  /**
   * Count Type FundsCountOutputType
   */


  export type FundsCountOutputType = {
    fundDonations: number
  }

  export type FundsCountOutputTypeSelect = {
    fundDonations?: boolean
  }

  export type FundsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | FundsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? FundsCountOutputType
    : S extends undefined
    ? never
    : S extends FundsCountOutputTypeArgs
    ?'include' extends U
    ? FundsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof FundsCountOutputType ?FundsCountOutputType [P]
  : 
     never
  } 
    : FundsCountOutputType
  : FundsCountOutputType




  // Custom InputTypes

  /**
   * FundsCountOutputType without action
   */
  export type FundsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the FundsCountOutputType
     * 
    **/
    select?: FundsCountOutputTypeSelect | null
  }



  /**
   * Count Type SessionsCountOutputType
   */


  export type SessionsCountOutputType = {
    visits: number
  }

  export type SessionsCountOutputTypeSelect = {
    visits?: boolean
  }

  export type SessionsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | SessionsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? SessionsCountOutputType
    : S extends undefined
    ? never
    : S extends SessionsCountOutputTypeArgs
    ?'include' extends U
    ? SessionsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof SessionsCountOutputType ?SessionsCountOutputType [P]
  : 
     never
  } 
    : SessionsCountOutputType
  : SessionsCountOutputType




  // Custom InputTypes

  /**
   * SessionsCountOutputType without action
   */
  export type SessionsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the SessionsCountOutputType
     * 
    **/
    select?: SessionsCountOutputTypeSelect | null
  }



  /**
   * Count Type VisitsCountOutputType
   */


  export type VisitsCountOutputType = {
    session: number
  }

  export type VisitsCountOutputTypeSelect = {
    session?: boolean
  }

  export type VisitsCountOutputTypeGetPayload<
    S extends boolean | null | undefined | VisitsCountOutputTypeArgs,
    U = keyof S
      > = S extends true
        ? VisitsCountOutputType
    : S extends undefined
    ? never
    : S extends VisitsCountOutputTypeArgs
    ?'include' extends U
    ? VisitsCountOutputType 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof VisitsCountOutputType ?VisitsCountOutputType [P]
  : 
     never
  } 
    : VisitsCountOutputType
  : VisitsCountOutputType




  // Custom InputTypes

  /**
   * VisitsCountOutputType without action
   */
  export type VisitsCountOutputTypeArgs = {
    /**
     * Select specific fields to fetch from the VisitsCountOutputType
     * 
    **/
    select?: VisitsCountOutputTypeSelect | null
  }



  /**
   * Models
   */

  /**
   * Model answers
   */


  export type AggregateAnswers = {
    _count: AnswersCountAggregateOutputType | null
    _min: AnswersMinAggregateOutputType | null
    _max: AnswersMaxAggregateOutputType | null
  }

  export type AnswersMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    formSubmissionId: string | null
    questionId: string | null
    value: string | null
  }

  export type AnswersMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    formSubmissionId: string | null
    questionId: string | null
    value: string | null
  }

  export type AnswersCountAggregateOutputType = {
    id: number
    churchId: number
    formSubmissionId: number
    questionId: number
    value: number
    _all: number
  }


  export type AnswersMinAggregateInputType = {
    id?: true
    churchId?: true
    formSubmissionId?: true
    questionId?: true
    value?: true
  }

  export type AnswersMaxAggregateInputType = {
    id?: true
    churchId?: true
    formSubmissionId?: true
    questionId?: true
    value?: true
  }

  export type AnswersCountAggregateInputType = {
    id?: true
    churchId?: true
    formSubmissionId?: true
    questionId?: true
    value?: true
    _all?: true
  }

  export type AnswersAggregateArgs = {
    /**
     * Filter which answers to aggregate.
     * 
    **/
    where?: answersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of answers to fetch.
     * 
    **/
    orderBy?: Enumerable<answersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: answersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` answers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` answers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned answers
    **/
    _count?: true | AnswersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AnswersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AnswersMaxAggregateInputType
  }

  export type GetAnswersAggregateType<T extends AnswersAggregateArgs> = {
        [P in keyof T & keyof AggregateAnswers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAnswers[P]>
      : GetScalarType<T[P], AggregateAnswers[P]>
  }




  export type AnswersGroupByArgs = {
    where?: answersWhereInput
    orderBy?: Enumerable<answersOrderByWithAggregationInput>
    by: Array<AnswersScalarFieldEnum>
    having?: answersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AnswersCountAggregateInputType | true
    _min?: AnswersMinAggregateInputType
    _max?: AnswersMaxAggregateInputType
  }


  export type AnswersGroupByOutputType = {
    id: string
    churchId: string | null
    formSubmissionId: string | null
    questionId: string | null
    value: string | null
    _count: AnswersCountAggregateOutputType | null
    _min: AnswersMinAggregateOutputType | null
    _max: AnswersMaxAggregateOutputType | null
  }

  type GetAnswersGroupByPayload<T extends AnswersGroupByArgs> = Promise<
    Array<
      PickArray<AnswersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AnswersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AnswersGroupByOutputType[P]>
            : GetScalarType<T[P], AnswersGroupByOutputType[P]>
        }
      >
    >


  export type answersSelect = {
    id?: boolean
    churchId?: boolean
    formSubmissionId?: boolean
    questionId?: boolean
    value?: boolean
  }

  export type answersGetPayload<
    S extends boolean | null | undefined | answersArgs,
    U = keyof S
      > = S extends true
        ? answers
    : S extends undefined
    ? never
    : S extends answersArgs | answersFindManyArgs
    ?'include' extends U
    ? answers 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof answers ?answers [P]
  : 
     never
  } 
    : answers
  : answers


  type answersCountArgs = Merge<
    Omit<answersFindManyArgs, 'select' | 'include'> & {
      select?: AnswersCountAggregateInputType | true
    }
  >

  export interface answersDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Answers that matches the filter.
     * @param {answersFindUniqueArgs} args - Arguments to find a Answers
     * @example
     * // Get one Answers
     * const answers = await prisma.answers.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends answersFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, answersFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'answers'> extends True ? CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>> : CheckSelect<T, Prisma__answersClient<answers | null >, Prisma__answersClient<answersGetPayload<T> | null >>

    /**
     * Find the first Answers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {answersFindFirstArgs} args - Arguments to find a Answers
     * @example
     * // Get one Answers
     * const answers = await prisma.answers.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends answersFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, answersFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'answers'> extends True ? CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>> : CheckSelect<T, Prisma__answersClient<answers | null >, Prisma__answersClient<answersGetPayload<T> | null >>

    /**
     * Find zero or more Answers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {answersFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Answers
     * const answers = await prisma.answers.findMany()
     * 
     * // Get first 10 Answers
     * const answers = await prisma.answers.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const answersWithIdOnly = await prisma.answers.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends answersFindManyArgs>(
      args?: SelectSubset<T, answersFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<answers>>, PrismaPromise<Array<answersGetPayload<T>>>>

    /**
     * Create a Answers.
     * @param {answersCreateArgs} args - Arguments to create a Answers.
     * @example
     * // Create one Answers
     * const Answers = await prisma.answers.create({
     *   data: {
     *     // ... data to create a Answers
     *   }
     * })
     * 
    **/
    create<T extends answersCreateArgs>(
      args: SelectSubset<T, answersCreateArgs>
    ): CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>>

    /**
     * Create many Answers.
     *     @param {answersCreateManyArgs} args - Arguments to create many Answers.
     *     @example
     *     // Create many Answers
     *     const answers = await prisma.answers.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends answersCreateManyArgs>(
      args?: SelectSubset<T, answersCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Answers.
     * @param {answersDeleteArgs} args - Arguments to delete one Answers.
     * @example
     * // Delete one Answers
     * const Answers = await prisma.answers.delete({
     *   where: {
     *     // ... filter to delete one Answers
     *   }
     * })
     * 
    **/
    delete<T extends answersDeleteArgs>(
      args: SelectSubset<T, answersDeleteArgs>
    ): CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>>

    /**
     * Update one Answers.
     * @param {answersUpdateArgs} args - Arguments to update one Answers.
     * @example
     * // Update one Answers
     * const answers = await prisma.answers.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends answersUpdateArgs>(
      args: SelectSubset<T, answersUpdateArgs>
    ): CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>>

    /**
     * Delete zero or more Answers.
     * @param {answersDeleteManyArgs} args - Arguments to filter Answers to delete.
     * @example
     * // Delete a few Answers
     * const { count } = await prisma.answers.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends answersDeleteManyArgs>(
      args?: SelectSubset<T, answersDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Answers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {answersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Answers
     * const answers = await prisma.answers.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends answersUpdateManyArgs>(
      args: SelectSubset<T, answersUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Answers.
     * @param {answersUpsertArgs} args - Arguments to update or create a Answers.
     * @example
     * // Update or create a Answers
     * const answers = await prisma.answers.upsert({
     *   create: {
     *     // ... data to create a Answers
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Answers we want to update
     *   }
     * })
    **/
    upsert<T extends answersUpsertArgs>(
      args: SelectSubset<T, answersUpsertArgs>
    ): CheckSelect<T, Prisma__answersClient<answers>, Prisma__answersClient<answersGetPayload<T>>>

    /**
     * Count the number of Answers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {answersCountArgs} args - Arguments to filter Answers to count.
     * @example
     * // Count the number of Answers
     * const count = await prisma.answers.count({
     *   where: {
     *     // ... the filter for the Answers we want to count
     *   }
     * })
    **/
    count<T extends answersCountArgs>(
      args?: Subset<T, answersCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AnswersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Answers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnswersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AnswersAggregateArgs>(args: Subset<T, AnswersAggregateArgs>): PrismaPromise<GetAnswersAggregateType<T>>

    /**
     * Group by Answers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AnswersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AnswersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AnswersGroupByArgs['orderBy'] }
        : { orderBy?: AnswersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AnswersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAnswersGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for answers.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__answersClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * answers findUnique
   */
  export type answersFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * Throw an Error if a answers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which answers to fetch.
     * 
    **/
    where: answersWhereUniqueInput
  }


  /**
   * answers findFirst
   */
  export type answersFindFirstArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * Throw an Error if a answers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which answers to fetch.
     * 
    **/
    where?: answersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of answers to fetch.
     * 
    **/
    orderBy?: Enumerable<answersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for answers.
     * 
    **/
    cursor?: answersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` answers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` answers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of answers.
     * 
    **/
    distinct?: Enumerable<AnswersScalarFieldEnum>
  }


  /**
   * answers findMany
   */
  export type answersFindManyArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * Filter, which answers to fetch.
     * 
    **/
    where?: answersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of answers to fetch.
     * 
    **/
    orderBy?: Enumerable<answersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing answers.
     * 
    **/
    cursor?: answersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` answers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` answers.
     * 
    **/
    skip?: number
    distinct?: Enumerable<AnswersScalarFieldEnum>
  }


  /**
   * answers create
   */
  export type answersCreateArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * The data needed to create a answers.
     * 
    **/
    data: XOR<answersCreateInput, answersUncheckedCreateInput>
  }


  /**
   * answers createMany
   */
  export type answersCreateManyArgs = {
    data: Enumerable<answersCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * answers update
   */
  export type answersUpdateArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * The data needed to update a answers.
     * 
    **/
    data: XOR<answersUpdateInput, answersUncheckedUpdateInput>
    /**
     * Choose, which answers to update.
     * 
    **/
    where: answersWhereUniqueInput
  }


  /**
   * answers updateMany
   */
  export type answersUpdateManyArgs = {
    data: XOR<answersUpdateManyMutationInput, answersUncheckedUpdateManyInput>
    where?: answersWhereInput
  }


  /**
   * answers upsert
   */
  export type answersUpsertArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * The filter to search for the answers to update in case it exists.
     * 
    **/
    where: answersWhereUniqueInput
    /**
     * In case the answers found by the `where` argument doesn't exist, create a new answers with this data.
     * 
    **/
    create: XOR<answersCreateInput, answersUncheckedCreateInput>
    /**
     * In case the answers was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<answersUpdateInput, answersUncheckedUpdateInput>
  }


  /**
   * answers delete
   */
  export type answersDeleteArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
    /**
     * Filter which answers to delete.
     * 
    **/
    where: answersWhereUniqueInput
  }


  /**
   * answers deleteMany
   */
  export type answersDeleteManyArgs = {
    where?: answersWhereInput
  }


  /**
   * answers without action
   */
  export type answersArgs = {
    /**
     * Select specific fields to fetch from the answers
     * 
    **/
    select?: answersSelect | null
  }



  /**
   * Model formSubmissions
   */


  export type AggregateFormSubmissions = {
    _count: FormSubmissionsCountAggregateOutputType | null
    _min: FormSubmissionsMinAggregateOutputType | null
    _max: FormSubmissionsMaxAggregateOutputType | null
  }

  export type FormSubmissionsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    formId: string | null
    contentType: string | null
    contentId: string | null
    submissionDate: Date | null
    submittedBy: string | null
    revisionDate: Date | null
    revisedBy: string | null
  }

  export type FormSubmissionsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    formId: string | null
    contentType: string | null
    contentId: string | null
    submissionDate: Date | null
    submittedBy: string | null
    revisionDate: Date | null
    revisedBy: string | null
  }

  export type FormSubmissionsCountAggregateOutputType = {
    id: number
    churchId: number
    formId: number
    contentType: number
    contentId: number
    submissionDate: number
    submittedBy: number
    revisionDate: number
    revisedBy: number
    _all: number
  }


  export type FormSubmissionsMinAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    contentType?: true
    contentId?: true
    submissionDate?: true
    submittedBy?: true
    revisionDate?: true
    revisedBy?: true
  }

  export type FormSubmissionsMaxAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    contentType?: true
    contentId?: true
    submissionDate?: true
    submittedBy?: true
    revisionDate?: true
    revisedBy?: true
  }

  export type FormSubmissionsCountAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    contentType?: true
    contentId?: true
    submissionDate?: true
    submittedBy?: true
    revisionDate?: true
    revisedBy?: true
    _all?: true
  }

  export type FormSubmissionsAggregateArgs = {
    /**
     * Filter which formSubmissions to aggregate.
     * 
    **/
    where?: formSubmissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of formSubmissions to fetch.
     * 
    **/
    orderBy?: Enumerable<formSubmissionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: formSubmissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` formSubmissions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` formSubmissions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned formSubmissions
    **/
    _count?: true | FormSubmissionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FormSubmissionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FormSubmissionsMaxAggregateInputType
  }

  export type GetFormSubmissionsAggregateType<T extends FormSubmissionsAggregateArgs> = {
        [P in keyof T & keyof AggregateFormSubmissions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFormSubmissions[P]>
      : GetScalarType<T[P], AggregateFormSubmissions[P]>
  }




  export type FormSubmissionsGroupByArgs = {
    where?: formSubmissionsWhereInput
    orderBy?: Enumerable<formSubmissionsOrderByWithAggregationInput>
    by: Array<FormSubmissionsScalarFieldEnum>
    having?: formSubmissionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FormSubmissionsCountAggregateInputType | true
    _min?: FormSubmissionsMinAggregateInputType
    _max?: FormSubmissionsMaxAggregateInputType
  }


  export type FormSubmissionsGroupByOutputType = {
    id: string
    churchId: string | null
    formId: string | null
    contentType: string | null
    contentId: string | null
    submissionDate: Date | null
    submittedBy: string | null
    revisionDate: Date | null
    revisedBy: string | null
    _count: FormSubmissionsCountAggregateOutputType | null
    _min: FormSubmissionsMinAggregateOutputType | null
    _max: FormSubmissionsMaxAggregateOutputType | null
  }

  type GetFormSubmissionsGroupByPayload<T extends FormSubmissionsGroupByArgs> = Promise<
    Array<
      PickArray<FormSubmissionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FormSubmissionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FormSubmissionsGroupByOutputType[P]>
            : GetScalarType<T[P], FormSubmissionsGroupByOutputType[P]>
        }
      >
    >


  export type formSubmissionsSelect = {
    id?: boolean
    churchId?: boolean
    formId?: boolean
    contentType?: boolean
    contentId?: boolean
    submissionDate?: boolean
    submittedBy?: boolean
    revisionDate?: boolean
    revisedBy?: boolean
  }

  export type formSubmissionsGetPayload<
    S extends boolean | null | undefined | formSubmissionsArgs,
    U = keyof S
      > = S extends true
        ? formSubmissions
    : S extends undefined
    ? never
    : S extends formSubmissionsArgs | formSubmissionsFindManyArgs
    ?'include' extends U
    ? formSubmissions 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof formSubmissions ?formSubmissions [P]
  : 
     never
  } 
    : formSubmissions
  : formSubmissions


  type formSubmissionsCountArgs = Merge<
    Omit<formSubmissionsFindManyArgs, 'select' | 'include'> & {
      select?: FormSubmissionsCountAggregateInputType | true
    }
  >

  export interface formSubmissionsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one FormSubmissions that matches the filter.
     * @param {formSubmissionsFindUniqueArgs} args - Arguments to find a FormSubmissions
     * @example
     * // Get one FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends formSubmissionsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, formSubmissionsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'formSubmissions'> extends True ? CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>> : CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions | null >, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T> | null >>

    /**
     * Find the first FormSubmissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formSubmissionsFindFirstArgs} args - Arguments to find a FormSubmissions
     * @example
     * // Get one FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends formSubmissionsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, formSubmissionsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'formSubmissions'> extends True ? CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>> : CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions | null >, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T> | null >>

    /**
     * Find zero or more FormSubmissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formSubmissionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.findMany()
     * 
     * // Get first 10 FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const formSubmissionsWithIdOnly = await prisma.formSubmissions.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends formSubmissionsFindManyArgs>(
      args?: SelectSubset<T, formSubmissionsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<formSubmissions>>, PrismaPromise<Array<formSubmissionsGetPayload<T>>>>

    /**
     * Create a FormSubmissions.
     * @param {formSubmissionsCreateArgs} args - Arguments to create a FormSubmissions.
     * @example
     * // Create one FormSubmissions
     * const FormSubmissions = await prisma.formSubmissions.create({
     *   data: {
     *     // ... data to create a FormSubmissions
     *   }
     * })
     * 
    **/
    create<T extends formSubmissionsCreateArgs>(
      args: SelectSubset<T, formSubmissionsCreateArgs>
    ): CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>>

    /**
     * Create many FormSubmissions.
     *     @param {formSubmissionsCreateManyArgs} args - Arguments to create many FormSubmissions.
     *     @example
     *     // Create many FormSubmissions
     *     const formSubmissions = await prisma.formSubmissions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends formSubmissionsCreateManyArgs>(
      args?: SelectSubset<T, formSubmissionsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a FormSubmissions.
     * @param {formSubmissionsDeleteArgs} args - Arguments to delete one FormSubmissions.
     * @example
     * // Delete one FormSubmissions
     * const FormSubmissions = await prisma.formSubmissions.delete({
     *   where: {
     *     // ... filter to delete one FormSubmissions
     *   }
     * })
     * 
    **/
    delete<T extends formSubmissionsDeleteArgs>(
      args: SelectSubset<T, formSubmissionsDeleteArgs>
    ): CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>>

    /**
     * Update one FormSubmissions.
     * @param {formSubmissionsUpdateArgs} args - Arguments to update one FormSubmissions.
     * @example
     * // Update one FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends formSubmissionsUpdateArgs>(
      args: SelectSubset<T, formSubmissionsUpdateArgs>
    ): CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>>

    /**
     * Delete zero or more FormSubmissions.
     * @param {formSubmissionsDeleteManyArgs} args - Arguments to filter FormSubmissions to delete.
     * @example
     * // Delete a few FormSubmissions
     * const { count } = await prisma.formSubmissions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends formSubmissionsDeleteManyArgs>(
      args?: SelectSubset<T, formSubmissionsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more FormSubmissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formSubmissionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends formSubmissionsUpdateManyArgs>(
      args: SelectSubset<T, formSubmissionsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one FormSubmissions.
     * @param {formSubmissionsUpsertArgs} args - Arguments to update or create a FormSubmissions.
     * @example
     * // Update or create a FormSubmissions
     * const formSubmissions = await prisma.formSubmissions.upsert({
     *   create: {
     *     // ... data to create a FormSubmissions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the FormSubmissions we want to update
     *   }
     * })
    **/
    upsert<T extends formSubmissionsUpsertArgs>(
      args: SelectSubset<T, formSubmissionsUpsertArgs>
    ): CheckSelect<T, Prisma__formSubmissionsClient<formSubmissions>, Prisma__formSubmissionsClient<formSubmissionsGetPayload<T>>>

    /**
     * Count the number of FormSubmissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formSubmissionsCountArgs} args - Arguments to filter FormSubmissions to count.
     * @example
     * // Count the number of FormSubmissions
     * const count = await prisma.formSubmissions.count({
     *   where: {
     *     // ... the filter for the FormSubmissions we want to count
     *   }
     * })
    **/
    count<T extends formSubmissionsCountArgs>(
      args?: Subset<T, formSubmissionsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FormSubmissionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a FormSubmissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FormSubmissionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FormSubmissionsAggregateArgs>(args: Subset<T, FormSubmissionsAggregateArgs>): PrismaPromise<GetFormSubmissionsAggregateType<T>>

    /**
     * Group by FormSubmissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FormSubmissionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FormSubmissionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FormSubmissionsGroupByArgs['orderBy'] }
        : { orderBy?: FormSubmissionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FormSubmissionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFormSubmissionsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for formSubmissions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__formSubmissionsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * formSubmissions findUnique
   */
  export type formSubmissionsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * Throw an Error if a formSubmissions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which formSubmissions to fetch.
     * 
    **/
    where: formSubmissionsWhereUniqueInput
  }


  /**
   * formSubmissions findFirst
   */
  export type formSubmissionsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * Throw an Error if a formSubmissions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which formSubmissions to fetch.
     * 
    **/
    where?: formSubmissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of formSubmissions to fetch.
     * 
    **/
    orderBy?: Enumerable<formSubmissionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for formSubmissions.
     * 
    **/
    cursor?: formSubmissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` formSubmissions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` formSubmissions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of formSubmissions.
     * 
    **/
    distinct?: Enumerable<FormSubmissionsScalarFieldEnum>
  }


  /**
   * formSubmissions findMany
   */
  export type formSubmissionsFindManyArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * Filter, which formSubmissions to fetch.
     * 
    **/
    where?: formSubmissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of formSubmissions to fetch.
     * 
    **/
    orderBy?: Enumerable<formSubmissionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing formSubmissions.
     * 
    **/
    cursor?: formSubmissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` formSubmissions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` formSubmissions.
     * 
    **/
    skip?: number
    distinct?: Enumerable<FormSubmissionsScalarFieldEnum>
  }


  /**
   * formSubmissions create
   */
  export type formSubmissionsCreateArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * The data needed to create a formSubmissions.
     * 
    **/
    data: XOR<formSubmissionsCreateInput, formSubmissionsUncheckedCreateInput>
  }


  /**
   * formSubmissions createMany
   */
  export type formSubmissionsCreateManyArgs = {
    data: Enumerable<formSubmissionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * formSubmissions update
   */
  export type formSubmissionsUpdateArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * The data needed to update a formSubmissions.
     * 
    **/
    data: XOR<formSubmissionsUpdateInput, formSubmissionsUncheckedUpdateInput>
    /**
     * Choose, which formSubmissions to update.
     * 
    **/
    where: formSubmissionsWhereUniqueInput
  }


  /**
   * formSubmissions updateMany
   */
  export type formSubmissionsUpdateManyArgs = {
    data: XOR<formSubmissionsUpdateManyMutationInput, formSubmissionsUncheckedUpdateManyInput>
    where?: formSubmissionsWhereInput
  }


  /**
   * formSubmissions upsert
   */
  export type formSubmissionsUpsertArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * The filter to search for the formSubmissions to update in case it exists.
     * 
    **/
    where: formSubmissionsWhereUniqueInput
    /**
     * In case the formSubmissions found by the `where` argument doesn't exist, create a new formSubmissions with this data.
     * 
    **/
    create: XOR<formSubmissionsCreateInput, formSubmissionsUncheckedCreateInput>
    /**
     * In case the formSubmissions was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<formSubmissionsUpdateInput, formSubmissionsUncheckedUpdateInput>
  }


  /**
   * formSubmissions delete
   */
  export type formSubmissionsDeleteArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
    /**
     * Filter which formSubmissions to delete.
     * 
    **/
    where: formSubmissionsWhereUniqueInput
  }


  /**
   * formSubmissions deleteMany
   */
  export type formSubmissionsDeleteManyArgs = {
    where?: formSubmissionsWhereInput
  }


  /**
   * formSubmissions without action
   */
  export type formSubmissionsArgs = {
    /**
     * Select specific fields to fetch from the formSubmissions
     * 
    **/
    select?: formSubmissionsSelect | null
  }



  /**
   * Model forms
   */


  export type AggregateForms = {
    _count: FormsCountAggregateOutputType | null
    _min: FormsMinAggregateOutputType | null
    _max: FormsMaxAggregateOutputType | null
  }

  export type FormsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    contentType: string | null
    createdTime: Date | null
    modifiedTime: Date | null
    removed: boolean | null
  }

  export type FormsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    contentType: string | null
    createdTime: Date | null
    modifiedTime: Date | null
    removed: boolean | null
  }

  export type FormsCountAggregateOutputType = {
    id: number
    churchId: number
    name: number
    contentType: number
    createdTime: number
    modifiedTime: number
    removed: number
    _all: number
  }


  export type FormsMinAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    contentType?: true
    createdTime?: true
    modifiedTime?: true
    removed?: true
  }

  export type FormsMaxAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    contentType?: true
    createdTime?: true
    modifiedTime?: true
    removed?: true
  }

  export type FormsCountAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    contentType?: true
    createdTime?: true
    modifiedTime?: true
    removed?: true
    _all?: true
  }

  export type FormsAggregateArgs = {
    /**
     * Filter which forms to aggregate.
     * 
    **/
    where?: formsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of forms to fetch.
     * 
    **/
    orderBy?: Enumerable<formsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: formsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` forms from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` forms.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned forms
    **/
    _count?: true | FormsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FormsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FormsMaxAggregateInputType
  }

  export type GetFormsAggregateType<T extends FormsAggregateArgs> = {
        [P in keyof T & keyof AggregateForms]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateForms[P]>
      : GetScalarType<T[P], AggregateForms[P]>
  }




  export type FormsGroupByArgs = {
    where?: formsWhereInput
    orderBy?: Enumerable<formsOrderByWithAggregationInput>
    by: Array<FormsScalarFieldEnum>
    having?: formsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FormsCountAggregateInputType | true
    _min?: FormsMinAggregateInputType
    _max?: FormsMaxAggregateInputType
  }


  export type FormsGroupByOutputType = {
    id: string
    churchId: string | null
    name: string | null
    contentType: string | null
    createdTime: Date | null
    modifiedTime: Date | null
    removed: boolean | null
    _count: FormsCountAggregateOutputType | null
    _min: FormsMinAggregateOutputType | null
    _max: FormsMaxAggregateOutputType | null
  }

  type GetFormsGroupByPayload<T extends FormsGroupByArgs> = Promise<
    Array<
      PickArray<FormsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FormsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FormsGroupByOutputType[P]>
            : GetScalarType<T[P], FormsGroupByOutputType[P]>
        }
      >
    >


  export type formsSelect = {
    id?: boolean
    churchId?: boolean
    name?: boolean
    contentType?: boolean
    createdTime?: boolean
    modifiedTime?: boolean
    removed?: boolean
  }

  export type formsGetPayload<
    S extends boolean | null | undefined | formsArgs,
    U = keyof S
      > = S extends true
        ? forms
    : S extends undefined
    ? never
    : S extends formsArgs | formsFindManyArgs
    ?'include' extends U
    ? forms 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof forms ?forms [P]
  : 
     never
  } 
    : forms
  : forms


  type formsCountArgs = Merge<
    Omit<formsFindManyArgs, 'select' | 'include'> & {
      select?: FormsCountAggregateInputType | true
    }
  >

  export interface formsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Forms that matches the filter.
     * @param {formsFindUniqueArgs} args - Arguments to find a Forms
     * @example
     * // Get one Forms
     * const forms = await prisma.forms.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends formsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, formsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'forms'> extends True ? CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>> : CheckSelect<T, Prisma__formsClient<forms | null >, Prisma__formsClient<formsGetPayload<T> | null >>

    /**
     * Find the first Forms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formsFindFirstArgs} args - Arguments to find a Forms
     * @example
     * // Get one Forms
     * const forms = await prisma.forms.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends formsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, formsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'forms'> extends True ? CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>> : CheckSelect<T, Prisma__formsClient<forms | null >, Prisma__formsClient<formsGetPayload<T> | null >>

    /**
     * Find zero or more Forms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Forms
     * const forms = await prisma.forms.findMany()
     * 
     * // Get first 10 Forms
     * const forms = await prisma.forms.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const formsWithIdOnly = await prisma.forms.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends formsFindManyArgs>(
      args?: SelectSubset<T, formsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<forms>>, PrismaPromise<Array<formsGetPayload<T>>>>

    /**
     * Create a Forms.
     * @param {formsCreateArgs} args - Arguments to create a Forms.
     * @example
     * // Create one Forms
     * const Forms = await prisma.forms.create({
     *   data: {
     *     // ... data to create a Forms
     *   }
     * })
     * 
    **/
    create<T extends formsCreateArgs>(
      args: SelectSubset<T, formsCreateArgs>
    ): CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>>

    /**
     * Create many Forms.
     *     @param {formsCreateManyArgs} args - Arguments to create many Forms.
     *     @example
     *     // Create many Forms
     *     const forms = await prisma.forms.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends formsCreateManyArgs>(
      args?: SelectSubset<T, formsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Forms.
     * @param {formsDeleteArgs} args - Arguments to delete one Forms.
     * @example
     * // Delete one Forms
     * const Forms = await prisma.forms.delete({
     *   where: {
     *     // ... filter to delete one Forms
     *   }
     * })
     * 
    **/
    delete<T extends formsDeleteArgs>(
      args: SelectSubset<T, formsDeleteArgs>
    ): CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>>

    /**
     * Update one Forms.
     * @param {formsUpdateArgs} args - Arguments to update one Forms.
     * @example
     * // Update one Forms
     * const forms = await prisma.forms.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends formsUpdateArgs>(
      args: SelectSubset<T, formsUpdateArgs>
    ): CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>>

    /**
     * Delete zero or more Forms.
     * @param {formsDeleteManyArgs} args - Arguments to filter Forms to delete.
     * @example
     * // Delete a few Forms
     * const { count } = await prisma.forms.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends formsDeleteManyArgs>(
      args?: SelectSubset<T, formsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Forms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Forms
     * const forms = await prisma.forms.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends formsUpdateManyArgs>(
      args: SelectSubset<T, formsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Forms.
     * @param {formsUpsertArgs} args - Arguments to update or create a Forms.
     * @example
     * // Update or create a Forms
     * const forms = await prisma.forms.upsert({
     *   create: {
     *     // ... data to create a Forms
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Forms we want to update
     *   }
     * })
    **/
    upsert<T extends formsUpsertArgs>(
      args: SelectSubset<T, formsUpsertArgs>
    ): CheckSelect<T, Prisma__formsClient<forms>, Prisma__formsClient<formsGetPayload<T>>>

    /**
     * Count the number of Forms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {formsCountArgs} args - Arguments to filter Forms to count.
     * @example
     * // Count the number of Forms
     * const count = await prisma.forms.count({
     *   where: {
     *     // ... the filter for the Forms we want to count
     *   }
     * })
    **/
    count<T extends formsCountArgs>(
      args?: Subset<T, formsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FormsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Forms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FormsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FormsAggregateArgs>(args: Subset<T, FormsAggregateArgs>): PrismaPromise<GetFormsAggregateType<T>>

    /**
     * Group by Forms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FormsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FormsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FormsGroupByArgs['orderBy'] }
        : { orderBy?: FormsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FormsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFormsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for forms.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__formsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * forms findUnique
   */
  export type formsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * Throw an Error if a forms can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which forms to fetch.
     * 
    **/
    where: formsWhereUniqueInput
  }


  /**
   * forms findFirst
   */
  export type formsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * Throw an Error if a forms can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which forms to fetch.
     * 
    **/
    where?: formsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of forms to fetch.
     * 
    **/
    orderBy?: Enumerable<formsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for forms.
     * 
    **/
    cursor?: formsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` forms from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` forms.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of forms.
     * 
    **/
    distinct?: Enumerable<FormsScalarFieldEnum>
  }


  /**
   * forms findMany
   */
  export type formsFindManyArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * Filter, which forms to fetch.
     * 
    **/
    where?: formsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of forms to fetch.
     * 
    **/
    orderBy?: Enumerable<formsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing forms.
     * 
    **/
    cursor?: formsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` forms from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` forms.
     * 
    **/
    skip?: number
    distinct?: Enumerable<FormsScalarFieldEnum>
  }


  /**
   * forms create
   */
  export type formsCreateArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * The data needed to create a forms.
     * 
    **/
    data: XOR<formsCreateInput, formsUncheckedCreateInput>
  }


  /**
   * forms createMany
   */
  export type formsCreateManyArgs = {
    data: Enumerable<formsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * forms update
   */
  export type formsUpdateArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * The data needed to update a forms.
     * 
    **/
    data: XOR<formsUpdateInput, formsUncheckedUpdateInput>
    /**
     * Choose, which forms to update.
     * 
    **/
    where: formsWhereUniqueInput
  }


  /**
   * forms updateMany
   */
  export type formsUpdateManyArgs = {
    data: XOR<formsUpdateManyMutationInput, formsUncheckedUpdateManyInput>
    where?: formsWhereInput
  }


  /**
   * forms upsert
   */
  export type formsUpsertArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * The filter to search for the forms to update in case it exists.
     * 
    **/
    where: formsWhereUniqueInput
    /**
     * In case the forms found by the `where` argument doesn't exist, create a new forms with this data.
     * 
    **/
    create: XOR<formsCreateInput, formsUncheckedCreateInput>
    /**
     * In case the forms was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<formsUpdateInput, formsUncheckedUpdateInput>
  }


  /**
   * forms delete
   */
  export type formsDeleteArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
    /**
     * Filter which forms to delete.
     * 
    **/
    where: formsWhereUniqueInput
  }


  /**
   * forms deleteMany
   */
  export type formsDeleteManyArgs = {
    where?: formsWhereInput
  }


  /**
   * forms without action
   */
  export type formsArgs = {
    /**
     * Select specific fields to fetch from the forms
     * 
    **/
    select?: formsSelect | null
  }



  /**
   * Model groupMembers
   */


  export type AggregateGroupMembers = {
    _count: GroupMembersCountAggregateOutputType | null
    _min: GroupMembersMinAggregateOutputType | null
    _max: GroupMembersMaxAggregateOutputType | null
  }

  export type GroupMembersMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    personId: string | null
    joinDate: Date | null
  }

  export type GroupMembersMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    personId: string | null
    joinDate: Date | null
  }

  export type GroupMembersCountAggregateOutputType = {
    id: number
    churchId: number
    groupId: number
    personId: number
    joinDate: number
    _all: number
  }


  export type GroupMembersMinAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    personId?: true
    joinDate?: true
  }

  export type GroupMembersMaxAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    personId?: true
    joinDate?: true
  }

  export type GroupMembersCountAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    personId?: true
    joinDate?: true
    _all?: true
  }

  export type GroupMembersAggregateArgs = {
    /**
     * Filter which groupMembers to aggregate.
     * 
    **/
    where?: groupMembersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupMembers to fetch.
     * 
    **/
    orderBy?: Enumerable<groupMembersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: groupMembersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupMembers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupMembers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned groupMembers
    **/
    _count?: true | GroupMembersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GroupMembersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GroupMembersMaxAggregateInputType
  }

  export type GetGroupMembersAggregateType<T extends GroupMembersAggregateArgs> = {
        [P in keyof T & keyof AggregateGroupMembers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGroupMembers[P]>
      : GetScalarType<T[P], AggregateGroupMembers[P]>
  }




  export type GroupMembersGroupByArgs = {
    where?: groupMembersWhereInput
    orderBy?: Enumerable<groupMembersOrderByWithAggregationInput>
    by: Array<GroupMembersScalarFieldEnum>
    having?: groupMembersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GroupMembersCountAggregateInputType | true
    _min?: GroupMembersMinAggregateInputType
    _max?: GroupMembersMaxAggregateInputType
  }


  export type GroupMembersGroupByOutputType = {
    id: string
    churchId: string | null
    groupId: string | null
    personId: string | null
    joinDate: Date | null
    _count: GroupMembersCountAggregateOutputType | null
    _min: GroupMembersMinAggregateOutputType | null
    _max: GroupMembersMaxAggregateOutputType | null
  }

  type GetGroupMembersGroupByPayload<T extends GroupMembersGroupByArgs> = Promise<
    Array<
      PickArray<GroupMembersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GroupMembersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GroupMembersGroupByOutputType[P]>
            : GetScalarType<T[P], GroupMembersGroupByOutputType[P]>
        }
      >
    >


  export type groupMembersSelect = {
    id?: boolean
    churchId?: boolean
    groupId?: boolean
    personId?: boolean
    joinDate?: boolean
    group?: boolean | groupsArgs
    person?: boolean | peopleArgs
  }

  export type groupMembersInclude = {
    group?: boolean | groupsArgs
    person?: boolean | peopleArgs
  }

  export type groupMembersGetPayload<
    S extends boolean | null | undefined | groupMembersArgs,
    U = keyof S
      > = S extends true
        ? groupMembers
    : S extends undefined
    ? never
    : S extends groupMembersArgs | groupMembersFindManyArgs
    ?'include' extends U
    ? groupMembers  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'group'
        ? groupsGetPayload<S['include'][P]> | null :
        P extends 'person'
        ? peopleGetPayload<S['include'][P]> | null : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof groupMembers ?groupMembers [P]
  : 
          P extends 'group'
        ? groupsGetPayload<S['select'][P]> | null :
        P extends 'person'
        ? peopleGetPayload<S['select'][P]> | null : never
  } 
    : groupMembers
  : groupMembers


  type groupMembersCountArgs = Merge<
    Omit<groupMembersFindManyArgs, 'select' | 'include'> & {
      select?: GroupMembersCountAggregateInputType | true
    }
  >

  export interface groupMembersDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one GroupMembers that matches the filter.
     * @param {groupMembersFindUniqueArgs} args - Arguments to find a GroupMembers
     * @example
     * // Get one GroupMembers
     * const groupMembers = await prisma.groupMembers.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends groupMembersFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, groupMembersFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'groupMembers'> extends True ? CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>> : CheckSelect<T, Prisma__groupMembersClient<groupMembers | null >, Prisma__groupMembersClient<groupMembersGetPayload<T> | null >>

    /**
     * Find the first GroupMembers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupMembersFindFirstArgs} args - Arguments to find a GroupMembers
     * @example
     * // Get one GroupMembers
     * const groupMembers = await prisma.groupMembers.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends groupMembersFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, groupMembersFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'groupMembers'> extends True ? CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>> : CheckSelect<T, Prisma__groupMembersClient<groupMembers | null >, Prisma__groupMembersClient<groupMembersGetPayload<T> | null >>

    /**
     * Find zero or more GroupMembers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupMembersFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all GroupMembers
     * const groupMembers = await prisma.groupMembers.findMany()
     * 
     * // Get first 10 GroupMembers
     * const groupMembers = await prisma.groupMembers.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const groupMembersWithIdOnly = await prisma.groupMembers.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends groupMembersFindManyArgs>(
      args?: SelectSubset<T, groupMembersFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<groupMembers>>, PrismaPromise<Array<groupMembersGetPayload<T>>>>

    /**
     * Create a GroupMembers.
     * @param {groupMembersCreateArgs} args - Arguments to create a GroupMembers.
     * @example
     * // Create one GroupMembers
     * const GroupMembers = await prisma.groupMembers.create({
     *   data: {
     *     // ... data to create a GroupMembers
     *   }
     * })
     * 
    **/
    create<T extends groupMembersCreateArgs>(
      args: SelectSubset<T, groupMembersCreateArgs>
    ): CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>>

    /**
     * Create many GroupMembers.
     *     @param {groupMembersCreateManyArgs} args - Arguments to create many GroupMembers.
     *     @example
     *     // Create many GroupMembers
     *     const groupMembers = await prisma.groupMembers.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends groupMembersCreateManyArgs>(
      args?: SelectSubset<T, groupMembersCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a GroupMembers.
     * @param {groupMembersDeleteArgs} args - Arguments to delete one GroupMembers.
     * @example
     * // Delete one GroupMembers
     * const GroupMembers = await prisma.groupMembers.delete({
     *   where: {
     *     // ... filter to delete one GroupMembers
     *   }
     * })
     * 
    **/
    delete<T extends groupMembersDeleteArgs>(
      args: SelectSubset<T, groupMembersDeleteArgs>
    ): CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>>

    /**
     * Update one GroupMembers.
     * @param {groupMembersUpdateArgs} args - Arguments to update one GroupMembers.
     * @example
     * // Update one GroupMembers
     * const groupMembers = await prisma.groupMembers.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends groupMembersUpdateArgs>(
      args: SelectSubset<T, groupMembersUpdateArgs>
    ): CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>>

    /**
     * Delete zero or more GroupMembers.
     * @param {groupMembersDeleteManyArgs} args - Arguments to filter GroupMembers to delete.
     * @example
     * // Delete a few GroupMembers
     * const { count } = await prisma.groupMembers.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends groupMembersDeleteManyArgs>(
      args?: SelectSubset<T, groupMembersDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more GroupMembers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupMembersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many GroupMembers
     * const groupMembers = await prisma.groupMembers.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends groupMembersUpdateManyArgs>(
      args: SelectSubset<T, groupMembersUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one GroupMembers.
     * @param {groupMembersUpsertArgs} args - Arguments to update or create a GroupMembers.
     * @example
     * // Update or create a GroupMembers
     * const groupMembers = await prisma.groupMembers.upsert({
     *   create: {
     *     // ... data to create a GroupMembers
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the GroupMembers we want to update
     *   }
     * })
    **/
    upsert<T extends groupMembersUpsertArgs>(
      args: SelectSubset<T, groupMembersUpsertArgs>
    ): CheckSelect<T, Prisma__groupMembersClient<groupMembers>, Prisma__groupMembersClient<groupMembersGetPayload<T>>>

    /**
     * Count the number of GroupMembers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupMembersCountArgs} args - Arguments to filter GroupMembers to count.
     * @example
     * // Count the number of GroupMembers
     * const count = await prisma.groupMembers.count({
     *   where: {
     *     // ... the filter for the GroupMembers we want to count
     *   }
     * })
    **/
    count<T extends groupMembersCountArgs>(
      args?: Subset<T, groupMembersCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GroupMembersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a GroupMembers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupMembersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GroupMembersAggregateArgs>(args: Subset<T, GroupMembersAggregateArgs>): PrismaPromise<GetGroupMembersAggregateType<T>>

    /**
     * Group by GroupMembers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupMembersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GroupMembersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GroupMembersGroupByArgs['orderBy'] }
        : { orderBy?: GroupMembersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GroupMembersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGroupMembersGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for groupMembers.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__groupMembersClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    group<T extends groupsArgs = {}>(args?: Subset<T, groupsArgs>): CheckSelect<T, Prisma__groupsClient<groups | null >, Prisma__groupsClient<groupsGetPayload<T> | null >>;

    person<T extends peopleArgs = {}>(args?: Subset<T, peopleArgs>): CheckSelect<T, Prisma__peopleClient<people | null >, Prisma__peopleClient<peopleGetPayload<T> | null >>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * groupMembers findUnique
   */
  export type groupMembersFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * Throw an Error if a groupMembers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groupMembers to fetch.
     * 
    **/
    where: groupMembersWhereUniqueInput
  }


  /**
   * groupMembers findFirst
   */
  export type groupMembersFindFirstArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * Throw an Error if a groupMembers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groupMembers to fetch.
     * 
    **/
    where?: groupMembersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupMembers to fetch.
     * 
    **/
    orderBy?: Enumerable<groupMembersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for groupMembers.
     * 
    **/
    cursor?: groupMembersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupMembers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupMembers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of groupMembers.
     * 
    **/
    distinct?: Enumerable<GroupMembersScalarFieldEnum>
  }


  /**
   * groupMembers findMany
   */
  export type groupMembersFindManyArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * Filter, which groupMembers to fetch.
     * 
    **/
    where?: groupMembersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupMembers to fetch.
     * 
    **/
    orderBy?: Enumerable<groupMembersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing groupMembers.
     * 
    **/
    cursor?: groupMembersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupMembers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupMembers.
     * 
    **/
    skip?: number
    distinct?: Enumerable<GroupMembersScalarFieldEnum>
  }


  /**
   * groupMembers create
   */
  export type groupMembersCreateArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * The data needed to create a groupMembers.
     * 
    **/
    data: XOR<groupMembersCreateInput, groupMembersUncheckedCreateInput>
  }


  /**
   * groupMembers createMany
   */
  export type groupMembersCreateManyArgs = {
    data: Enumerable<groupMembersCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * groupMembers update
   */
  export type groupMembersUpdateArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * The data needed to update a groupMembers.
     * 
    **/
    data: XOR<groupMembersUpdateInput, groupMembersUncheckedUpdateInput>
    /**
     * Choose, which groupMembers to update.
     * 
    **/
    where: groupMembersWhereUniqueInput
  }


  /**
   * groupMembers updateMany
   */
  export type groupMembersUpdateManyArgs = {
    data: XOR<groupMembersUpdateManyMutationInput, groupMembersUncheckedUpdateManyInput>
    where?: groupMembersWhereInput
  }


  /**
   * groupMembers upsert
   */
  export type groupMembersUpsertArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * The filter to search for the groupMembers to update in case it exists.
     * 
    **/
    where: groupMembersWhereUniqueInput
    /**
     * In case the groupMembers found by the `where` argument doesn't exist, create a new groupMembers with this data.
     * 
    **/
    create: XOR<groupMembersCreateInput, groupMembersUncheckedCreateInput>
    /**
     * In case the groupMembers was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<groupMembersUpdateInput, groupMembersUncheckedUpdateInput>
  }


  /**
   * groupMembers delete
   */
  export type groupMembersDeleteArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
    /**
     * Filter which groupMembers to delete.
     * 
    **/
    where: groupMembersWhereUniqueInput
  }


  /**
   * groupMembers deleteMany
   */
  export type groupMembersDeleteManyArgs = {
    where?: groupMembersWhereInput
  }


  /**
   * groupMembers without action
   */
  export type groupMembersArgs = {
    /**
     * Select specific fields to fetch from the groupMembers
     * 
    **/
    select?: groupMembersSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupMembersInclude | null
  }



  /**
   * Model groups
   */


  export type AggregateGroups = {
    _count: GroupsCountAggregateOutputType | null
    _min: GroupsMinAggregateOutputType | null
    _max: GroupsMaxAggregateOutputType | null
  }

  export type GroupsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    categoryName: string | null
    name: string | null
    trackAttendance: boolean | null
    parentPickup: boolean | null
    removed: boolean | null
  }

  export type GroupsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    categoryName: string | null
    name: string | null
    trackAttendance: boolean | null
    parentPickup: boolean | null
    removed: boolean | null
  }

  export type GroupsCountAggregateOutputType = {
    id: number
    churchId: number
    categoryName: number
    name: number
    trackAttendance: number
    parentPickup: number
    removed: number
    _all: number
  }


  export type GroupsMinAggregateInputType = {
    id?: true
    churchId?: true
    categoryName?: true
    name?: true
    trackAttendance?: true
    parentPickup?: true
    removed?: true
  }

  export type GroupsMaxAggregateInputType = {
    id?: true
    churchId?: true
    categoryName?: true
    name?: true
    trackAttendance?: true
    parentPickup?: true
    removed?: true
  }

  export type GroupsCountAggregateInputType = {
    id?: true
    churchId?: true
    categoryName?: true
    name?: true
    trackAttendance?: true
    parentPickup?: true
    removed?: true
    _all?: true
  }

  export type GroupsAggregateArgs = {
    /**
     * Filter which groups to aggregate.
     * 
    **/
    where?: groupsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groups to fetch.
     * 
    **/
    orderBy?: Enumerable<groupsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: groupsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groups from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groups.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned groups
    **/
    _count?: true | GroupsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GroupsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GroupsMaxAggregateInputType
  }

  export type GetGroupsAggregateType<T extends GroupsAggregateArgs> = {
        [P in keyof T & keyof AggregateGroups]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGroups[P]>
      : GetScalarType<T[P], AggregateGroups[P]>
  }




  export type GroupsGroupByArgs = {
    where?: groupsWhereInput
    orderBy?: Enumerable<groupsOrderByWithAggregationInput>
    by: Array<GroupsScalarFieldEnum>
    having?: groupsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GroupsCountAggregateInputType | true
    _min?: GroupsMinAggregateInputType
    _max?: GroupsMaxAggregateInputType
  }


  export type GroupsGroupByOutputType = {
    id: string
    churchId: string | null
    categoryName: string | null
    name: string | null
    trackAttendance: boolean | null
    parentPickup: boolean | null
    removed: boolean | null
    _count: GroupsCountAggregateOutputType | null
    _min: GroupsMinAggregateOutputType | null
    _max: GroupsMaxAggregateOutputType | null
  }

  type GetGroupsGroupByPayload<T extends GroupsGroupByArgs> = Promise<
    Array<
      PickArray<GroupsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GroupsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GroupsGroupByOutputType[P]>
            : GetScalarType<T[P], GroupsGroupByOutputType[P]>
        }
      >
    >


  export type groupsSelect = {
    id?: boolean
    churchId?: boolean
    categoryName?: boolean
    name?: boolean
    trackAttendance?: boolean
    parentPickup?: boolean
    removed?: boolean
    users?: boolean | groupMembersFindManyArgs
    _count?: boolean | GroupsCountOutputTypeArgs
  }

  export type groupsInclude = {
    users?: boolean | groupMembersFindManyArgs
    _count?: boolean | GroupsCountOutputTypeArgs
  }

  export type groupsGetPayload<
    S extends boolean | null | undefined | groupsArgs,
    U = keyof S
      > = S extends true
        ? groups
    : S extends undefined
    ? never
    : S extends groupsArgs | groupsFindManyArgs
    ?'include' extends U
    ? groups  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'users'
        ? Array < groupMembersGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? GroupsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof groups ?groups [P]
  : 
          P extends 'users'
        ? Array < groupMembersGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? GroupsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : groups
  : groups


  type groupsCountArgs = Merge<
    Omit<groupsFindManyArgs, 'select' | 'include'> & {
      select?: GroupsCountAggregateInputType | true
    }
  >

  export interface groupsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Groups that matches the filter.
     * @param {groupsFindUniqueArgs} args - Arguments to find a Groups
     * @example
     * // Get one Groups
     * const groups = await prisma.groups.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends groupsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, groupsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'groups'> extends True ? CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>> : CheckSelect<T, Prisma__groupsClient<groups | null >, Prisma__groupsClient<groupsGetPayload<T> | null >>

    /**
     * Find the first Groups that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupsFindFirstArgs} args - Arguments to find a Groups
     * @example
     * // Get one Groups
     * const groups = await prisma.groups.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends groupsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, groupsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'groups'> extends True ? CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>> : CheckSelect<T, Prisma__groupsClient<groups | null >, Prisma__groupsClient<groupsGetPayload<T> | null >>

    /**
     * Find zero or more Groups that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Groups
     * const groups = await prisma.groups.findMany()
     * 
     * // Get first 10 Groups
     * const groups = await prisma.groups.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const groupsWithIdOnly = await prisma.groups.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends groupsFindManyArgs>(
      args?: SelectSubset<T, groupsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<groups>>, PrismaPromise<Array<groupsGetPayload<T>>>>

    /**
     * Create a Groups.
     * @param {groupsCreateArgs} args - Arguments to create a Groups.
     * @example
     * // Create one Groups
     * const Groups = await prisma.groups.create({
     *   data: {
     *     // ... data to create a Groups
     *   }
     * })
     * 
    **/
    create<T extends groupsCreateArgs>(
      args: SelectSubset<T, groupsCreateArgs>
    ): CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>>

    /**
     * Create many Groups.
     *     @param {groupsCreateManyArgs} args - Arguments to create many Groups.
     *     @example
     *     // Create many Groups
     *     const groups = await prisma.groups.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends groupsCreateManyArgs>(
      args?: SelectSubset<T, groupsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Groups.
     * @param {groupsDeleteArgs} args - Arguments to delete one Groups.
     * @example
     * // Delete one Groups
     * const Groups = await prisma.groups.delete({
     *   where: {
     *     // ... filter to delete one Groups
     *   }
     * })
     * 
    **/
    delete<T extends groupsDeleteArgs>(
      args: SelectSubset<T, groupsDeleteArgs>
    ): CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>>

    /**
     * Update one Groups.
     * @param {groupsUpdateArgs} args - Arguments to update one Groups.
     * @example
     * // Update one Groups
     * const groups = await prisma.groups.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends groupsUpdateArgs>(
      args: SelectSubset<T, groupsUpdateArgs>
    ): CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>>

    /**
     * Delete zero or more Groups.
     * @param {groupsDeleteManyArgs} args - Arguments to filter Groups to delete.
     * @example
     * // Delete a few Groups
     * const { count } = await prisma.groups.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends groupsDeleteManyArgs>(
      args?: SelectSubset<T, groupsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Groups
     * const groups = await prisma.groups.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends groupsUpdateManyArgs>(
      args: SelectSubset<T, groupsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Groups.
     * @param {groupsUpsertArgs} args - Arguments to update or create a Groups.
     * @example
     * // Update or create a Groups
     * const groups = await prisma.groups.upsert({
     *   create: {
     *     // ... data to create a Groups
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Groups we want to update
     *   }
     * })
    **/
    upsert<T extends groupsUpsertArgs>(
      args: SelectSubset<T, groupsUpsertArgs>
    ): CheckSelect<T, Prisma__groupsClient<groups>, Prisma__groupsClient<groupsGetPayload<T>>>

    /**
     * Count the number of Groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupsCountArgs} args - Arguments to filter Groups to count.
     * @example
     * // Count the number of Groups
     * const count = await prisma.groups.count({
     *   where: {
     *     // ... the filter for the Groups we want to count
     *   }
     * })
    **/
    count<T extends groupsCountArgs>(
      args?: Subset<T, groupsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GroupsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GroupsAggregateArgs>(args: Subset<T, GroupsAggregateArgs>): PrismaPromise<GetGroupsAggregateType<T>>

    /**
     * Group by Groups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GroupsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GroupsGroupByArgs['orderBy'] }
        : { orderBy?: GroupsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GroupsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGroupsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for groups.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__groupsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    users<T extends groupMembersFindManyArgs = {}>(args?: Subset<T, groupMembersFindManyArgs>): CheckSelect<T, PrismaPromise<Array<groupMembers>>, PrismaPromise<Array<groupMembersGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * groups findUnique
   */
  export type groupsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * Throw an Error if a groups can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groups to fetch.
     * 
    **/
    where: groupsWhereUniqueInput
  }


  /**
   * groups findFirst
   */
  export type groupsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * Throw an Error if a groups can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groups to fetch.
     * 
    **/
    where?: groupsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groups to fetch.
     * 
    **/
    orderBy?: Enumerable<groupsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for groups.
     * 
    **/
    cursor?: groupsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groups from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groups.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of groups.
     * 
    **/
    distinct?: Enumerable<GroupsScalarFieldEnum>
  }


  /**
   * groups findMany
   */
  export type groupsFindManyArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * Filter, which groups to fetch.
     * 
    **/
    where?: groupsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groups to fetch.
     * 
    **/
    orderBy?: Enumerable<groupsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing groups.
     * 
    **/
    cursor?: groupsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groups from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groups.
     * 
    **/
    skip?: number
    distinct?: Enumerable<GroupsScalarFieldEnum>
  }


  /**
   * groups create
   */
  export type groupsCreateArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * The data needed to create a groups.
     * 
    **/
    data: XOR<groupsCreateInput, groupsUncheckedCreateInput>
  }


  /**
   * groups createMany
   */
  export type groupsCreateManyArgs = {
    data: Enumerable<groupsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * groups update
   */
  export type groupsUpdateArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * The data needed to update a groups.
     * 
    **/
    data: XOR<groupsUpdateInput, groupsUncheckedUpdateInput>
    /**
     * Choose, which groups to update.
     * 
    **/
    where: groupsWhereUniqueInput
  }


  /**
   * groups updateMany
   */
  export type groupsUpdateManyArgs = {
    data: XOR<groupsUpdateManyMutationInput, groupsUncheckedUpdateManyInput>
    where?: groupsWhereInput
  }


  /**
   * groups upsert
   */
  export type groupsUpsertArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * The filter to search for the groups to update in case it exists.
     * 
    **/
    where: groupsWhereUniqueInput
    /**
     * In case the groups found by the `where` argument doesn't exist, create a new groups with this data.
     * 
    **/
    create: XOR<groupsCreateInput, groupsUncheckedCreateInput>
    /**
     * In case the groups was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<groupsUpdateInput, groupsUncheckedUpdateInput>
  }


  /**
   * groups delete
   */
  export type groupsDeleteArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
    /**
     * Filter which groups to delete.
     * 
    **/
    where: groupsWhereUniqueInput
  }


  /**
   * groups deleteMany
   */
  export type groupsDeleteManyArgs = {
    where?: groupsWhereInput
  }


  /**
   * groups without action
   */
  export type groupsArgs = {
    /**
     * Select specific fields to fetch from the groups
     * 
    **/
    select?: groupsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: groupsInclude | null
  }



  /**
   * Model households
   */


  export type AggregateHouseholds = {
    _count: HouseholdsCountAggregateOutputType | null
    _min: HouseholdsMinAggregateOutputType | null
    _max: HouseholdsMaxAggregateOutputType | null
  }

  export type HouseholdsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
  }

  export type HouseholdsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
  }

  export type HouseholdsCountAggregateOutputType = {
    id: number
    churchId: number
    name: number
    _all: number
  }


  export type HouseholdsMinAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
  }

  export type HouseholdsMaxAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
  }

  export type HouseholdsCountAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    _all?: true
  }

  export type HouseholdsAggregateArgs = {
    /**
     * Filter which households to aggregate.
     * 
    **/
    where?: householdsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of households to fetch.
     * 
    **/
    orderBy?: Enumerable<householdsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: householdsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` households from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` households.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned households
    **/
    _count?: true | HouseholdsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HouseholdsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HouseholdsMaxAggregateInputType
  }

  export type GetHouseholdsAggregateType<T extends HouseholdsAggregateArgs> = {
        [P in keyof T & keyof AggregateHouseholds]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHouseholds[P]>
      : GetScalarType<T[P], AggregateHouseholds[P]>
  }




  export type HouseholdsGroupByArgs = {
    where?: householdsWhereInput
    orderBy?: Enumerable<householdsOrderByWithAggregationInput>
    by: Array<HouseholdsScalarFieldEnum>
    having?: householdsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HouseholdsCountAggregateInputType | true
    _min?: HouseholdsMinAggregateInputType
    _max?: HouseholdsMaxAggregateInputType
  }


  export type HouseholdsGroupByOutputType = {
    id: string
    churchId: string | null
    name: string | null
    _count: HouseholdsCountAggregateOutputType | null
    _min: HouseholdsMinAggregateOutputType | null
    _max: HouseholdsMaxAggregateOutputType | null
  }

  type GetHouseholdsGroupByPayload<T extends HouseholdsGroupByArgs> = Promise<
    Array<
      PickArray<HouseholdsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HouseholdsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HouseholdsGroupByOutputType[P]>
            : GetScalarType<T[P], HouseholdsGroupByOutputType[P]>
        }
      >
    >


  export type householdsSelect = {
    id?: boolean
    churchId?: boolean
    name?: boolean
    people?: boolean | peopleFindManyArgs
    _count?: boolean | HouseholdsCountOutputTypeArgs
  }

  export type householdsInclude = {
    people?: boolean | peopleFindManyArgs
    _count?: boolean | HouseholdsCountOutputTypeArgs
  }

  export type householdsGetPayload<
    S extends boolean | null | undefined | householdsArgs,
    U = keyof S
      > = S extends true
        ? households
    : S extends undefined
    ? never
    : S extends householdsArgs | householdsFindManyArgs
    ?'include' extends U
    ? households  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'people'
        ? Array < peopleGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? HouseholdsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof households ?households [P]
  : 
          P extends 'people'
        ? Array < peopleGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? HouseholdsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : households
  : households


  type householdsCountArgs = Merge<
    Omit<householdsFindManyArgs, 'select' | 'include'> & {
      select?: HouseholdsCountAggregateInputType | true
    }
  >

  export interface householdsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Households that matches the filter.
     * @param {householdsFindUniqueArgs} args - Arguments to find a Households
     * @example
     * // Get one Households
     * const households = await prisma.households.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends householdsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, householdsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'households'> extends True ? CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>> : CheckSelect<T, Prisma__householdsClient<households | null >, Prisma__householdsClient<householdsGetPayload<T> | null >>

    /**
     * Find the first Households that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {householdsFindFirstArgs} args - Arguments to find a Households
     * @example
     * // Get one Households
     * const households = await prisma.households.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends householdsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, householdsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'households'> extends True ? CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>> : CheckSelect<T, Prisma__householdsClient<households | null >, Prisma__householdsClient<householdsGetPayload<T> | null >>

    /**
     * Find zero or more Households that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {householdsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Households
     * const households = await prisma.households.findMany()
     * 
     * // Get first 10 Households
     * const households = await prisma.households.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const householdsWithIdOnly = await prisma.households.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends householdsFindManyArgs>(
      args?: SelectSubset<T, householdsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<households>>, PrismaPromise<Array<householdsGetPayload<T>>>>

    /**
     * Create a Households.
     * @param {householdsCreateArgs} args - Arguments to create a Households.
     * @example
     * // Create one Households
     * const Households = await prisma.households.create({
     *   data: {
     *     // ... data to create a Households
     *   }
     * })
     * 
    **/
    create<T extends householdsCreateArgs>(
      args: SelectSubset<T, householdsCreateArgs>
    ): CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>>

    /**
     * Create many Households.
     *     @param {householdsCreateManyArgs} args - Arguments to create many Households.
     *     @example
     *     // Create many Households
     *     const households = await prisma.households.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends householdsCreateManyArgs>(
      args?: SelectSubset<T, householdsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Households.
     * @param {householdsDeleteArgs} args - Arguments to delete one Households.
     * @example
     * // Delete one Households
     * const Households = await prisma.households.delete({
     *   where: {
     *     // ... filter to delete one Households
     *   }
     * })
     * 
    **/
    delete<T extends householdsDeleteArgs>(
      args: SelectSubset<T, householdsDeleteArgs>
    ): CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>>

    /**
     * Update one Households.
     * @param {householdsUpdateArgs} args - Arguments to update one Households.
     * @example
     * // Update one Households
     * const households = await prisma.households.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends householdsUpdateArgs>(
      args: SelectSubset<T, householdsUpdateArgs>
    ): CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>>

    /**
     * Delete zero or more Households.
     * @param {householdsDeleteManyArgs} args - Arguments to filter Households to delete.
     * @example
     * // Delete a few Households
     * const { count } = await prisma.households.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends householdsDeleteManyArgs>(
      args?: SelectSubset<T, householdsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Households.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {householdsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Households
     * const households = await prisma.households.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends householdsUpdateManyArgs>(
      args: SelectSubset<T, householdsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Households.
     * @param {householdsUpsertArgs} args - Arguments to update or create a Households.
     * @example
     * // Update or create a Households
     * const households = await prisma.households.upsert({
     *   create: {
     *     // ... data to create a Households
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Households we want to update
     *   }
     * })
    **/
    upsert<T extends householdsUpsertArgs>(
      args: SelectSubset<T, householdsUpsertArgs>
    ): CheckSelect<T, Prisma__householdsClient<households>, Prisma__householdsClient<householdsGetPayload<T>>>

    /**
     * Count the number of Households.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {householdsCountArgs} args - Arguments to filter Households to count.
     * @example
     * // Count the number of Households
     * const count = await prisma.households.count({
     *   where: {
     *     // ... the filter for the Households we want to count
     *   }
     * })
    **/
    count<T extends householdsCountArgs>(
      args?: Subset<T, householdsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HouseholdsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Households.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HouseholdsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HouseholdsAggregateArgs>(args: Subset<T, HouseholdsAggregateArgs>): PrismaPromise<GetHouseholdsAggregateType<T>>

    /**
     * Group by Households.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HouseholdsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HouseholdsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HouseholdsGroupByArgs['orderBy'] }
        : { orderBy?: HouseholdsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HouseholdsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHouseholdsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for households.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__householdsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    people<T extends peopleFindManyArgs = {}>(args?: Subset<T, peopleFindManyArgs>): CheckSelect<T, PrismaPromise<Array<people>>, PrismaPromise<Array<peopleGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * households findUnique
   */
  export type householdsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * Throw an Error if a households can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which households to fetch.
     * 
    **/
    where: householdsWhereUniqueInput
  }


  /**
   * households findFirst
   */
  export type householdsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * Throw an Error if a households can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which households to fetch.
     * 
    **/
    where?: householdsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of households to fetch.
     * 
    **/
    orderBy?: Enumerable<householdsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for households.
     * 
    **/
    cursor?: householdsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` households from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` households.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of households.
     * 
    **/
    distinct?: Enumerable<HouseholdsScalarFieldEnum>
  }


  /**
   * households findMany
   */
  export type householdsFindManyArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * Filter, which households to fetch.
     * 
    **/
    where?: householdsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of households to fetch.
     * 
    **/
    orderBy?: Enumerable<householdsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing households.
     * 
    **/
    cursor?: householdsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` households from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` households.
     * 
    **/
    skip?: number
    distinct?: Enumerable<HouseholdsScalarFieldEnum>
  }


  /**
   * households create
   */
  export type householdsCreateArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * The data needed to create a households.
     * 
    **/
    data: XOR<householdsCreateInput, householdsUncheckedCreateInput>
  }


  /**
   * households createMany
   */
  export type householdsCreateManyArgs = {
    data: Enumerable<householdsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * households update
   */
  export type householdsUpdateArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * The data needed to update a households.
     * 
    **/
    data: XOR<householdsUpdateInput, householdsUncheckedUpdateInput>
    /**
     * Choose, which households to update.
     * 
    **/
    where: householdsWhereUniqueInput
  }


  /**
   * households updateMany
   */
  export type householdsUpdateManyArgs = {
    data: XOR<householdsUpdateManyMutationInput, householdsUncheckedUpdateManyInput>
    where?: householdsWhereInput
  }


  /**
   * households upsert
   */
  export type householdsUpsertArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * The filter to search for the households to update in case it exists.
     * 
    **/
    where: householdsWhereUniqueInput
    /**
     * In case the households found by the `where` argument doesn't exist, create a new households with this data.
     * 
    **/
    create: XOR<householdsCreateInput, householdsUncheckedCreateInput>
    /**
     * In case the households was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<householdsUpdateInput, householdsUncheckedUpdateInput>
  }


  /**
   * households delete
   */
  export type householdsDeleteArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
    /**
     * Filter which households to delete.
     * 
    **/
    where: householdsWhereUniqueInput
  }


  /**
   * households deleteMany
   */
  export type householdsDeleteManyArgs = {
    where?: householdsWhereInput
  }


  /**
   * households without action
   */
  export type householdsArgs = {
    /**
     * Select specific fields to fetch from the households
     * 
    **/
    select?: householdsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: householdsInclude | null
  }



  /**
   * Model notes
   */


  export type AggregateNotes = {
    _count: NotesCountAggregateOutputType | null
    _min: NotesMinAggregateOutputType | null
    _max: NotesMaxAggregateOutputType | null
  }

  export type NotesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    contentType: string | null
    contentId: string | null
    noteType: string | null
    addedBy: string | null
    createdAt: Date | null
    updatedAt: Date | null
    contents: string | null
  }

  export type NotesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    contentType: string | null
    contentId: string | null
    noteType: string | null
    addedBy: string | null
    createdAt: Date | null
    updatedAt: Date | null
    contents: string | null
  }

  export type NotesCountAggregateOutputType = {
    id: number
    churchId: number
    contentType: number
    contentId: number
    noteType: number
    addedBy: number
    createdAt: number
    updatedAt: number
    contents: number
    _all: number
  }


  export type NotesMinAggregateInputType = {
    id?: true
    churchId?: true
    contentType?: true
    contentId?: true
    noteType?: true
    addedBy?: true
    createdAt?: true
    updatedAt?: true
    contents?: true
  }

  export type NotesMaxAggregateInputType = {
    id?: true
    churchId?: true
    contentType?: true
    contentId?: true
    noteType?: true
    addedBy?: true
    createdAt?: true
    updatedAt?: true
    contents?: true
  }

  export type NotesCountAggregateInputType = {
    id?: true
    churchId?: true
    contentType?: true
    contentId?: true
    noteType?: true
    addedBy?: true
    createdAt?: true
    updatedAt?: true
    contents?: true
    _all?: true
  }

  export type NotesAggregateArgs = {
    /**
     * Filter which notes to aggregate.
     * 
    **/
    where?: notesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notes to fetch.
     * 
    **/
    orderBy?: Enumerable<notesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: notesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned notes
    **/
    _count?: true | NotesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: NotesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: NotesMaxAggregateInputType
  }

  export type GetNotesAggregateType<T extends NotesAggregateArgs> = {
        [P in keyof T & keyof AggregateNotes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateNotes[P]>
      : GetScalarType<T[P], AggregateNotes[P]>
  }




  export type NotesGroupByArgs = {
    where?: notesWhereInput
    orderBy?: Enumerable<notesOrderByWithAggregationInput>
    by: Array<NotesScalarFieldEnum>
    having?: notesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: NotesCountAggregateInputType | true
    _min?: NotesMinAggregateInputType
    _max?: NotesMaxAggregateInputType
  }


  export type NotesGroupByOutputType = {
    id: string
    churchId: string | null
    contentType: string | null
    contentId: string | null
    noteType: string | null
    addedBy: string | null
    createdAt: Date | null
    updatedAt: Date | null
    contents: string | null
    _count: NotesCountAggregateOutputType | null
    _min: NotesMinAggregateOutputType | null
    _max: NotesMaxAggregateOutputType | null
  }

  type GetNotesGroupByPayload<T extends NotesGroupByArgs> = Promise<
    Array<
      PickArray<NotesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof NotesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], NotesGroupByOutputType[P]>
            : GetScalarType<T[P], NotesGroupByOutputType[P]>
        }
      >
    >


  export type notesSelect = {
    id?: boolean
    churchId?: boolean
    contentType?: boolean
    contentId?: boolean
    noteType?: boolean
    addedBy?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    contents?: boolean
  }

  export type notesGetPayload<
    S extends boolean | null | undefined | notesArgs,
    U = keyof S
      > = S extends true
        ? notes
    : S extends undefined
    ? never
    : S extends notesArgs | notesFindManyArgs
    ?'include' extends U
    ? notes 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof notes ?notes [P]
  : 
     never
  } 
    : notes
  : notes


  type notesCountArgs = Merge<
    Omit<notesFindManyArgs, 'select' | 'include'> & {
      select?: NotesCountAggregateInputType | true
    }
  >

  export interface notesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Notes that matches the filter.
     * @param {notesFindUniqueArgs} args - Arguments to find a Notes
     * @example
     * // Get one Notes
     * const notes = await prisma.notes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends notesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, notesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'notes'> extends True ? CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>> : CheckSelect<T, Prisma__notesClient<notes | null >, Prisma__notesClient<notesGetPayload<T> | null >>

    /**
     * Find the first Notes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notesFindFirstArgs} args - Arguments to find a Notes
     * @example
     * // Get one Notes
     * const notes = await prisma.notes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends notesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, notesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'notes'> extends True ? CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>> : CheckSelect<T, Prisma__notesClient<notes | null >, Prisma__notesClient<notesGetPayload<T> | null >>

    /**
     * Find zero or more Notes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Notes
     * const notes = await prisma.notes.findMany()
     * 
     * // Get first 10 Notes
     * const notes = await prisma.notes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const notesWithIdOnly = await prisma.notes.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends notesFindManyArgs>(
      args?: SelectSubset<T, notesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<notes>>, PrismaPromise<Array<notesGetPayload<T>>>>

    /**
     * Create a Notes.
     * @param {notesCreateArgs} args - Arguments to create a Notes.
     * @example
     * // Create one Notes
     * const Notes = await prisma.notes.create({
     *   data: {
     *     // ... data to create a Notes
     *   }
     * })
     * 
    **/
    create<T extends notesCreateArgs>(
      args: SelectSubset<T, notesCreateArgs>
    ): CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>>

    /**
     * Create many Notes.
     *     @param {notesCreateManyArgs} args - Arguments to create many Notes.
     *     @example
     *     // Create many Notes
     *     const notes = await prisma.notes.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends notesCreateManyArgs>(
      args?: SelectSubset<T, notesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Notes.
     * @param {notesDeleteArgs} args - Arguments to delete one Notes.
     * @example
     * // Delete one Notes
     * const Notes = await prisma.notes.delete({
     *   where: {
     *     // ... filter to delete one Notes
     *   }
     * })
     * 
    **/
    delete<T extends notesDeleteArgs>(
      args: SelectSubset<T, notesDeleteArgs>
    ): CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>>

    /**
     * Update one Notes.
     * @param {notesUpdateArgs} args - Arguments to update one Notes.
     * @example
     * // Update one Notes
     * const notes = await prisma.notes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends notesUpdateArgs>(
      args: SelectSubset<T, notesUpdateArgs>
    ): CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>>

    /**
     * Delete zero or more Notes.
     * @param {notesDeleteManyArgs} args - Arguments to filter Notes to delete.
     * @example
     * // Delete a few Notes
     * const { count } = await prisma.notes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends notesDeleteManyArgs>(
      args?: SelectSubset<T, notesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Notes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Notes
     * const notes = await prisma.notes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends notesUpdateManyArgs>(
      args: SelectSubset<T, notesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Notes.
     * @param {notesUpsertArgs} args - Arguments to update or create a Notes.
     * @example
     * // Update or create a Notes
     * const notes = await prisma.notes.upsert({
     *   create: {
     *     // ... data to create a Notes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Notes we want to update
     *   }
     * })
    **/
    upsert<T extends notesUpsertArgs>(
      args: SelectSubset<T, notesUpsertArgs>
    ): CheckSelect<T, Prisma__notesClient<notes>, Prisma__notesClient<notesGetPayload<T>>>

    /**
     * Count the number of Notes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {notesCountArgs} args - Arguments to filter Notes to count.
     * @example
     * // Count the number of Notes
     * const count = await prisma.notes.count({
     *   where: {
     *     // ... the filter for the Notes we want to count
     *   }
     * })
    **/
    count<T extends notesCountArgs>(
      args?: Subset<T, notesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], NotesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Notes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends NotesAggregateArgs>(args: Subset<T, NotesAggregateArgs>): PrismaPromise<GetNotesAggregateType<T>>

    /**
     * Group by Notes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NotesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends NotesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: NotesGroupByArgs['orderBy'] }
        : { orderBy?: NotesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, NotesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNotesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for notes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__notesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * notes findUnique
   */
  export type notesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * Throw an Error if a notes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which notes to fetch.
     * 
    **/
    where: notesWhereUniqueInput
  }


  /**
   * notes findFirst
   */
  export type notesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * Throw an Error if a notes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which notes to fetch.
     * 
    **/
    where?: notesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notes to fetch.
     * 
    **/
    orderBy?: Enumerable<notesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for notes.
     * 
    **/
    cursor?: notesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of notes.
     * 
    **/
    distinct?: Enumerable<NotesScalarFieldEnum>
  }


  /**
   * notes findMany
   */
  export type notesFindManyArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * Filter, which notes to fetch.
     * 
    **/
    where?: notesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of notes to fetch.
     * 
    **/
    orderBy?: Enumerable<notesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing notes.
     * 
    **/
    cursor?: notesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` notes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` notes.
     * 
    **/
    skip?: number
    distinct?: Enumerable<NotesScalarFieldEnum>
  }


  /**
   * notes create
   */
  export type notesCreateArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * The data needed to create a notes.
     * 
    **/
    data: XOR<notesCreateInput, notesUncheckedCreateInput>
  }


  /**
   * notes createMany
   */
  export type notesCreateManyArgs = {
    data: Enumerable<notesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * notes update
   */
  export type notesUpdateArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * The data needed to update a notes.
     * 
    **/
    data: XOR<notesUpdateInput, notesUncheckedUpdateInput>
    /**
     * Choose, which notes to update.
     * 
    **/
    where: notesWhereUniqueInput
  }


  /**
   * notes updateMany
   */
  export type notesUpdateManyArgs = {
    data: XOR<notesUpdateManyMutationInput, notesUncheckedUpdateManyInput>
    where?: notesWhereInput
  }


  /**
   * notes upsert
   */
  export type notesUpsertArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * The filter to search for the notes to update in case it exists.
     * 
    **/
    where: notesWhereUniqueInput
    /**
     * In case the notes found by the `where` argument doesn't exist, create a new notes with this data.
     * 
    **/
    create: XOR<notesCreateInput, notesUncheckedCreateInput>
    /**
     * In case the notes was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<notesUpdateInput, notesUncheckedUpdateInput>
  }


  /**
   * notes delete
   */
  export type notesDeleteArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
    /**
     * Filter which notes to delete.
     * 
    **/
    where: notesWhereUniqueInput
  }


  /**
   * notes deleteMany
   */
  export type notesDeleteManyArgs = {
    where?: notesWhereInput
  }


  /**
   * notes without action
   */
  export type notesArgs = {
    /**
     * Select specific fields to fetch from the notes
     * 
    **/
    select?: notesSelect | null
  }



  /**
   * Model people
   */


  export type AggregatePeople = {
    _count: PeopleCountAggregateOutputType | null
    _min: PeopleMinAggregateOutputType | null
    _max: PeopleMaxAggregateOutputType | null
  }

  export type PeopleMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    displayName: string | null
    firstName: string | null
    middleName: string | null
    lastName: string | null
    nickName: string | null
    prefix: string | null
    suffix: string | null
    birthDate: Date | null
    gender: string | null
    maritalStatus: string | null
    anniversary: Date | null
    membershipStatus: string | null
    homePhone: string | null
    mobilePhone: string | null
    workPhone: string | null
    email: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    photoUpdated: Date | null
    householdId: string | null
    householdRole: string | null
    removed: boolean | null
  }

  export type PeopleMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    displayName: string | null
    firstName: string | null
    middleName: string | null
    lastName: string | null
    nickName: string | null
    prefix: string | null
    suffix: string | null
    birthDate: Date | null
    gender: string | null
    maritalStatus: string | null
    anniversary: Date | null
    membershipStatus: string | null
    homePhone: string | null
    mobilePhone: string | null
    workPhone: string | null
    email: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    photoUpdated: Date | null
    householdId: string | null
    householdRole: string | null
    removed: boolean | null
  }

  export type PeopleCountAggregateOutputType = {
    id: number
    churchId: number
    displayName: number
    firstName: number
    middleName: number
    lastName: number
    nickName: number
    prefix: number
    suffix: number
    birthDate: number
    gender: number
    maritalStatus: number
    anniversary: number
    membershipStatus: number
    homePhone: number
    mobilePhone: number
    workPhone: number
    email: number
    address1: number
    address2: number
    city: number
    state: number
    zip: number
    photoUpdated: number
    householdId: number
    householdRole: number
    removed: number
    _all: number
  }


  export type PeopleMinAggregateInputType = {
    id?: true
    churchId?: true
    displayName?: true
    firstName?: true
    middleName?: true
    lastName?: true
    nickName?: true
    prefix?: true
    suffix?: true
    birthDate?: true
    gender?: true
    maritalStatus?: true
    anniversary?: true
    membershipStatus?: true
    homePhone?: true
    mobilePhone?: true
    workPhone?: true
    email?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    photoUpdated?: true
    householdId?: true
    householdRole?: true
    removed?: true
  }

  export type PeopleMaxAggregateInputType = {
    id?: true
    churchId?: true
    displayName?: true
    firstName?: true
    middleName?: true
    lastName?: true
    nickName?: true
    prefix?: true
    suffix?: true
    birthDate?: true
    gender?: true
    maritalStatus?: true
    anniversary?: true
    membershipStatus?: true
    homePhone?: true
    mobilePhone?: true
    workPhone?: true
    email?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    photoUpdated?: true
    householdId?: true
    householdRole?: true
    removed?: true
  }

  export type PeopleCountAggregateInputType = {
    id?: true
    churchId?: true
    displayName?: true
    firstName?: true
    middleName?: true
    lastName?: true
    nickName?: true
    prefix?: true
    suffix?: true
    birthDate?: true
    gender?: true
    maritalStatus?: true
    anniversary?: true
    membershipStatus?: true
    homePhone?: true
    mobilePhone?: true
    workPhone?: true
    email?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    photoUpdated?: true
    householdId?: true
    householdRole?: true
    removed?: true
    _all?: true
  }

  export type PeopleAggregateArgs = {
    /**
     * Filter which people to aggregate.
     * 
    **/
    where?: peopleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of people to fetch.
     * 
    **/
    orderBy?: Enumerable<peopleOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: peopleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` people from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` people.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned people
    **/
    _count?: true | PeopleCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PeopleMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PeopleMaxAggregateInputType
  }

  export type GetPeopleAggregateType<T extends PeopleAggregateArgs> = {
        [P in keyof T & keyof AggregatePeople]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePeople[P]>
      : GetScalarType<T[P], AggregatePeople[P]>
  }




  export type PeopleGroupByArgs = {
    where?: peopleWhereInput
    orderBy?: Enumerable<peopleOrderByWithAggregationInput>
    by: Array<PeopleScalarFieldEnum>
    having?: peopleScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PeopleCountAggregateInputType | true
    _min?: PeopleMinAggregateInputType
    _max?: PeopleMaxAggregateInputType
  }


  export type PeopleGroupByOutputType = {
    id: string
    churchId: string | null
    displayName: string | null
    firstName: string | null
    middleName: string | null
    lastName: string | null
    nickName: string | null
    prefix: string | null
    suffix: string | null
    birthDate: Date | null
    gender: string | null
    maritalStatus: string | null
    anniversary: Date | null
    membershipStatus: string | null
    homePhone: string | null
    mobilePhone: string | null
    workPhone: string | null
    email: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    photoUpdated: Date | null
    householdId: string | null
    householdRole: string | null
    removed: boolean | null
    _count: PeopleCountAggregateOutputType | null
    _min: PeopleMinAggregateOutputType | null
    _max: PeopleMaxAggregateOutputType | null
  }

  type GetPeopleGroupByPayload<T extends PeopleGroupByArgs> = Promise<
    Array<
      PickArray<PeopleGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PeopleGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PeopleGroupByOutputType[P]>
            : GetScalarType<T[P], PeopleGroupByOutputType[P]>
        }
      >
    >


  export type peopleSelect = {
    id?: boolean
    churchId?: boolean
    displayName?: boolean
    firstName?: boolean
    middleName?: boolean
    lastName?: boolean
    nickName?: boolean
    prefix?: boolean
    suffix?: boolean
    birthDate?: boolean
    gender?: boolean
    maritalStatus?: boolean
    anniversary?: boolean
    membershipStatus?: boolean
    homePhone?: boolean
    mobilePhone?: boolean
    workPhone?: boolean
    email?: boolean
    address1?: boolean
    address2?: boolean
    city?: boolean
    state?: boolean
    zip?: boolean
    photoUpdated?: boolean
    householdId?: boolean
    householdRole?: boolean
    removed?: boolean
    groups?: boolean | groupMembersFindManyArgs
    household?: boolean | householdsArgs
    _count?: boolean | PeopleCountOutputTypeArgs
  }

  export type peopleInclude = {
    groups?: boolean | groupMembersFindManyArgs
    household?: boolean | householdsArgs
    _count?: boolean | PeopleCountOutputTypeArgs
  }

  export type peopleGetPayload<
    S extends boolean | null | undefined | peopleArgs,
    U = keyof S
      > = S extends true
        ? people
    : S extends undefined
    ? never
    : S extends peopleArgs | peopleFindManyArgs
    ?'include' extends U
    ? people  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'groups'
        ? Array < groupMembersGetPayload<S['include'][P]>>  :
        P extends 'household'
        ? householdsGetPayload<S['include'][P]> | null :
        P extends '_count'
        ? PeopleCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof people ?people [P]
  : 
          P extends 'groups'
        ? Array < groupMembersGetPayload<S['select'][P]>>  :
        P extends 'household'
        ? householdsGetPayload<S['select'][P]> | null :
        P extends '_count'
        ? PeopleCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : people
  : people


  type peopleCountArgs = Merge<
    Omit<peopleFindManyArgs, 'select' | 'include'> & {
      select?: PeopleCountAggregateInputType | true
    }
  >

  export interface peopleDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one People that matches the filter.
     * @param {peopleFindUniqueArgs} args - Arguments to find a People
     * @example
     * // Get one People
     * const people = await prisma.people.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends peopleFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, peopleFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'people'> extends True ? CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>> : CheckSelect<T, Prisma__peopleClient<people | null >, Prisma__peopleClient<peopleGetPayload<T> | null >>

    /**
     * Find the first People that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {peopleFindFirstArgs} args - Arguments to find a People
     * @example
     * // Get one People
     * const people = await prisma.people.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends peopleFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, peopleFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'people'> extends True ? CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>> : CheckSelect<T, Prisma__peopleClient<people | null >, Prisma__peopleClient<peopleGetPayload<T> | null >>

    /**
     * Find zero or more People that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {peopleFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all People
     * const people = await prisma.people.findMany()
     * 
     * // Get first 10 People
     * const people = await prisma.people.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const peopleWithIdOnly = await prisma.people.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends peopleFindManyArgs>(
      args?: SelectSubset<T, peopleFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<people>>, PrismaPromise<Array<peopleGetPayload<T>>>>

    /**
     * Create a People.
     * @param {peopleCreateArgs} args - Arguments to create a People.
     * @example
     * // Create one People
     * const People = await prisma.people.create({
     *   data: {
     *     // ... data to create a People
     *   }
     * })
     * 
    **/
    create<T extends peopleCreateArgs>(
      args: SelectSubset<T, peopleCreateArgs>
    ): CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>>

    /**
     * Create many People.
     *     @param {peopleCreateManyArgs} args - Arguments to create many People.
     *     @example
     *     // Create many People
     *     const people = await prisma.people.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends peopleCreateManyArgs>(
      args?: SelectSubset<T, peopleCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a People.
     * @param {peopleDeleteArgs} args - Arguments to delete one People.
     * @example
     * // Delete one People
     * const People = await prisma.people.delete({
     *   where: {
     *     // ... filter to delete one People
     *   }
     * })
     * 
    **/
    delete<T extends peopleDeleteArgs>(
      args: SelectSubset<T, peopleDeleteArgs>
    ): CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>>

    /**
     * Update one People.
     * @param {peopleUpdateArgs} args - Arguments to update one People.
     * @example
     * // Update one People
     * const people = await prisma.people.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends peopleUpdateArgs>(
      args: SelectSubset<T, peopleUpdateArgs>
    ): CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>>

    /**
     * Delete zero or more People.
     * @param {peopleDeleteManyArgs} args - Arguments to filter People to delete.
     * @example
     * // Delete a few People
     * const { count } = await prisma.people.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends peopleDeleteManyArgs>(
      args?: SelectSubset<T, peopleDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more People.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {peopleUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many People
     * const people = await prisma.people.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends peopleUpdateManyArgs>(
      args: SelectSubset<T, peopleUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one People.
     * @param {peopleUpsertArgs} args - Arguments to update or create a People.
     * @example
     * // Update or create a People
     * const people = await prisma.people.upsert({
     *   create: {
     *     // ... data to create a People
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the People we want to update
     *   }
     * })
    **/
    upsert<T extends peopleUpsertArgs>(
      args: SelectSubset<T, peopleUpsertArgs>
    ): CheckSelect<T, Prisma__peopleClient<people>, Prisma__peopleClient<peopleGetPayload<T>>>

    /**
     * Count the number of People.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {peopleCountArgs} args - Arguments to filter People to count.
     * @example
     * // Count the number of People
     * const count = await prisma.people.count({
     *   where: {
     *     // ... the filter for the People we want to count
     *   }
     * })
    **/
    count<T extends peopleCountArgs>(
      args?: Subset<T, peopleCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PeopleCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a People.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PeopleAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PeopleAggregateArgs>(args: Subset<T, PeopleAggregateArgs>): PrismaPromise<GetPeopleAggregateType<T>>

    /**
     * Group by People.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PeopleGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PeopleGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PeopleGroupByArgs['orderBy'] }
        : { orderBy?: PeopleGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PeopleGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPeopleGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for people.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__peopleClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    groups<T extends groupMembersFindManyArgs = {}>(args?: Subset<T, groupMembersFindManyArgs>): CheckSelect<T, PrismaPromise<Array<groupMembers>>, PrismaPromise<Array<groupMembersGetPayload<T>>>>;

    household<T extends householdsArgs = {}>(args?: Subset<T, householdsArgs>): CheckSelect<T, Prisma__householdsClient<households | null >, Prisma__householdsClient<householdsGetPayload<T> | null >>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * people findUnique
   */
  export type peopleFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * Throw an Error if a people can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which people to fetch.
     * 
    **/
    where: peopleWhereUniqueInput
  }


  /**
   * people findFirst
   */
  export type peopleFindFirstArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * Throw an Error if a people can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which people to fetch.
     * 
    **/
    where?: peopleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of people to fetch.
     * 
    **/
    orderBy?: Enumerable<peopleOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for people.
     * 
    **/
    cursor?: peopleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` people from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` people.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of people.
     * 
    **/
    distinct?: Enumerable<PeopleScalarFieldEnum>
  }


  /**
   * people findMany
   */
  export type peopleFindManyArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * Filter, which people to fetch.
     * 
    **/
    where?: peopleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of people to fetch.
     * 
    **/
    orderBy?: Enumerable<peopleOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing people.
     * 
    **/
    cursor?: peopleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` people from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` people.
     * 
    **/
    skip?: number
    distinct?: Enumerable<PeopleScalarFieldEnum>
  }


  /**
   * people create
   */
  export type peopleCreateArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * The data needed to create a people.
     * 
    **/
    data: XOR<peopleCreateInput, peopleUncheckedCreateInput>
  }


  /**
   * people createMany
   */
  export type peopleCreateManyArgs = {
    data: Enumerable<peopleCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * people update
   */
  export type peopleUpdateArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * The data needed to update a people.
     * 
    **/
    data: XOR<peopleUpdateInput, peopleUncheckedUpdateInput>
    /**
     * Choose, which people to update.
     * 
    **/
    where: peopleWhereUniqueInput
  }


  /**
   * people updateMany
   */
  export type peopleUpdateManyArgs = {
    data: XOR<peopleUpdateManyMutationInput, peopleUncheckedUpdateManyInput>
    where?: peopleWhereInput
  }


  /**
   * people upsert
   */
  export type peopleUpsertArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * The filter to search for the people to update in case it exists.
     * 
    **/
    where: peopleWhereUniqueInput
    /**
     * In case the people found by the `where` argument doesn't exist, create a new people with this data.
     * 
    **/
    create: XOR<peopleCreateInput, peopleUncheckedCreateInput>
    /**
     * In case the people was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<peopleUpdateInput, peopleUncheckedUpdateInput>
  }


  /**
   * people delete
   */
  export type peopleDeleteArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
    /**
     * Filter which people to delete.
     * 
    **/
    where: peopleWhereUniqueInput
  }


  /**
   * people deleteMany
   */
  export type peopleDeleteManyArgs = {
    where?: peopleWhereInput
  }


  /**
   * people without action
   */
  export type peopleArgs = {
    /**
     * Select specific fields to fetch from the people
     * 
    **/
    select?: peopleSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: peopleInclude | null
  }



  /**
   * Model questions
   */


  export type AggregateQuestions = {
    _count: QuestionsCountAggregateOutputType | null
    _min: QuestionsMinAggregateOutputType | null
    _max: QuestionsMaxAggregateOutputType | null
  }

  export type QuestionsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    formId: string | null
    parentId: string | null
    title: string | null
    description: string | null
    fieldType: string | null
    placeholder: string | null
    sort: string | null
    choices: string | null
    removed: boolean | null
  }

  export type QuestionsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    formId: string | null
    parentId: string | null
    title: string | null
    description: string | null
    fieldType: string | null
    placeholder: string | null
    sort: string | null
    choices: string | null
    removed: boolean | null
  }

  export type QuestionsCountAggregateOutputType = {
    id: number
    churchId: number
    formId: number
    parentId: number
    title: number
    description: number
    fieldType: number
    placeholder: number
    sort: number
    choices: number
    removed: number
    _all: number
  }


  export type QuestionsMinAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    parentId?: true
    title?: true
    description?: true
    fieldType?: true
    placeholder?: true
    sort?: true
    choices?: true
    removed?: true
  }

  export type QuestionsMaxAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    parentId?: true
    title?: true
    description?: true
    fieldType?: true
    placeholder?: true
    sort?: true
    choices?: true
    removed?: true
  }

  export type QuestionsCountAggregateInputType = {
    id?: true
    churchId?: true
    formId?: true
    parentId?: true
    title?: true
    description?: true
    fieldType?: true
    placeholder?: true
    sort?: true
    choices?: true
    removed?: true
    _all?: true
  }

  export type QuestionsAggregateArgs = {
    /**
     * Filter which questions to aggregate.
     * 
    **/
    where?: questionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of questions to fetch.
     * 
    **/
    orderBy?: Enumerable<questionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: questionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` questions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` questions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned questions
    **/
    _count?: true | QuestionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: QuestionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: QuestionsMaxAggregateInputType
  }

  export type GetQuestionsAggregateType<T extends QuestionsAggregateArgs> = {
        [P in keyof T & keyof AggregateQuestions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateQuestions[P]>
      : GetScalarType<T[P], AggregateQuestions[P]>
  }




  export type QuestionsGroupByArgs = {
    where?: questionsWhereInput
    orderBy?: Enumerable<questionsOrderByWithAggregationInput>
    by: Array<QuestionsScalarFieldEnum>
    having?: questionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: QuestionsCountAggregateInputType | true
    _min?: QuestionsMinAggregateInputType
    _max?: QuestionsMaxAggregateInputType
  }


  export type QuestionsGroupByOutputType = {
    id: string
    churchId: string | null
    formId: string | null
    parentId: string | null
    title: string | null
    description: string | null
    fieldType: string | null
    placeholder: string | null
    sort: string | null
    choices: string | null
    removed: boolean | null
    _count: QuestionsCountAggregateOutputType | null
    _min: QuestionsMinAggregateOutputType | null
    _max: QuestionsMaxAggregateOutputType | null
  }

  type GetQuestionsGroupByPayload<T extends QuestionsGroupByArgs> = Promise<
    Array<
      PickArray<QuestionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof QuestionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], QuestionsGroupByOutputType[P]>
            : GetScalarType<T[P], QuestionsGroupByOutputType[P]>
        }
      >
    >


  export type questionsSelect = {
    id?: boolean
    churchId?: boolean
    formId?: boolean
    parentId?: boolean
    title?: boolean
    description?: boolean
    fieldType?: boolean
    placeholder?: boolean
    sort?: boolean
    choices?: boolean
    removed?: boolean
  }

  export type questionsGetPayload<
    S extends boolean | null | undefined | questionsArgs,
    U = keyof S
      > = S extends true
        ? questions
    : S extends undefined
    ? never
    : S extends questionsArgs | questionsFindManyArgs
    ?'include' extends U
    ? questions 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof questions ?questions [P]
  : 
     never
  } 
    : questions
  : questions


  type questionsCountArgs = Merge<
    Omit<questionsFindManyArgs, 'select' | 'include'> & {
      select?: QuestionsCountAggregateInputType | true
    }
  >

  export interface questionsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Questions that matches the filter.
     * @param {questionsFindUniqueArgs} args - Arguments to find a Questions
     * @example
     * // Get one Questions
     * const questions = await prisma.questions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends questionsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, questionsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'questions'> extends True ? CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>> : CheckSelect<T, Prisma__questionsClient<questions | null >, Prisma__questionsClient<questionsGetPayload<T> | null >>

    /**
     * Find the first Questions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {questionsFindFirstArgs} args - Arguments to find a Questions
     * @example
     * // Get one Questions
     * const questions = await prisma.questions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends questionsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, questionsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'questions'> extends True ? CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>> : CheckSelect<T, Prisma__questionsClient<questions | null >, Prisma__questionsClient<questionsGetPayload<T> | null >>

    /**
     * Find zero or more Questions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {questionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Questions
     * const questions = await prisma.questions.findMany()
     * 
     * // Get first 10 Questions
     * const questions = await prisma.questions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const questionsWithIdOnly = await prisma.questions.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends questionsFindManyArgs>(
      args?: SelectSubset<T, questionsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<questions>>, PrismaPromise<Array<questionsGetPayload<T>>>>

    /**
     * Create a Questions.
     * @param {questionsCreateArgs} args - Arguments to create a Questions.
     * @example
     * // Create one Questions
     * const Questions = await prisma.questions.create({
     *   data: {
     *     // ... data to create a Questions
     *   }
     * })
     * 
    **/
    create<T extends questionsCreateArgs>(
      args: SelectSubset<T, questionsCreateArgs>
    ): CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>>

    /**
     * Create many Questions.
     *     @param {questionsCreateManyArgs} args - Arguments to create many Questions.
     *     @example
     *     // Create many Questions
     *     const questions = await prisma.questions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends questionsCreateManyArgs>(
      args?: SelectSubset<T, questionsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Questions.
     * @param {questionsDeleteArgs} args - Arguments to delete one Questions.
     * @example
     * // Delete one Questions
     * const Questions = await prisma.questions.delete({
     *   where: {
     *     // ... filter to delete one Questions
     *   }
     * })
     * 
    **/
    delete<T extends questionsDeleteArgs>(
      args: SelectSubset<T, questionsDeleteArgs>
    ): CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>>

    /**
     * Update one Questions.
     * @param {questionsUpdateArgs} args - Arguments to update one Questions.
     * @example
     * // Update one Questions
     * const questions = await prisma.questions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends questionsUpdateArgs>(
      args: SelectSubset<T, questionsUpdateArgs>
    ): CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>>

    /**
     * Delete zero or more Questions.
     * @param {questionsDeleteManyArgs} args - Arguments to filter Questions to delete.
     * @example
     * // Delete a few Questions
     * const { count } = await prisma.questions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends questionsDeleteManyArgs>(
      args?: SelectSubset<T, questionsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Questions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {questionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Questions
     * const questions = await prisma.questions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends questionsUpdateManyArgs>(
      args: SelectSubset<T, questionsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Questions.
     * @param {questionsUpsertArgs} args - Arguments to update or create a Questions.
     * @example
     * // Update or create a Questions
     * const questions = await prisma.questions.upsert({
     *   create: {
     *     // ... data to create a Questions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Questions we want to update
     *   }
     * })
    **/
    upsert<T extends questionsUpsertArgs>(
      args: SelectSubset<T, questionsUpsertArgs>
    ): CheckSelect<T, Prisma__questionsClient<questions>, Prisma__questionsClient<questionsGetPayload<T>>>

    /**
     * Count the number of Questions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {questionsCountArgs} args - Arguments to filter Questions to count.
     * @example
     * // Count the number of Questions
     * const count = await prisma.questions.count({
     *   where: {
     *     // ... the filter for the Questions we want to count
     *   }
     * })
    **/
    count<T extends questionsCountArgs>(
      args?: Subset<T, questionsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], QuestionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Questions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {QuestionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends QuestionsAggregateArgs>(args: Subset<T, QuestionsAggregateArgs>): PrismaPromise<GetQuestionsAggregateType<T>>

    /**
     * Group by Questions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {QuestionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends QuestionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: QuestionsGroupByArgs['orderBy'] }
        : { orderBy?: QuestionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, QuestionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetQuestionsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for questions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__questionsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * questions findUnique
   */
  export type questionsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * Throw an Error if a questions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which questions to fetch.
     * 
    **/
    where: questionsWhereUniqueInput
  }


  /**
   * questions findFirst
   */
  export type questionsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * Throw an Error if a questions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which questions to fetch.
     * 
    **/
    where?: questionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of questions to fetch.
     * 
    **/
    orderBy?: Enumerable<questionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for questions.
     * 
    **/
    cursor?: questionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` questions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` questions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of questions.
     * 
    **/
    distinct?: Enumerable<QuestionsScalarFieldEnum>
  }


  /**
   * questions findMany
   */
  export type questionsFindManyArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * Filter, which questions to fetch.
     * 
    **/
    where?: questionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of questions to fetch.
     * 
    **/
    orderBy?: Enumerable<questionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing questions.
     * 
    **/
    cursor?: questionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` questions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` questions.
     * 
    **/
    skip?: number
    distinct?: Enumerable<QuestionsScalarFieldEnum>
  }


  /**
   * questions create
   */
  export type questionsCreateArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * The data needed to create a questions.
     * 
    **/
    data: XOR<questionsCreateInput, questionsUncheckedCreateInput>
  }


  /**
   * questions createMany
   */
  export type questionsCreateManyArgs = {
    data: Enumerable<questionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * questions update
   */
  export type questionsUpdateArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * The data needed to update a questions.
     * 
    **/
    data: XOR<questionsUpdateInput, questionsUncheckedUpdateInput>
    /**
     * Choose, which questions to update.
     * 
    **/
    where: questionsWhereUniqueInput
  }


  /**
   * questions updateMany
   */
  export type questionsUpdateManyArgs = {
    data: XOR<questionsUpdateManyMutationInput, questionsUncheckedUpdateManyInput>
    where?: questionsWhereInput
  }


  /**
   * questions upsert
   */
  export type questionsUpsertArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * The filter to search for the questions to update in case it exists.
     * 
    **/
    where: questionsWhereUniqueInput
    /**
     * In case the questions found by the `where` argument doesn't exist, create a new questions with this data.
     * 
    **/
    create: XOR<questionsCreateInput, questionsUncheckedCreateInput>
    /**
     * In case the questions was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<questionsUpdateInput, questionsUncheckedUpdateInput>
  }


  /**
   * questions delete
   */
  export type questionsDeleteArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
    /**
     * Filter which questions to delete.
     * 
    **/
    where: questionsWhereUniqueInput
  }


  /**
   * questions deleteMany
   */
  export type questionsDeleteManyArgs = {
    where?: questionsWhereInput
  }


  /**
   * questions without action
   */
  export type questionsArgs = {
    /**
     * Select specific fields to fetch from the questions
     * 
    **/
    select?: questionsSelect | null
  }



  /**
   * Model customers
   */


  export type AggregateCustomers = {
    _count: CustomersCountAggregateOutputType | null
    _min: CustomersMinAggregateOutputType | null
    _max: CustomersMaxAggregateOutputType | null
  }

  export type CustomersMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
  }

  export type CustomersMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
  }

  export type CustomersCountAggregateOutputType = {
    id: number
    churchId: number
    personId: number
    _all: number
  }


  export type CustomersMinAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
  }

  export type CustomersMaxAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
  }

  export type CustomersCountAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    _all?: true
  }

  export type CustomersAggregateArgs = {
    /**
     * Filter which customers to aggregate.
     * 
    **/
    where?: customersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     * 
    **/
    orderBy?: Enumerable<customersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: customersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned customers
    **/
    _count?: true | CustomersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CustomersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CustomersMaxAggregateInputType
  }

  export type GetCustomersAggregateType<T extends CustomersAggregateArgs> = {
        [P in keyof T & keyof AggregateCustomers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCustomers[P]>
      : GetScalarType<T[P], AggregateCustomers[P]>
  }




  export type CustomersGroupByArgs = {
    where?: customersWhereInput
    orderBy?: Enumerable<customersOrderByWithAggregationInput>
    by: Array<CustomersScalarFieldEnum>
    having?: customersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CustomersCountAggregateInputType | true
    _min?: CustomersMinAggregateInputType
    _max?: CustomersMaxAggregateInputType
  }


  export type CustomersGroupByOutputType = {
    id: string
    churchId: string | null
    personId: string | null
    _count: CustomersCountAggregateOutputType | null
    _min: CustomersMinAggregateOutputType | null
    _max: CustomersMaxAggregateOutputType | null
  }

  type GetCustomersGroupByPayload<T extends CustomersGroupByArgs> = Promise<
    Array<
      PickArray<CustomersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CustomersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CustomersGroupByOutputType[P]>
            : GetScalarType<T[P], CustomersGroupByOutputType[P]>
        }
      >
    >


  export type customersSelect = {
    id?: boolean
    churchId?: boolean
    personId?: boolean
  }

  export type customersGetPayload<
    S extends boolean | null | undefined | customersArgs,
    U = keyof S
      > = S extends true
        ? customers
    : S extends undefined
    ? never
    : S extends customersArgs | customersFindManyArgs
    ?'include' extends U
    ? customers 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof customers ?customers [P]
  : 
     never
  } 
    : customers
  : customers


  type customersCountArgs = Merge<
    Omit<customersFindManyArgs, 'select' | 'include'> & {
      select?: CustomersCountAggregateInputType | true
    }
  >

  export interface customersDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Customers that matches the filter.
     * @param {customersFindUniqueArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends customersFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, customersFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'customers'> extends True ? CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>> : CheckSelect<T, Prisma__customersClient<customers | null >, Prisma__customersClient<customersGetPayload<T> | null >>

    /**
     * Find the first Customers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customersFindFirstArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends customersFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, customersFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'customers'> extends True ? CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>> : CheckSelect<T, Prisma__customersClient<customers | null >, Prisma__customersClient<customersGetPayload<T> | null >>

    /**
     * Find zero or more Customers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customersFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Customers
     * const customers = await prisma.customers.findMany()
     * 
     * // Get first 10 Customers
     * const customers = await prisma.customers.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const customersWithIdOnly = await prisma.customers.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends customersFindManyArgs>(
      args?: SelectSubset<T, customersFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<customers>>, PrismaPromise<Array<customersGetPayload<T>>>>

    /**
     * Create a Customers.
     * @param {customersCreateArgs} args - Arguments to create a Customers.
     * @example
     * // Create one Customers
     * const Customers = await prisma.customers.create({
     *   data: {
     *     // ... data to create a Customers
     *   }
     * })
     * 
    **/
    create<T extends customersCreateArgs>(
      args: SelectSubset<T, customersCreateArgs>
    ): CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>>

    /**
     * Create many Customers.
     *     @param {customersCreateManyArgs} args - Arguments to create many Customers.
     *     @example
     *     // Create many Customers
     *     const customers = await prisma.customers.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends customersCreateManyArgs>(
      args?: SelectSubset<T, customersCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Customers.
     * @param {customersDeleteArgs} args - Arguments to delete one Customers.
     * @example
     * // Delete one Customers
     * const Customers = await prisma.customers.delete({
     *   where: {
     *     // ... filter to delete one Customers
     *   }
     * })
     * 
    **/
    delete<T extends customersDeleteArgs>(
      args: SelectSubset<T, customersDeleteArgs>
    ): CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>>

    /**
     * Update one Customers.
     * @param {customersUpdateArgs} args - Arguments to update one Customers.
     * @example
     * // Update one Customers
     * const customers = await prisma.customers.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends customersUpdateArgs>(
      args: SelectSubset<T, customersUpdateArgs>
    ): CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>>

    /**
     * Delete zero or more Customers.
     * @param {customersDeleteManyArgs} args - Arguments to filter Customers to delete.
     * @example
     * // Delete a few Customers
     * const { count } = await prisma.customers.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends customersDeleteManyArgs>(
      args?: SelectSubset<T, customersDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Customers
     * const customers = await prisma.customers.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends customersUpdateManyArgs>(
      args: SelectSubset<T, customersUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Customers.
     * @param {customersUpsertArgs} args - Arguments to update or create a Customers.
     * @example
     * // Update or create a Customers
     * const customers = await prisma.customers.upsert({
     *   create: {
     *     // ... data to create a Customers
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Customers we want to update
     *   }
     * })
    **/
    upsert<T extends customersUpsertArgs>(
      args: SelectSubset<T, customersUpsertArgs>
    ): CheckSelect<T, Prisma__customersClient<customers>, Prisma__customersClient<customersGetPayload<T>>>

    /**
     * Count the number of Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {customersCountArgs} args - Arguments to filter Customers to count.
     * @example
     * // Count the number of Customers
     * const count = await prisma.customers.count({
     *   where: {
     *     // ... the filter for the Customers we want to count
     *   }
     * })
    **/
    count<T extends customersCountArgs>(
      args?: Subset<T, customersCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CustomersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CustomersAggregateArgs>(args: Subset<T, CustomersAggregateArgs>): PrismaPromise<GetCustomersAggregateType<T>>

    /**
     * Group by Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CustomersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CustomersGroupByArgs['orderBy'] }
        : { orderBy?: CustomersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CustomersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCustomersGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for customers.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__customersClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * customers findUnique
   */
  export type customersFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * Throw an Error if a customers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which customers to fetch.
     * 
    **/
    where: customersWhereUniqueInput
  }


  /**
   * customers findFirst
   */
  export type customersFindFirstArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * Throw an Error if a customers can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which customers to fetch.
     * 
    **/
    where?: customersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     * 
    **/
    orderBy?: Enumerable<customersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for customers.
     * 
    **/
    cursor?: customersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of customers.
     * 
    **/
    distinct?: Enumerable<CustomersScalarFieldEnum>
  }


  /**
   * customers findMany
   */
  export type customersFindManyArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * Filter, which customers to fetch.
     * 
    **/
    where?: customersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of customers to fetch.
     * 
    **/
    orderBy?: Enumerable<customersOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing customers.
     * 
    **/
    cursor?: customersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` customers from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` customers.
     * 
    **/
    skip?: number
    distinct?: Enumerable<CustomersScalarFieldEnum>
  }


  /**
   * customers create
   */
  export type customersCreateArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * The data needed to create a customers.
     * 
    **/
    data: XOR<customersCreateInput, customersUncheckedCreateInput>
  }


  /**
   * customers createMany
   */
  export type customersCreateManyArgs = {
    data: Enumerable<customersCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * customers update
   */
  export type customersUpdateArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * The data needed to update a customers.
     * 
    **/
    data: XOR<customersUpdateInput, customersUncheckedUpdateInput>
    /**
     * Choose, which customers to update.
     * 
    **/
    where: customersWhereUniqueInput
  }


  /**
   * customers updateMany
   */
  export type customersUpdateManyArgs = {
    data: XOR<customersUpdateManyMutationInput, customersUncheckedUpdateManyInput>
    where?: customersWhereInput
  }


  /**
   * customers upsert
   */
  export type customersUpsertArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * The filter to search for the customers to update in case it exists.
     * 
    **/
    where: customersWhereUniqueInput
    /**
     * In case the customers found by the `where` argument doesn't exist, create a new customers with this data.
     * 
    **/
    create: XOR<customersCreateInput, customersUncheckedCreateInput>
    /**
     * In case the customers was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<customersUpdateInput, customersUncheckedUpdateInput>
  }


  /**
   * customers delete
   */
  export type customersDeleteArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
    /**
     * Filter which customers to delete.
     * 
    **/
    where: customersWhereUniqueInput
  }


  /**
   * customers deleteMany
   */
  export type customersDeleteManyArgs = {
    where?: customersWhereInput
  }


  /**
   * customers without action
   */
  export type customersArgs = {
    /**
     * Select specific fields to fetch from the customers
     * 
    **/
    select?: customersSelect | null
  }



  /**
   * Model donationBatches
   */


  export type AggregateDonationBatches = {
    _count: DonationBatchesCountAggregateOutputType | null
    _min: DonationBatchesMinAggregateOutputType | null
    _max: DonationBatchesMaxAggregateOutputType | null
  }

  export type DonationBatchesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    batchDate: Date | null
  }

  export type DonationBatchesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    batchDate: Date | null
  }

  export type DonationBatchesCountAggregateOutputType = {
    id: number
    churchId: number
    name: number
    batchDate: number
    _all: number
  }


  export type DonationBatchesMinAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    batchDate?: true
  }

  export type DonationBatchesMaxAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    batchDate?: true
  }

  export type DonationBatchesCountAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    batchDate?: true
    _all?: true
  }

  export type DonationBatchesAggregateArgs = {
    /**
     * Filter which donationBatches to aggregate.
     * 
    **/
    where?: donationBatchesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donationBatches to fetch.
     * 
    **/
    orderBy?: Enumerable<donationBatchesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: donationBatchesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donationBatches from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donationBatches.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned donationBatches
    **/
    _count?: true | DonationBatchesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DonationBatchesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DonationBatchesMaxAggregateInputType
  }

  export type GetDonationBatchesAggregateType<T extends DonationBatchesAggregateArgs> = {
        [P in keyof T & keyof AggregateDonationBatches]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDonationBatches[P]>
      : GetScalarType<T[P], AggregateDonationBatches[P]>
  }




  export type DonationBatchesGroupByArgs = {
    where?: donationBatchesWhereInput
    orderBy?: Enumerable<donationBatchesOrderByWithAggregationInput>
    by: Array<DonationBatchesScalarFieldEnum>
    having?: donationBatchesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DonationBatchesCountAggregateInputType | true
    _min?: DonationBatchesMinAggregateInputType
    _max?: DonationBatchesMaxAggregateInputType
  }


  export type DonationBatchesGroupByOutputType = {
    id: string
    churchId: string | null
    name: string | null
    batchDate: Date | null
    _count: DonationBatchesCountAggregateOutputType | null
    _min: DonationBatchesMinAggregateOutputType | null
    _max: DonationBatchesMaxAggregateOutputType | null
  }

  type GetDonationBatchesGroupByPayload<T extends DonationBatchesGroupByArgs> = Promise<
    Array<
      PickArray<DonationBatchesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DonationBatchesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DonationBatchesGroupByOutputType[P]>
            : GetScalarType<T[P], DonationBatchesGroupByOutputType[P]>
        }
      >
    >


  export type donationBatchesSelect = {
    id?: boolean
    churchId?: boolean
    name?: boolean
    batchDate?: boolean
    donations?: boolean | donationsFindManyArgs
    _count?: boolean | DonationBatchesCountOutputTypeArgs
  }

  export type donationBatchesInclude = {
    donations?: boolean | donationsFindManyArgs
    _count?: boolean | DonationBatchesCountOutputTypeArgs
  }

  export type donationBatchesGetPayload<
    S extends boolean | null | undefined | donationBatchesArgs,
    U = keyof S
      > = S extends true
        ? donationBatches
    : S extends undefined
    ? never
    : S extends donationBatchesArgs | donationBatchesFindManyArgs
    ?'include' extends U
    ? donationBatches  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'donations'
        ? Array < donationsGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? DonationBatchesCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof donationBatches ?donationBatches [P]
  : 
          P extends 'donations'
        ? Array < donationsGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? DonationBatchesCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : donationBatches
  : donationBatches


  type donationBatchesCountArgs = Merge<
    Omit<donationBatchesFindManyArgs, 'select' | 'include'> & {
      select?: DonationBatchesCountAggregateInputType | true
    }
  >

  export interface donationBatchesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one DonationBatches that matches the filter.
     * @param {donationBatchesFindUniqueArgs} args - Arguments to find a DonationBatches
     * @example
     * // Get one DonationBatches
     * const donationBatches = await prisma.donationBatches.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends donationBatchesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, donationBatchesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'donationBatches'> extends True ? CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>> : CheckSelect<T, Prisma__donationBatchesClient<donationBatches | null >, Prisma__donationBatchesClient<donationBatchesGetPayload<T> | null >>

    /**
     * Find the first DonationBatches that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationBatchesFindFirstArgs} args - Arguments to find a DonationBatches
     * @example
     * // Get one DonationBatches
     * const donationBatches = await prisma.donationBatches.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends donationBatchesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, donationBatchesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'donationBatches'> extends True ? CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>> : CheckSelect<T, Prisma__donationBatchesClient<donationBatches | null >, Prisma__donationBatchesClient<donationBatchesGetPayload<T> | null >>

    /**
     * Find zero or more DonationBatches that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationBatchesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all DonationBatches
     * const donationBatches = await prisma.donationBatches.findMany()
     * 
     * // Get first 10 DonationBatches
     * const donationBatches = await prisma.donationBatches.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const donationBatchesWithIdOnly = await prisma.donationBatches.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends donationBatchesFindManyArgs>(
      args?: SelectSubset<T, donationBatchesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<donationBatches>>, PrismaPromise<Array<donationBatchesGetPayload<T>>>>

    /**
     * Create a DonationBatches.
     * @param {donationBatchesCreateArgs} args - Arguments to create a DonationBatches.
     * @example
     * // Create one DonationBatches
     * const DonationBatches = await prisma.donationBatches.create({
     *   data: {
     *     // ... data to create a DonationBatches
     *   }
     * })
     * 
    **/
    create<T extends donationBatchesCreateArgs>(
      args: SelectSubset<T, donationBatchesCreateArgs>
    ): CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>>

    /**
     * Create many DonationBatches.
     *     @param {donationBatchesCreateManyArgs} args - Arguments to create many DonationBatches.
     *     @example
     *     // Create many DonationBatches
     *     const donationBatches = await prisma.donationBatches.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends donationBatchesCreateManyArgs>(
      args?: SelectSubset<T, donationBatchesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a DonationBatches.
     * @param {donationBatchesDeleteArgs} args - Arguments to delete one DonationBatches.
     * @example
     * // Delete one DonationBatches
     * const DonationBatches = await prisma.donationBatches.delete({
     *   where: {
     *     // ... filter to delete one DonationBatches
     *   }
     * })
     * 
    **/
    delete<T extends donationBatchesDeleteArgs>(
      args: SelectSubset<T, donationBatchesDeleteArgs>
    ): CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>>

    /**
     * Update one DonationBatches.
     * @param {donationBatchesUpdateArgs} args - Arguments to update one DonationBatches.
     * @example
     * // Update one DonationBatches
     * const donationBatches = await prisma.donationBatches.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends donationBatchesUpdateArgs>(
      args: SelectSubset<T, donationBatchesUpdateArgs>
    ): CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>>

    /**
     * Delete zero or more DonationBatches.
     * @param {donationBatchesDeleteManyArgs} args - Arguments to filter DonationBatches to delete.
     * @example
     * // Delete a few DonationBatches
     * const { count } = await prisma.donationBatches.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends donationBatchesDeleteManyArgs>(
      args?: SelectSubset<T, donationBatchesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more DonationBatches.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationBatchesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many DonationBatches
     * const donationBatches = await prisma.donationBatches.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends donationBatchesUpdateManyArgs>(
      args: SelectSubset<T, donationBatchesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one DonationBatches.
     * @param {donationBatchesUpsertArgs} args - Arguments to update or create a DonationBatches.
     * @example
     * // Update or create a DonationBatches
     * const donationBatches = await prisma.donationBatches.upsert({
     *   create: {
     *     // ... data to create a DonationBatches
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the DonationBatches we want to update
     *   }
     * })
    **/
    upsert<T extends donationBatchesUpsertArgs>(
      args: SelectSubset<T, donationBatchesUpsertArgs>
    ): CheckSelect<T, Prisma__donationBatchesClient<donationBatches>, Prisma__donationBatchesClient<donationBatchesGetPayload<T>>>

    /**
     * Count the number of DonationBatches.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationBatchesCountArgs} args - Arguments to filter DonationBatches to count.
     * @example
     * // Count the number of DonationBatches
     * const count = await prisma.donationBatches.count({
     *   where: {
     *     // ... the filter for the DonationBatches we want to count
     *   }
     * })
    **/
    count<T extends donationBatchesCountArgs>(
      args?: Subset<T, donationBatchesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DonationBatchesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a DonationBatches.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DonationBatchesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DonationBatchesAggregateArgs>(args: Subset<T, DonationBatchesAggregateArgs>): PrismaPromise<GetDonationBatchesAggregateType<T>>

    /**
     * Group by DonationBatches.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DonationBatchesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DonationBatchesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DonationBatchesGroupByArgs['orderBy'] }
        : { orderBy?: DonationBatchesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DonationBatchesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDonationBatchesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for donationBatches.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__donationBatchesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    donations<T extends donationsFindManyArgs = {}>(args?: Subset<T, donationsFindManyArgs>): CheckSelect<T, PrismaPromise<Array<donations>>, PrismaPromise<Array<donationsGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * donationBatches findUnique
   */
  export type donationBatchesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * Throw an Error if a donationBatches can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which donationBatches to fetch.
     * 
    **/
    where: donationBatchesWhereUniqueInput
  }


  /**
   * donationBatches findFirst
   */
  export type donationBatchesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * Throw an Error if a donationBatches can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which donationBatches to fetch.
     * 
    **/
    where?: donationBatchesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donationBatches to fetch.
     * 
    **/
    orderBy?: Enumerable<donationBatchesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for donationBatches.
     * 
    **/
    cursor?: donationBatchesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donationBatches from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donationBatches.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of donationBatches.
     * 
    **/
    distinct?: Enumerable<DonationBatchesScalarFieldEnum>
  }


  /**
   * donationBatches findMany
   */
  export type donationBatchesFindManyArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * Filter, which donationBatches to fetch.
     * 
    **/
    where?: donationBatchesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donationBatches to fetch.
     * 
    **/
    orderBy?: Enumerable<donationBatchesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing donationBatches.
     * 
    **/
    cursor?: donationBatchesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donationBatches from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donationBatches.
     * 
    **/
    skip?: number
    distinct?: Enumerable<DonationBatchesScalarFieldEnum>
  }


  /**
   * donationBatches create
   */
  export type donationBatchesCreateArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * The data needed to create a donationBatches.
     * 
    **/
    data: XOR<donationBatchesCreateInput, donationBatchesUncheckedCreateInput>
  }


  /**
   * donationBatches createMany
   */
  export type donationBatchesCreateManyArgs = {
    data: Enumerable<donationBatchesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * donationBatches update
   */
  export type donationBatchesUpdateArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * The data needed to update a donationBatches.
     * 
    **/
    data: XOR<donationBatchesUpdateInput, donationBatchesUncheckedUpdateInput>
    /**
     * Choose, which donationBatches to update.
     * 
    **/
    where: donationBatchesWhereUniqueInput
  }


  /**
   * donationBatches updateMany
   */
  export type donationBatchesUpdateManyArgs = {
    data: XOR<donationBatchesUpdateManyMutationInput, donationBatchesUncheckedUpdateManyInput>
    where?: donationBatchesWhereInput
  }


  /**
   * donationBatches upsert
   */
  export type donationBatchesUpsertArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * The filter to search for the donationBatches to update in case it exists.
     * 
    **/
    where: donationBatchesWhereUniqueInput
    /**
     * In case the donationBatches found by the `where` argument doesn't exist, create a new donationBatches with this data.
     * 
    **/
    create: XOR<donationBatchesCreateInput, donationBatchesUncheckedCreateInput>
    /**
     * In case the donationBatches was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<donationBatchesUpdateInput, donationBatchesUncheckedUpdateInput>
  }


  /**
   * donationBatches delete
   */
  export type donationBatchesDeleteArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
    /**
     * Filter which donationBatches to delete.
     * 
    **/
    where: donationBatchesWhereUniqueInput
  }


  /**
   * donationBatches deleteMany
   */
  export type donationBatchesDeleteManyArgs = {
    where?: donationBatchesWhereInput
  }


  /**
   * donationBatches without action
   */
  export type donationBatchesArgs = {
    /**
     * Select specific fields to fetch from the donationBatches
     * 
    **/
    select?: donationBatchesSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationBatchesInclude | null
  }



  /**
   * Model donations
   */


  export type AggregateDonations = {
    _count: DonationsCountAggregateOutputType | null
    _avg: DonationsAvgAggregateOutputType | null
    _sum: DonationsSumAggregateOutputType | null
    _min: DonationsMinAggregateOutputType | null
    _max: DonationsMaxAggregateOutputType | null
  }

  export type DonationsAvgAggregateOutputType = {
    amount: number | null
  }

  export type DonationsSumAggregateOutputType = {
    amount: number | null
  }

  export type DonationsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    batchId: string | null
    personId: string | null
    donationDate: Date | null
    amount: number | null
    method: string | null
    methodDetails: string | null
    notes: string | null
  }

  export type DonationsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    batchId: string | null
    personId: string | null
    donationDate: Date | null
    amount: number | null
    method: string | null
    methodDetails: string | null
    notes: string | null
  }

  export type DonationsCountAggregateOutputType = {
    id: number
    churchId: number
    batchId: number
    personId: number
    donationDate: number
    amount: number
    method: number
    methodDetails: number
    notes: number
    _all: number
  }


  export type DonationsAvgAggregateInputType = {
    amount?: true
  }

  export type DonationsSumAggregateInputType = {
    amount?: true
  }

  export type DonationsMinAggregateInputType = {
    id?: true
    churchId?: true
    batchId?: true
    personId?: true
    donationDate?: true
    amount?: true
    method?: true
    methodDetails?: true
    notes?: true
  }

  export type DonationsMaxAggregateInputType = {
    id?: true
    churchId?: true
    batchId?: true
    personId?: true
    donationDate?: true
    amount?: true
    method?: true
    methodDetails?: true
    notes?: true
  }

  export type DonationsCountAggregateInputType = {
    id?: true
    churchId?: true
    batchId?: true
    personId?: true
    donationDate?: true
    amount?: true
    method?: true
    methodDetails?: true
    notes?: true
    _all?: true
  }

  export type DonationsAggregateArgs = {
    /**
     * Filter which donations to aggregate.
     * 
    **/
    where?: donationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donations to fetch.
     * 
    **/
    orderBy?: Enumerable<donationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: donationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donations.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned donations
    **/
    _count?: true | DonationsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: DonationsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: DonationsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DonationsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DonationsMaxAggregateInputType
  }

  export type GetDonationsAggregateType<T extends DonationsAggregateArgs> = {
        [P in keyof T & keyof AggregateDonations]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDonations[P]>
      : GetScalarType<T[P], AggregateDonations[P]>
  }




  export type DonationsGroupByArgs = {
    where?: donationsWhereInput
    orderBy?: Enumerable<donationsOrderByWithAggregationInput>
    by: Array<DonationsScalarFieldEnum>
    having?: donationsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DonationsCountAggregateInputType | true
    _avg?: DonationsAvgAggregateInputType
    _sum?: DonationsSumAggregateInputType
    _min?: DonationsMinAggregateInputType
    _max?: DonationsMaxAggregateInputType
  }


  export type DonationsGroupByOutputType = {
    id: string
    churchId: string | null
    batchId: string | null
    personId: string | null
    donationDate: Date | null
    amount: number | null
    method: string | null
    methodDetails: string | null
    notes: string | null
    _count: DonationsCountAggregateOutputType | null
    _avg: DonationsAvgAggregateOutputType | null
    _sum: DonationsSumAggregateOutputType | null
    _min: DonationsMinAggregateOutputType | null
    _max: DonationsMaxAggregateOutputType | null
  }

  type GetDonationsGroupByPayload<T extends DonationsGroupByArgs> = Promise<
    Array<
      PickArray<DonationsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DonationsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DonationsGroupByOutputType[P]>
            : GetScalarType<T[P], DonationsGroupByOutputType[P]>
        }
      >
    >


  export type donationsSelect = {
    id?: boolean
    churchId?: boolean
    batchId?: boolean
    personId?: boolean
    donationDate?: boolean
    amount?: boolean
    method?: boolean
    methodDetails?: boolean
    notes?: boolean
    donationBatches?: boolean | donationBatchesArgs
    fundDonations?: boolean | fundDonationsFindManyArgs
    _count?: boolean | DonationsCountOutputTypeArgs
  }

  export type donationsInclude = {
    donationBatches?: boolean | donationBatchesArgs
    fundDonations?: boolean | fundDonationsFindManyArgs
    _count?: boolean | DonationsCountOutputTypeArgs
  }

  export type donationsGetPayload<
    S extends boolean | null | undefined | donationsArgs,
    U = keyof S
      > = S extends true
        ? donations
    : S extends undefined
    ? never
    : S extends donationsArgs | donationsFindManyArgs
    ?'include' extends U
    ? donations  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'donationBatches'
        ? donationBatchesGetPayload<S['include'][P]> | null :
        P extends 'fundDonations'
        ? Array < fundDonationsGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? DonationsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof donations ?donations [P]
  : 
          P extends 'donationBatches'
        ? donationBatchesGetPayload<S['select'][P]> | null :
        P extends 'fundDonations'
        ? Array < fundDonationsGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? DonationsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : donations
  : donations


  type donationsCountArgs = Merge<
    Omit<donationsFindManyArgs, 'select' | 'include'> & {
      select?: DonationsCountAggregateInputType | true
    }
  >

  export interface donationsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Donations that matches the filter.
     * @param {donationsFindUniqueArgs} args - Arguments to find a Donations
     * @example
     * // Get one Donations
     * const donations = await prisma.donations.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends donationsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, donationsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'donations'> extends True ? CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>> : CheckSelect<T, Prisma__donationsClient<donations | null >, Prisma__donationsClient<donationsGetPayload<T> | null >>

    /**
     * Find the first Donations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationsFindFirstArgs} args - Arguments to find a Donations
     * @example
     * // Get one Donations
     * const donations = await prisma.donations.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends donationsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, donationsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'donations'> extends True ? CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>> : CheckSelect<T, Prisma__donationsClient<donations | null >, Prisma__donationsClient<donationsGetPayload<T> | null >>

    /**
     * Find zero or more Donations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Donations
     * const donations = await prisma.donations.findMany()
     * 
     * // Get first 10 Donations
     * const donations = await prisma.donations.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const donationsWithIdOnly = await prisma.donations.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends donationsFindManyArgs>(
      args?: SelectSubset<T, donationsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<donations>>, PrismaPromise<Array<donationsGetPayload<T>>>>

    /**
     * Create a Donations.
     * @param {donationsCreateArgs} args - Arguments to create a Donations.
     * @example
     * // Create one Donations
     * const Donations = await prisma.donations.create({
     *   data: {
     *     // ... data to create a Donations
     *   }
     * })
     * 
    **/
    create<T extends donationsCreateArgs>(
      args: SelectSubset<T, donationsCreateArgs>
    ): CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>>

    /**
     * Create many Donations.
     *     @param {donationsCreateManyArgs} args - Arguments to create many Donations.
     *     @example
     *     // Create many Donations
     *     const donations = await prisma.donations.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends donationsCreateManyArgs>(
      args?: SelectSubset<T, donationsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Donations.
     * @param {donationsDeleteArgs} args - Arguments to delete one Donations.
     * @example
     * // Delete one Donations
     * const Donations = await prisma.donations.delete({
     *   where: {
     *     // ... filter to delete one Donations
     *   }
     * })
     * 
    **/
    delete<T extends donationsDeleteArgs>(
      args: SelectSubset<T, donationsDeleteArgs>
    ): CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>>

    /**
     * Update one Donations.
     * @param {donationsUpdateArgs} args - Arguments to update one Donations.
     * @example
     * // Update one Donations
     * const donations = await prisma.donations.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends donationsUpdateArgs>(
      args: SelectSubset<T, donationsUpdateArgs>
    ): CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>>

    /**
     * Delete zero or more Donations.
     * @param {donationsDeleteManyArgs} args - Arguments to filter Donations to delete.
     * @example
     * // Delete a few Donations
     * const { count } = await prisma.donations.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends donationsDeleteManyArgs>(
      args?: SelectSubset<T, donationsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Donations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Donations
     * const donations = await prisma.donations.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends donationsUpdateManyArgs>(
      args: SelectSubset<T, donationsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Donations.
     * @param {donationsUpsertArgs} args - Arguments to update or create a Donations.
     * @example
     * // Update or create a Donations
     * const donations = await prisma.donations.upsert({
     *   create: {
     *     // ... data to create a Donations
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Donations we want to update
     *   }
     * })
    **/
    upsert<T extends donationsUpsertArgs>(
      args: SelectSubset<T, donationsUpsertArgs>
    ): CheckSelect<T, Prisma__donationsClient<donations>, Prisma__donationsClient<donationsGetPayload<T>>>

    /**
     * Count the number of Donations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {donationsCountArgs} args - Arguments to filter Donations to count.
     * @example
     * // Count the number of Donations
     * const count = await prisma.donations.count({
     *   where: {
     *     // ... the filter for the Donations we want to count
     *   }
     * })
    **/
    count<T extends donationsCountArgs>(
      args?: Subset<T, donationsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DonationsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Donations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DonationsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DonationsAggregateArgs>(args: Subset<T, DonationsAggregateArgs>): PrismaPromise<GetDonationsAggregateType<T>>

    /**
     * Group by Donations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DonationsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DonationsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DonationsGroupByArgs['orderBy'] }
        : { orderBy?: DonationsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DonationsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDonationsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for donations.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__donationsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    donationBatches<T extends donationBatchesArgs = {}>(args?: Subset<T, donationBatchesArgs>): CheckSelect<T, Prisma__donationBatchesClient<donationBatches | null >, Prisma__donationBatchesClient<donationBatchesGetPayload<T> | null >>;

    fundDonations<T extends fundDonationsFindManyArgs = {}>(args?: Subset<T, fundDonationsFindManyArgs>): CheckSelect<T, PrismaPromise<Array<fundDonations>>, PrismaPromise<Array<fundDonationsGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * donations findUnique
   */
  export type donationsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * Throw an Error if a donations can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which donations to fetch.
     * 
    **/
    where: donationsWhereUniqueInput
  }


  /**
   * donations findFirst
   */
  export type donationsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * Throw an Error if a donations can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which donations to fetch.
     * 
    **/
    where?: donationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donations to fetch.
     * 
    **/
    orderBy?: Enumerable<donationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for donations.
     * 
    **/
    cursor?: donationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donations.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of donations.
     * 
    **/
    distinct?: Enumerable<DonationsScalarFieldEnum>
  }


  /**
   * donations findMany
   */
  export type donationsFindManyArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * Filter, which donations to fetch.
     * 
    **/
    where?: donationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of donations to fetch.
     * 
    **/
    orderBy?: Enumerable<donationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing donations.
     * 
    **/
    cursor?: donationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` donations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` donations.
     * 
    **/
    skip?: number
    distinct?: Enumerable<DonationsScalarFieldEnum>
  }


  /**
   * donations create
   */
  export type donationsCreateArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * The data needed to create a donations.
     * 
    **/
    data: XOR<donationsCreateInput, donationsUncheckedCreateInput>
  }


  /**
   * donations createMany
   */
  export type donationsCreateManyArgs = {
    data: Enumerable<donationsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * donations update
   */
  export type donationsUpdateArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * The data needed to update a donations.
     * 
    **/
    data: XOR<donationsUpdateInput, donationsUncheckedUpdateInput>
    /**
     * Choose, which donations to update.
     * 
    **/
    where: donationsWhereUniqueInput
  }


  /**
   * donations updateMany
   */
  export type donationsUpdateManyArgs = {
    data: XOR<donationsUpdateManyMutationInput, donationsUncheckedUpdateManyInput>
    where?: donationsWhereInput
  }


  /**
   * donations upsert
   */
  export type donationsUpsertArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * The filter to search for the donations to update in case it exists.
     * 
    **/
    where: donationsWhereUniqueInput
    /**
     * In case the donations found by the `where` argument doesn't exist, create a new donations with this data.
     * 
    **/
    create: XOR<donationsCreateInput, donationsUncheckedCreateInput>
    /**
     * In case the donations was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<donationsUpdateInput, donationsUncheckedUpdateInput>
  }


  /**
   * donations delete
   */
  export type donationsDeleteArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
    /**
     * Filter which donations to delete.
     * 
    **/
    where: donationsWhereUniqueInput
  }


  /**
   * donations deleteMany
   */
  export type donationsDeleteManyArgs = {
    where?: donationsWhereInput
  }


  /**
   * donations without action
   */
  export type donationsArgs = {
    /**
     * Select specific fields to fetch from the donations
     * 
    **/
    select?: donationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: donationsInclude | null
  }



  /**
   * Model eventLogs
   */


  export type AggregateEventLogs = {
    _count: EventLogsCountAggregateOutputType | null
    _min: EventLogsMinAggregateOutputType | null
    _max: EventLogsMaxAggregateOutputType | null
  }

  export type EventLogsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    customerId: string | null
    provider: string | null
    status: string | null
    eventType: string | null
    message: string | null
    created: Date | null
    resolved: boolean | null
  }

  export type EventLogsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    customerId: string | null
    provider: string | null
    status: string | null
    eventType: string | null
    message: string | null
    created: Date | null
    resolved: boolean | null
  }

  export type EventLogsCountAggregateOutputType = {
    id: number
    churchId: number
    customerId: number
    provider: number
    status: number
    eventType: number
    message: number
    created: number
    resolved: number
    _all: number
  }


  export type EventLogsMinAggregateInputType = {
    id?: true
    churchId?: true
    customerId?: true
    provider?: true
    status?: true
    eventType?: true
    message?: true
    created?: true
    resolved?: true
  }

  export type EventLogsMaxAggregateInputType = {
    id?: true
    churchId?: true
    customerId?: true
    provider?: true
    status?: true
    eventType?: true
    message?: true
    created?: true
    resolved?: true
  }

  export type EventLogsCountAggregateInputType = {
    id?: true
    churchId?: true
    customerId?: true
    provider?: true
    status?: true
    eventType?: true
    message?: true
    created?: true
    resolved?: true
    _all?: true
  }

  export type EventLogsAggregateArgs = {
    /**
     * Filter which eventLogs to aggregate.
     * 
    **/
    where?: eventLogsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventLogs to fetch.
     * 
    **/
    orderBy?: Enumerable<eventLogsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: eventLogsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventLogs from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventLogs.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eventLogs
    **/
    _count?: true | EventLogsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EventLogsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EventLogsMaxAggregateInputType
  }

  export type GetEventLogsAggregateType<T extends EventLogsAggregateArgs> = {
        [P in keyof T & keyof AggregateEventLogs]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEventLogs[P]>
      : GetScalarType<T[P], AggregateEventLogs[P]>
  }




  export type EventLogsGroupByArgs = {
    where?: eventLogsWhereInput
    orderBy?: Enumerable<eventLogsOrderByWithAggregationInput>
    by: Array<EventLogsScalarFieldEnum>
    having?: eventLogsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EventLogsCountAggregateInputType | true
    _min?: EventLogsMinAggregateInputType
    _max?: EventLogsMaxAggregateInputType
  }


  export type EventLogsGroupByOutputType = {
    id: string
    churchId: string | null
    customerId: string | null
    provider: string | null
    status: string | null
    eventType: string | null
    message: string | null
    created: Date | null
    resolved: boolean | null
    _count: EventLogsCountAggregateOutputType | null
    _min: EventLogsMinAggregateOutputType | null
    _max: EventLogsMaxAggregateOutputType | null
  }

  type GetEventLogsGroupByPayload<T extends EventLogsGroupByArgs> = Promise<
    Array<
      PickArray<EventLogsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EventLogsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EventLogsGroupByOutputType[P]>
            : GetScalarType<T[P], EventLogsGroupByOutputType[P]>
        }
      >
    >


  export type eventLogsSelect = {
    id?: boolean
    churchId?: boolean
    customerId?: boolean
    provider?: boolean
    status?: boolean
    eventType?: boolean
    message?: boolean
    created?: boolean
    resolved?: boolean
  }

  export type eventLogsGetPayload<
    S extends boolean | null | undefined | eventLogsArgs,
    U = keyof S
      > = S extends true
        ? eventLogs
    : S extends undefined
    ? never
    : S extends eventLogsArgs | eventLogsFindManyArgs
    ?'include' extends U
    ? eventLogs 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof eventLogs ?eventLogs [P]
  : 
     never
  } 
    : eventLogs
  : eventLogs


  type eventLogsCountArgs = Merge<
    Omit<eventLogsFindManyArgs, 'select' | 'include'> & {
      select?: EventLogsCountAggregateInputType | true
    }
  >

  export interface eventLogsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one EventLogs that matches the filter.
     * @param {eventLogsFindUniqueArgs} args - Arguments to find a EventLogs
     * @example
     * // Get one EventLogs
     * const eventLogs = await prisma.eventLogs.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends eventLogsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, eventLogsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'eventLogs'> extends True ? CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>> : CheckSelect<T, Prisma__eventLogsClient<eventLogs | null >, Prisma__eventLogsClient<eventLogsGetPayload<T> | null >>

    /**
     * Find the first EventLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventLogsFindFirstArgs} args - Arguments to find a EventLogs
     * @example
     * // Get one EventLogs
     * const eventLogs = await prisma.eventLogs.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends eventLogsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, eventLogsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'eventLogs'> extends True ? CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>> : CheckSelect<T, Prisma__eventLogsClient<eventLogs | null >, Prisma__eventLogsClient<eventLogsGetPayload<T> | null >>

    /**
     * Find zero or more EventLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventLogsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all EventLogs
     * const eventLogs = await prisma.eventLogs.findMany()
     * 
     * // Get first 10 EventLogs
     * const eventLogs = await prisma.eventLogs.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const eventLogsWithIdOnly = await prisma.eventLogs.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends eventLogsFindManyArgs>(
      args?: SelectSubset<T, eventLogsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<eventLogs>>, PrismaPromise<Array<eventLogsGetPayload<T>>>>

    /**
     * Create a EventLogs.
     * @param {eventLogsCreateArgs} args - Arguments to create a EventLogs.
     * @example
     * // Create one EventLogs
     * const EventLogs = await prisma.eventLogs.create({
     *   data: {
     *     // ... data to create a EventLogs
     *   }
     * })
     * 
    **/
    create<T extends eventLogsCreateArgs>(
      args: SelectSubset<T, eventLogsCreateArgs>
    ): CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>>

    /**
     * Create many EventLogs.
     *     @param {eventLogsCreateManyArgs} args - Arguments to create many EventLogs.
     *     @example
     *     // Create many EventLogs
     *     const eventLogs = await prisma.eventLogs.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends eventLogsCreateManyArgs>(
      args?: SelectSubset<T, eventLogsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a EventLogs.
     * @param {eventLogsDeleteArgs} args - Arguments to delete one EventLogs.
     * @example
     * // Delete one EventLogs
     * const EventLogs = await prisma.eventLogs.delete({
     *   where: {
     *     // ... filter to delete one EventLogs
     *   }
     * })
     * 
    **/
    delete<T extends eventLogsDeleteArgs>(
      args: SelectSubset<T, eventLogsDeleteArgs>
    ): CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>>

    /**
     * Update one EventLogs.
     * @param {eventLogsUpdateArgs} args - Arguments to update one EventLogs.
     * @example
     * // Update one EventLogs
     * const eventLogs = await prisma.eventLogs.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends eventLogsUpdateArgs>(
      args: SelectSubset<T, eventLogsUpdateArgs>
    ): CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>>

    /**
     * Delete zero or more EventLogs.
     * @param {eventLogsDeleteManyArgs} args - Arguments to filter EventLogs to delete.
     * @example
     * // Delete a few EventLogs
     * const { count } = await prisma.eventLogs.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends eventLogsDeleteManyArgs>(
      args?: SelectSubset<T, eventLogsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more EventLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventLogsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many EventLogs
     * const eventLogs = await prisma.eventLogs.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends eventLogsUpdateManyArgs>(
      args: SelectSubset<T, eventLogsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one EventLogs.
     * @param {eventLogsUpsertArgs} args - Arguments to update or create a EventLogs.
     * @example
     * // Update or create a EventLogs
     * const eventLogs = await prisma.eventLogs.upsert({
     *   create: {
     *     // ... data to create a EventLogs
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the EventLogs we want to update
     *   }
     * })
    **/
    upsert<T extends eventLogsUpsertArgs>(
      args: SelectSubset<T, eventLogsUpsertArgs>
    ): CheckSelect<T, Prisma__eventLogsClient<eventLogs>, Prisma__eventLogsClient<eventLogsGetPayload<T>>>

    /**
     * Count the number of EventLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventLogsCountArgs} args - Arguments to filter EventLogs to count.
     * @example
     * // Count the number of EventLogs
     * const count = await prisma.eventLogs.count({
     *   where: {
     *     // ... the filter for the EventLogs we want to count
     *   }
     * })
    **/
    count<T extends eventLogsCountArgs>(
      args?: Subset<T, eventLogsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EventLogsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a EventLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventLogsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EventLogsAggregateArgs>(args: Subset<T, EventLogsAggregateArgs>): PrismaPromise<GetEventLogsAggregateType<T>>

    /**
     * Group by EventLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventLogsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EventLogsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EventLogsGroupByArgs['orderBy'] }
        : { orderBy?: EventLogsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EventLogsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEventLogsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for eventLogs.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__eventLogsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * eventLogs findUnique
   */
  export type eventLogsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * Throw an Error if a eventLogs can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which eventLogs to fetch.
     * 
    **/
    where: eventLogsWhereUniqueInput
  }


  /**
   * eventLogs findFirst
   */
  export type eventLogsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * Throw an Error if a eventLogs can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which eventLogs to fetch.
     * 
    **/
    where?: eventLogsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventLogs to fetch.
     * 
    **/
    orderBy?: Enumerable<eventLogsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eventLogs.
     * 
    **/
    cursor?: eventLogsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventLogs from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventLogs.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eventLogs.
     * 
    **/
    distinct?: Enumerable<EventLogsScalarFieldEnum>
  }


  /**
   * eventLogs findMany
   */
  export type eventLogsFindManyArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * Filter, which eventLogs to fetch.
     * 
    **/
    where?: eventLogsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventLogs to fetch.
     * 
    **/
    orderBy?: Enumerable<eventLogsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eventLogs.
     * 
    **/
    cursor?: eventLogsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventLogs from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventLogs.
     * 
    **/
    skip?: number
    distinct?: Enumerable<EventLogsScalarFieldEnum>
  }


  /**
   * eventLogs create
   */
  export type eventLogsCreateArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * The data needed to create a eventLogs.
     * 
    **/
    data: XOR<eventLogsCreateInput, eventLogsUncheckedCreateInput>
  }


  /**
   * eventLogs createMany
   */
  export type eventLogsCreateManyArgs = {
    data: Enumerable<eventLogsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * eventLogs update
   */
  export type eventLogsUpdateArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * The data needed to update a eventLogs.
     * 
    **/
    data: XOR<eventLogsUpdateInput, eventLogsUncheckedUpdateInput>
    /**
     * Choose, which eventLogs to update.
     * 
    **/
    where: eventLogsWhereUniqueInput
  }


  /**
   * eventLogs updateMany
   */
  export type eventLogsUpdateManyArgs = {
    data: XOR<eventLogsUpdateManyMutationInput, eventLogsUncheckedUpdateManyInput>
    where?: eventLogsWhereInput
  }


  /**
   * eventLogs upsert
   */
  export type eventLogsUpsertArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * The filter to search for the eventLogs to update in case it exists.
     * 
    **/
    where: eventLogsWhereUniqueInput
    /**
     * In case the eventLogs found by the `where` argument doesn't exist, create a new eventLogs with this data.
     * 
    **/
    create: XOR<eventLogsCreateInput, eventLogsUncheckedCreateInput>
    /**
     * In case the eventLogs was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<eventLogsUpdateInput, eventLogsUncheckedUpdateInput>
  }


  /**
   * eventLogs delete
   */
  export type eventLogsDeleteArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
    /**
     * Filter which eventLogs to delete.
     * 
    **/
    where: eventLogsWhereUniqueInput
  }


  /**
   * eventLogs deleteMany
   */
  export type eventLogsDeleteManyArgs = {
    where?: eventLogsWhereInput
  }


  /**
   * eventLogs without action
   */
  export type eventLogsArgs = {
    /**
     * Select specific fields to fetch from the eventLogs
     * 
    **/
    select?: eventLogsSelect | null
  }



  /**
   * Model fundDonations
   */


  export type AggregateFundDonations = {
    _count: FundDonationsCountAggregateOutputType | null
    _avg: FundDonationsAvgAggregateOutputType | null
    _sum: FundDonationsSumAggregateOutputType | null
    _min: FundDonationsMinAggregateOutputType | null
    _max: FundDonationsMaxAggregateOutputType | null
  }

  export type FundDonationsAvgAggregateOutputType = {
    amount: number | null
  }

  export type FundDonationsSumAggregateOutputType = {
    amount: number | null
  }

  export type FundDonationsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    donationId: string | null
    fundId: string | null
    amount: number | null
  }

  export type FundDonationsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    donationId: string | null
    fundId: string | null
    amount: number | null
  }

  export type FundDonationsCountAggregateOutputType = {
    id: number
    churchId: number
    donationId: number
    fundId: number
    amount: number
    _all: number
  }


  export type FundDonationsAvgAggregateInputType = {
    amount?: true
  }

  export type FundDonationsSumAggregateInputType = {
    amount?: true
  }

  export type FundDonationsMinAggregateInputType = {
    id?: true
    churchId?: true
    donationId?: true
    fundId?: true
    amount?: true
  }

  export type FundDonationsMaxAggregateInputType = {
    id?: true
    churchId?: true
    donationId?: true
    fundId?: true
    amount?: true
  }

  export type FundDonationsCountAggregateInputType = {
    id?: true
    churchId?: true
    donationId?: true
    fundId?: true
    amount?: true
    _all?: true
  }

  export type FundDonationsAggregateArgs = {
    /**
     * Filter which fundDonations to aggregate.
     * 
    **/
    where?: fundDonationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of fundDonations to fetch.
     * 
    **/
    orderBy?: Enumerable<fundDonationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: fundDonationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` fundDonations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` fundDonations.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned fundDonations
    **/
    _count?: true | FundDonationsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: FundDonationsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: FundDonationsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FundDonationsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FundDonationsMaxAggregateInputType
  }

  export type GetFundDonationsAggregateType<T extends FundDonationsAggregateArgs> = {
        [P in keyof T & keyof AggregateFundDonations]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFundDonations[P]>
      : GetScalarType<T[P], AggregateFundDonations[P]>
  }




  export type FundDonationsGroupByArgs = {
    where?: fundDonationsWhereInput
    orderBy?: Enumerable<fundDonationsOrderByWithAggregationInput>
    by: Array<FundDonationsScalarFieldEnum>
    having?: fundDonationsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FundDonationsCountAggregateInputType | true
    _avg?: FundDonationsAvgAggregateInputType
    _sum?: FundDonationsSumAggregateInputType
    _min?: FundDonationsMinAggregateInputType
    _max?: FundDonationsMaxAggregateInputType
  }


  export type FundDonationsGroupByOutputType = {
    id: string
    churchId: string | null
    donationId: string | null
    fundId: string | null
    amount: number | null
    _count: FundDonationsCountAggregateOutputType | null
    _avg: FundDonationsAvgAggregateOutputType | null
    _sum: FundDonationsSumAggregateOutputType | null
    _min: FundDonationsMinAggregateOutputType | null
    _max: FundDonationsMaxAggregateOutputType | null
  }

  type GetFundDonationsGroupByPayload<T extends FundDonationsGroupByArgs> = Promise<
    Array<
      PickArray<FundDonationsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FundDonationsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FundDonationsGroupByOutputType[P]>
            : GetScalarType<T[P], FundDonationsGroupByOutputType[P]>
        }
      >
    >


  export type fundDonationsSelect = {
    id?: boolean
    churchId?: boolean
    donationId?: boolean
    fundId?: boolean
    amount?: boolean
    fund?: boolean | fundsArgs
    donation?: boolean | donationsArgs
  }

  export type fundDonationsInclude = {
    fund?: boolean | fundsArgs
    donation?: boolean | donationsArgs
  }

  export type fundDonationsGetPayload<
    S extends boolean | null | undefined | fundDonationsArgs,
    U = keyof S
      > = S extends true
        ? fundDonations
    : S extends undefined
    ? never
    : S extends fundDonationsArgs | fundDonationsFindManyArgs
    ?'include' extends U
    ? fundDonations  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'fund'
        ? fundsGetPayload<S['include'][P]> | null :
        P extends 'donation'
        ? donationsGetPayload<S['include'][P]> | null : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof fundDonations ?fundDonations [P]
  : 
          P extends 'fund'
        ? fundsGetPayload<S['select'][P]> | null :
        P extends 'donation'
        ? donationsGetPayload<S['select'][P]> | null : never
  } 
    : fundDonations
  : fundDonations


  type fundDonationsCountArgs = Merge<
    Omit<fundDonationsFindManyArgs, 'select' | 'include'> & {
      select?: FundDonationsCountAggregateInputType | true
    }
  >

  export interface fundDonationsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one FundDonations that matches the filter.
     * @param {fundDonationsFindUniqueArgs} args - Arguments to find a FundDonations
     * @example
     * // Get one FundDonations
     * const fundDonations = await prisma.fundDonations.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends fundDonationsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, fundDonationsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'fundDonations'> extends True ? CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>> : CheckSelect<T, Prisma__fundDonationsClient<fundDonations | null >, Prisma__fundDonationsClient<fundDonationsGetPayload<T> | null >>

    /**
     * Find the first FundDonations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundDonationsFindFirstArgs} args - Arguments to find a FundDonations
     * @example
     * // Get one FundDonations
     * const fundDonations = await prisma.fundDonations.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends fundDonationsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, fundDonationsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'fundDonations'> extends True ? CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>> : CheckSelect<T, Prisma__fundDonationsClient<fundDonations | null >, Prisma__fundDonationsClient<fundDonationsGetPayload<T> | null >>

    /**
     * Find zero or more FundDonations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundDonationsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all FundDonations
     * const fundDonations = await prisma.fundDonations.findMany()
     * 
     * // Get first 10 FundDonations
     * const fundDonations = await prisma.fundDonations.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const fundDonationsWithIdOnly = await prisma.fundDonations.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends fundDonationsFindManyArgs>(
      args?: SelectSubset<T, fundDonationsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<fundDonations>>, PrismaPromise<Array<fundDonationsGetPayload<T>>>>

    /**
     * Create a FundDonations.
     * @param {fundDonationsCreateArgs} args - Arguments to create a FundDonations.
     * @example
     * // Create one FundDonations
     * const FundDonations = await prisma.fundDonations.create({
     *   data: {
     *     // ... data to create a FundDonations
     *   }
     * })
     * 
    **/
    create<T extends fundDonationsCreateArgs>(
      args: SelectSubset<T, fundDonationsCreateArgs>
    ): CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>>

    /**
     * Create many FundDonations.
     *     @param {fundDonationsCreateManyArgs} args - Arguments to create many FundDonations.
     *     @example
     *     // Create many FundDonations
     *     const fundDonations = await prisma.fundDonations.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends fundDonationsCreateManyArgs>(
      args?: SelectSubset<T, fundDonationsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a FundDonations.
     * @param {fundDonationsDeleteArgs} args - Arguments to delete one FundDonations.
     * @example
     * // Delete one FundDonations
     * const FundDonations = await prisma.fundDonations.delete({
     *   where: {
     *     // ... filter to delete one FundDonations
     *   }
     * })
     * 
    **/
    delete<T extends fundDonationsDeleteArgs>(
      args: SelectSubset<T, fundDonationsDeleteArgs>
    ): CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>>

    /**
     * Update one FundDonations.
     * @param {fundDonationsUpdateArgs} args - Arguments to update one FundDonations.
     * @example
     * // Update one FundDonations
     * const fundDonations = await prisma.fundDonations.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends fundDonationsUpdateArgs>(
      args: SelectSubset<T, fundDonationsUpdateArgs>
    ): CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>>

    /**
     * Delete zero or more FundDonations.
     * @param {fundDonationsDeleteManyArgs} args - Arguments to filter FundDonations to delete.
     * @example
     * // Delete a few FundDonations
     * const { count } = await prisma.fundDonations.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends fundDonationsDeleteManyArgs>(
      args?: SelectSubset<T, fundDonationsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more FundDonations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundDonationsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many FundDonations
     * const fundDonations = await prisma.fundDonations.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends fundDonationsUpdateManyArgs>(
      args: SelectSubset<T, fundDonationsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one FundDonations.
     * @param {fundDonationsUpsertArgs} args - Arguments to update or create a FundDonations.
     * @example
     * // Update or create a FundDonations
     * const fundDonations = await prisma.fundDonations.upsert({
     *   create: {
     *     // ... data to create a FundDonations
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the FundDonations we want to update
     *   }
     * })
    **/
    upsert<T extends fundDonationsUpsertArgs>(
      args: SelectSubset<T, fundDonationsUpsertArgs>
    ): CheckSelect<T, Prisma__fundDonationsClient<fundDonations>, Prisma__fundDonationsClient<fundDonationsGetPayload<T>>>

    /**
     * Count the number of FundDonations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundDonationsCountArgs} args - Arguments to filter FundDonations to count.
     * @example
     * // Count the number of FundDonations
     * const count = await prisma.fundDonations.count({
     *   where: {
     *     // ... the filter for the FundDonations we want to count
     *   }
     * })
    **/
    count<T extends fundDonationsCountArgs>(
      args?: Subset<T, fundDonationsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FundDonationsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a FundDonations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FundDonationsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FundDonationsAggregateArgs>(args: Subset<T, FundDonationsAggregateArgs>): PrismaPromise<GetFundDonationsAggregateType<T>>

    /**
     * Group by FundDonations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FundDonationsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FundDonationsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FundDonationsGroupByArgs['orderBy'] }
        : { orderBy?: FundDonationsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FundDonationsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFundDonationsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for fundDonations.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__fundDonationsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    fund<T extends fundsArgs = {}>(args?: Subset<T, fundsArgs>): CheckSelect<T, Prisma__fundsClient<funds | null >, Prisma__fundsClient<fundsGetPayload<T> | null >>;

    donation<T extends donationsArgs = {}>(args?: Subset<T, donationsArgs>): CheckSelect<T, Prisma__donationsClient<donations | null >, Prisma__donationsClient<donationsGetPayload<T> | null >>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * fundDonations findUnique
   */
  export type fundDonationsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * Throw an Error if a fundDonations can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which fundDonations to fetch.
     * 
    **/
    where: fundDonationsWhereUniqueInput
  }


  /**
   * fundDonations findFirst
   */
  export type fundDonationsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * Throw an Error if a fundDonations can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which fundDonations to fetch.
     * 
    **/
    where?: fundDonationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of fundDonations to fetch.
     * 
    **/
    orderBy?: Enumerable<fundDonationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for fundDonations.
     * 
    **/
    cursor?: fundDonationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` fundDonations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` fundDonations.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of fundDonations.
     * 
    **/
    distinct?: Enumerable<FundDonationsScalarFieldEnum>
  }


  /**
   * fundDonations findMany
   */
  export type fundDonationsFindManyArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * Filter, which fundDonations to fetch.
     * 
    **/
    where?: fundDonationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of fundDonations to fetch.
     * 
    **/
    orderBy?: Enumerable<fundDonationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing fundDonations.
     * 
    **/
    cursor?: fundDonationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` fundDonations from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` fundDonations.
     * 
    **/
    skip?: number
    distinct?: Enumerable<FundDonationsScalarFieldEnum>
  }


  /**
   * fundDonations create
   */
  export type fundDonationsCreateArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * The data needed to create a fundDonations.
     * 
    **/
    data: XOR<fundDonationsCreateInput, fundDonationsUncheckedCreateInput>
  }


  /**
   * fundDonations createMany
   */
  export type fundDonationsCreateManyArgs = {
    data: Enumerable<fundDonationsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * fundDonations update
   */
  export type fundDonationsUpdateArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * The data needed to update a fundDonations.
     * 
    **/
    data: XOR<fundDonationsUpdateInput, fundDonationsUncheckedUpdateInput>
    /**
     * Choose, which fundDonations to update.
     * 
    **/
    where: fundDonationsWhereUniqueInput
  }


  /**
   * fundDonations updateMany
   */
  export type fundDonationsUpdateManyArgs = {
    data: XOR<fundDonationsUpdateManyMutationInput, fundDonationsUncheckedUpdateManyInput>
    where?: fundDonationsWhereInput
  }


  /**
   * fundDonations upsert
   */
  export type fundDonationsUpsertArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * The filter to search for the fundDonations to update in case it exists.
     * 
    **/
    where: fundDonationsWhereUniqueInput
    /**
     * In case the fundDonations found by the `where` argument doesn't exist, create a new fundDonations with this data.
     * 
    **/
    create: XOR<fundDonationsCreateInput, fundDonationsUncheckedCreateInput>
    /**
     * In case the fundDonations was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<fundDonationsUpdateInput, fundDonationsUncheckedUpdateInput>
  }


  /**
   * fundDonations delete
   */
  export type fundDonationsDeleteArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
    /**
     * Filter which fundDonations to delete.
     * 
    **/
    where: fundDonationsWhereUniqueInput
  }


  /**
   * fundDonations deleteMany
   */
  export type fundDonationsDeleteManyArgs = {
    where?: fundDonationsWhereInput
  }


  /**
   * fundDonations without action
   */
  export type fundDonationsArgs = {
    /**
     * Select specific fields to fetch from the fundDonations
     * 
    **/
    select?: fundDonationsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundDonationsInclude | null
  }



  /**
   * Model funds
   */


  export type AggregateFunds = {
    _count: FundsCountAggregateOutputType | null
    _min: FundsMinAggregateOutputType | null
    _max: FundsMaxAggregateOutputType | null
  }

  export type FundsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    productId: string | null
    removed: boolean | null
  }

  export type FundsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    productId: string | null
    removed: boolean | null
  }

  export type FundsCountAggregateOutputType = {
    id: number
    churchId: number
    name: number
    productId: number
    removed: number
    _all: number
  }


  export type FundsMinAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    productId?: true
    removed?: true
  }

  export type FundsMaxAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    productId?: true
    removed?: true
  }

  export type FundsCountAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    productId?: true
    removed?: true
    _all?: true
  }

  export type FundsAggregateArgs = {
    /**
     * Filter which funds to aggregate.
     * 
    **/
    where?: fundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of funds to fetch.
     * 
    **/
    orderBy?: Enumerable<fundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: fundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` funds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` funds.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned funds
    **/
    _count?: true | FundsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FundsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FundsMaxAggregateInputType
  }

  export type GetFundsAggregateType<T extends FundsAggregateArgs> = {
        [P in keyof T & keyof AggregateFunds]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFunds[P]>
      : GetScalarType<T[P], AggregateFunds[P]>
  }




  export type FundsGroupByArgs = {
    where?: fundsWhereInput
    orderBy?: Enumerable<fundsOrderByWithAggregationInput>
    by: Array<FundsScalarFieldEnum>
    having?: fundsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FundsCountAggregateInputType | true
    _min?: FundsMinAggregateInputType
    _max?: FundsMaxAggregateInputType
  }


  export type FundsGroupByOutputType = {
    id: string
    churchId: string | null
    name: string | null
    productId: string | null
    removed: boolean | null
    _count: FundsCountAggregateOutputType | null
    _min: FundsMinAggregateOutputType | null
    _max: FundsMaxAggregateOutputType | null
  }

  type GetFundsGroupByPayload<T extends FundsGroupByArgs> = Promise<
    Array<
      PickArray<FundsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FundsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FundsGroupByOutputType[P]>
            : GetScalarType<T[P], FundsGroupByOutputType[P]>
        }
      >
    >


  export type fundsSelect = {
    id?: boolean
    churchId?: boolean
    name?: boolean
    productId?: boolean
    removed?: boolean
    fundDonations?: boolean | fundDonationsFindManyArgs
    _count?: boolean | FundsCountOutputTypeArgs
  }

  export type fundsInclude = {
    fundDonations?: boolean | fundDonationsFindManyArgs
    _count?: boolean | FundsCountOutputTypeArgs
  }

  export type fundsGetPayload<
    S extends boolean | null | undefined | fundsArgs,
    U = keyof S
      > = S extends true
        ? funds
    : S extends undefined
    ? never
    : S extends fundsArgs | fundsFindManyArgs
    ?'include' extends U
    ? funds  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'fundDonations'
        ? Array < fundDonationsGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? FundsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof funds ?funds [P]
  : 
          P extends 'fundDonations'
        ? Array < fundDonationsGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? FundsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : funds
  : funds


  type fundsCountArgs = Merge<
    Omit<fundsFindManyArgs, 'select' | 'include'> & {
      select?: FundsCountAggregateInputType | true
    }
  >

  export interface fundsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Funds that matches the filter.
     * @param {fundsFindUniqueArgs} args - Arguments to find a Funds
     * @example
     * // Get one Funds
     * const funds = await prisma.funds.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends fundsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, fundsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'funds'> extends True ? CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>> : CheckSelect<T, Prisma__fundsClient<funds | null >, Prisma__fundsClient<fundsGetPayload<T> | null >>

    /**
     * Find the first Funds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundsFindFirstArgs} args - Arguments to find a Funds
     * @example
     * // Get one Funds
     * const funds = await prisma.funds.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends fundsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, fundsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'funds'> extends True ? CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>> : CheckSelect<T, Prisma__fundsClient<funds | null >, Prisma__fundsClient<fundsGetPayload<T> | null >>

    /**
     * Find zero or more Funds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Funds
     * const funds = await prisma.funds.findMany()
     * 
     * // Get first 10 Funds
     * const funds = await prisma.funds.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const fundsWithIdOnly = await prisma.funds.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends fundsFindManyArgs>(
      args?: SelectSubset<T, fundsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<funds>>, PrismaPromise<Array<fundsGetPayload<T>>>>

    /**
     * Create a Funds.
     * @param {fundsCreateArgs} args - Arguments to create a Funds.
     * @example
     * // Create one Funds
     * const Funds = await prisma.funds.create({
     *   data: {
     *     // ... data to create a Funds
     *   }
     * })
     * 
    **/
    create<T extends fundsCreateArgs>(
      args: SelectSubset<T, fundsCreateArgs>
    ): CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>>

    /**
     * Create many Funds.
     *     @param {fundsCreateManyArgs} args - Arguments to create many Funds.
     *     @example
     *     // Create many Funds
     *     const funds = await prisma.funds.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends fundsCreateManyArgs>(
      args?: SelectSubset<T, fundsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Funds.
     * @param {fundsDeleteArgs} args - Arguments to delete one Funds.
     * @example
     * // Delete one Funds
     * const Funds = await prisma.funds.delete({
     *   where: {
     *     // ... filter to delete one Funds
     *   }
     * })
     * 
    **/
    delete<T extends fundsDeleteArgs>(
      args: SelectSubset<T, fundsDeleteArgs>
    ): CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>>

    /**
     * Update one Funds.
     * @param {fundsUpdateArgs} args - Arguments to update one Funds.
     * @example
     * // Update one Funds
     * const funds = await prisma.funds.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends fundsUpdateArgs>(
      args: SelectSubset<T, fundsUpdateArgs>
    ): CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>>

    /**
     * Delete zero or more Funds.
     * @param {fundsDeleteManyArgs} args - Arguments to filter Funds to delete.
     * @example
     * // Delete a few Funds
     * const { count } = await prisma.funds.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends fundsDeleteManyArgs>(
      args?: SelectSubset<T, fundsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Funds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Funds
     * const funds = await prisma.funds.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends fundsUpdateManyArgs>(
      args: SelectSubset<T, fundsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Funds.
     * @param {fundsUpsertArgs} args - Arguments to update or create a Funds.
     * @example
     * // Update or create a Funds
     * const funds = await prisma.funds.upsert({
     *   create: {
     *     // ... data to create a Funds
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Funds we want to update
     *   }
     * })
    **/
    upsert<T extends fundsUpsertArgs>(
      args: SelectSubset<T, fundsUpsertArgs>
    ): CheckSelect<T, Prisma__fundsClient<funds>, Prisma__fundsClient<fundsGetPayload<T>>>

    /**
     * Count the number of Funds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {fundsCountArgs} args - Arguments to filter Funds to count.
     * @example
     * // Count the number of Funds
     * const count = await prisma.funds.count({
     *   where: {
     *     // ... the filter for the Funds we want to count
     *   }
     * })
    **/
    count<T extends fundsCountArgs>(
      args?: Subset<T, fundsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FundsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Funds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FundsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FundsAggregateArgs>(args: Subset<T, FundsAggregateArgs>): PrismaPromise<GetFundsAggregateType<T>>

    /**
     * Group by Funds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FundsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FundsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FundsGroupByArgs['orderBy'] }
        : { orderBy?: FundsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FundsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFundsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for funds.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__fundsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    fundDonations<T extends fundDonationsFindManyArgs = {}>(args?: Subset<T, fundDonationsFindManyArgs>): CheckSelect<T, PrismaPromise<Array<fundDonations>>, PrismaPromise<Array<fundDonationsGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * funds findUnique
   */
  export type fundsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * Throw an Error if a funds can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which funds to fetch.
     * 
    **/
    where: fundsWhereUniqueInput
  }


  /**
   * funds findFirst
   */
  export type fundsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * Throw an Error if a funds can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which funds to fetch.
     * 
    **/
    where?: fundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of funds to fetch.
     * 
    **/
    orderBy?: Enumerable<fundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for funds.
     * 
    **/
    cursor?: fundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` funds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` funds.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of funds.
     * 
    **/
    distinct?: Enumerable<FundsScalarFieldEnum>
  }


  /**
   * funds findMany
   */
  export type fundsFindManyArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * Filter, which funds to fetch.
     * 
    **/
    where?: fundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of funds to fetch.
     * 
    **/
    orderBy?: Enumerable<fundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing funds.
     * 
    **/
    cursor?: fundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` funds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` funds.
     * 
    **/
    skip?: number
    distinct?: Enumerable<FundsScalarFieldEnum>
  }


  /**
   * funds create
   */
  export type fundsCreateArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * The data needed to create a funds.
     * 
    **/
    data: XOR<fundsCreateInput, fundsUncheckedCreateInput>
  }


  /**
   * funds createMany
   */
  export type fundsCreateManyArgs = {
    data: Enumerable<fundsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * funds update
   */
  export type fundsUpdateArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * The data needed to update a funds.
     * 
    **/
    data: XOR<fundsUpdateInput, fundsUncheckedUpdateInput>
    /**
     * Choose, which funds to update.
     * 
    **/
    where: fundsWhereUniqueInput
  }


  /**
   * funds updateMany
   */
  export type fundsUpdateManyArgs = {
    data: XOR<fundsUpdateManyMutationInput, fundsUncheckedUpdateManyInput>
    where?: fundsWhereInput
  }


  /**
   * funds upsert
   */
  export type fundsUpsertArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * The filter to search for the funds to update in case it exists.
     * 
    **/
    where: fundsWhereUniqueInput
    /**
     * In case the funds found by the `where` argument doesn't exist, create a new funds with this data.
     * 
    **/
    create: XOR<fundsCreateInput, fundsUncheckedCreateInput>
    /**
     * In case the funds was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<fundsUpdateInput, fundsUncheckedUpdateInput>
  }


  /**
   * funds delete
   */
  export type fundsDeleteArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
    /**
     * Filter which funds to delete.
     * 
    **/
    where: fundsWhereUniqueInput
  }


  /**
   * funds deleteMany
   */
  export type fundsDeleteManyArgs = {
    where?: fundsWhereInput
  }


  /**
   * funds without action
   */
  export type fundsArgs = {
    /**
     * Select specific fields to fetch from the funds
     * 
    **/
    select?: fundsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: fundsInclude | null
  }



  /**
   * Model gateways
   */


  export type AggregateGateways = {
    _count: GatewaysCountAggregateOutputType | null
    _min: GatewaysMinAggregateOutputType | null
    _max: GatewaysMaxAggregateOutputType | null
  }

  export type GatewaysMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    provider: string | null
    publicKey: string | null
    privateKey: string | null
    webhookKey: string | null
    productId: string | null
  }

  export type GatewaysMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    provider: string | null
    publicKey: string | null
    privateKey: string | null
    webhookKey: string | null
    productId: string | null
  }

  export type GatewaysCountAggregateOutputType = {
    id: number
    churchId: number
    provider: number
    publicKey: number
    privateKey: number
    webhookKey: number
    productId: number
    _all: number
  }


  export type GatewaysMinAggregateInputType = {
    id?: true
    churchId?: true
    provider?: true
    publicKey?: true
    privateKey?: true
    webhookKey?: true
    productId?: true
  }

  export type GatewaysMaxAggregateInputType = {
    id?: true
    churchId?: true
    provider?: true
    publicKey?: true
    privateKey?: true
    webhookKey?: true
    productId?: true
  }

  export type GatewaysCountAggregateInputType = {
    id?: true
    churchId?: true
    provider?: true
    publicKey?: true
    privateKey?: true
    webhookKey?: true
    productId?: true
    _all?: true
  }

  export type GatewaysAggregateArgs = {
    /**
     * Filter which gateways to aggregate.
     * 
    **/
    where?: gatewaysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of gateways to fetch.
     * 
    **/
    orderBy?: Enumerable<gatewaysOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: gatewaysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` gateways from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` gateways.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned gateways
    **/
    _count?: true | GatewaysCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GatewaysMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GatewaysMaxAggregateInputType
  }

  export type GetGatewaysAggregateType<T extends GatewaysAggregateArgs> = {
        [P in keyof T & keyof AggregateGateways]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGateways[P]>
      : GetScalarType<T[P], AggregateGateways[P]>
  }




  export type GatewaysGroupByArgs = {
    where?: gatewaysWhereInput
    orderBy?: Enumerable<gatewaysOrderByWithAggregationInput>
    by: Array<GatewaysScalarFieldEnum>
    having?: gatewaysScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GatewaysCountAggregateInputType | true
    _min?: GatewaysMinAggregateInputType
    _max?: GatewaysMaxAggregateInputType
  }


  export type GatewaysGroupByOutputType = {
    id: string
    churchId: string | null
    provider: string | null
    publicKey: string | null
    privateKey: string | null
    webhookKey: string | null
    productId: string | null
    _count: GatewaysCountAggregateOutputType | null
    _min: GatewaysMinAggregateOutputType | null
    _max: GatewaysMaxAggregateOutputType | null
  }

  type GetGatewaysGroupByPayload<T extends GatewaysGroupByArgs> = Promise<
    Array<
      PickArray<GatewaysGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GatewaysGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GatewaysGroupByOutputType[P]>
            : GetScalarType<T[P], GatewaysGroupByOutputType[P]>
        }
      >
    >


  export type gatewaysSelect = {
    id?: boolean
    churchId?: boolean
    provider?: boolean
    publicKey?: boolean
    privateKey?: boolean
    webhookKey?: boolean
    productId?: boolean
  }

  export type gatewaysGetPayload<
    S extends boolean | null | undefined | gatewaysArgs,
    U = keyof S
      > = S extends true
        ? gateways
    : S extends undefined
    ? never
    : S extends gatewaysArgs | gatewaysFindManyArgs
    ?'include' extends U
    ? gateways 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof gateways ?gateways [P]
  : 
     never
  } 
    : gateways
  : gateways


  type gatewaysCountArgs = Merge<
    Omit<gatewaysFindManyArgs, 'select' | 'include'> & {
      select?: GatewaysCountAggregateInputType | true
    }
  >

  export interface gatewaysDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Gateways that matches the filter.
     * @param {gatewaysFindUniqueArgs} args - Arguments to find a Gateways
     * @example
     * // Get one Gateways
     * const gateways = await prisma.gateways.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends gatewaysFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, gatewaysFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'gateways'> extends True ? CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>> : CheckSelect<T, Prisma__gatewaysClient<gateways | null >, Prisma__gatewaysClient<gatewaysGetPayload<T> | null >>

    /**
     * Find the first Gateways that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {gatewaysFindFirstArgs} args - Arguments to find a Gateways
     * @example
     * // Get one Gateways
     * const gateways = await prisma.gateways.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends gatewaysFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, gatewaysFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'gateways'> extends True ? CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>> : CheckSelect<T, Prisma__gatewaysClient<gateways | null >, Prisma__gatewaysClient<gatewaysGetPayload<T> | null >>

    /**
     * Find zero or more Gateways that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {gatewaysFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Gateways
     * const gateways = await prisma.gateways.findMany()
     * 
     * // Get first 10 Gateways
     * const gateways = await prisma.gateways.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const gatewaysWithIdOnly = await prisma.gateways.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends gatewaysFindManyArgs>(
      args?: SelectSubset<T, gatewaysFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<gateways>>, PrismaPromise<Array<gatewaysGetPayload<T>>>>

    /**
     * Create a Gateways.
     * @param {gatewaysCreateArgs} args - Arguments to create a Gateways.
     * @example
     * // Create one Gateways
     * const Gateways = await prisma.gateways.create({
     *   data: {
     *     // ... data to create a Gateways
     *   }
     * })
     * 
    **/
    create<T extends gatewaysCreateArgs>(
      args: SelectSubset<T, gatewaysCreateArgs>
    ): CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>>

    /**
     * Create many Gateways.
     *     @param {gatewaysCreateManyArgs} args - Arguments to create many Gateways.
     *     @example
     *     // Create many Gateways
     *     const gateways = await prisma.gateways.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends gatewaysCreateManyArgs>(
      args?: SelectSubset<T, gatewaysCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Gateways.
     * @param {gatewaysDeleteArgs} args - Arguments to delete one Gateways.
     * @example
     * // Delete one Gateways
     * const Gateways = await prisma.gateways.delete({
     *   where: {
     *     // ... filter to delete one Gateways
     *   }
     * })
     * 
    **/
    delete<T extends gatewaysDeleteArgs>(
      args: SelectSubset<T, gatewaysDeleteArgs>
    ): CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>>

    /**
     * Update one Gateways.
     * @param {gatewaysUpdateArgs} args - Arguments to update one Gateways.
     * @example
     * // Update one Gateways
     * const gateways = await prisma.gateways.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends gatewaysUpdateArgs>(
      args: SelectSubset<T, gatewaysUpdateArgs>
    ): CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>>

    /**
     * Delete zero or more Gateways.
     * @param {gatewaysDeleteManyArgs} args - Arguments to filter Gateways to delete.
     * @example
     * // Delete a few Gateways
     * const { count } = await prisma.gateways.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends gatewaysDeleteManyArgs>(
      args?: SelectSubset<T, gatewaysDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Gateways.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {gatewaysUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Gateways
     * const gateways = await prisma.gateways.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends gatewaysUpdateManyArgs>(
      args: SelectSubset<T, gatewaysUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Gateways.
     * @param {gatewaysUpsertArgs} args - Arguments to update or create a Gateways.
     * @example
     * // Update or create a Gateways
     * const gateways = await prisma.gateways.upsert({
     *   create: {
     *     // ... data to create a Gateways
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Gateways we want to update
     *   }
     * })
    **/
    upsert<T extends gatewaysUpsertArgs>(
      args: SelectSubset<T, gatewaysUpsertArgs>
    ): CheckSelect<T, Prisma__gatewaysClient<gateways>, Prisma__gatewaysClient<gatewaysGetPayload<T>>>

    /**
     * Count the number of Gateways.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {gatewaysCountArgs} args - Arguments to filter Gateways to count.
     * @example
     * // Count the number of Gateways
     * const count = await prisma.gateways.count({
     *   where: {
     *     // ... the filter for the Gateways we want to count
     *   }
     * })
    **/
    count<T extends gatewaysCountArgs>(
      args?: Subset<T, gatewaysCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GatewaysCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Gateways.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GatewaysAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GatewaysAggregateArgs>(args: Subset<T, GatewaysAggregateArgs>): PrismaPromise<GetGatewaysAggregateType<T>>

    /**
     * Group by Gateways.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GatewaysGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GatewaysGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GatewaysGroupByArgs['orderBy'] }
        : { orderBy?: GatewaysGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GatewaysGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGatewaysGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for gateways.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__gatewaysClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * gateways findUnique
   */
  export type gatewaysFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * Throw an Error if a gateways can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which gateways to fetch.
     * 
    **/
    where: gatewaysWhereUniqueInput
  }


  /**
   * gateways findFirst
   */
  export type gatewaysFindFirstArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * Throw an Error if a gateways can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which gateways to fetch.
     * 
    **/
    where?: gatewaysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of gateways to fetch.
     * 
    **/
    orderBy?: Enumerable<gatewaysOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for gateways.
     * 
    **/
    cursor?: gatewaysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` gateways from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` gateways.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of gateways.
     * 
    **/
    distinct?: Enumerable<GatewaysScalarFieldEnum>
  }


  /**
   * gateways findMany
   */
  export type gatewaysFindManyArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * Filter, which gateways to fetch.
     * 
    **/
    where?: gatewaysWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of gateways to fetch.
     * 
    **/
    orderBy?: Enumerable<gatewaysOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing gateways.
     * 
    **/
    cursor?: gatewaysWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` gateways from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` gateways.
     * 
    **/
    skip?: number
    distinct?: Enumerable<GatewaysScalarFieldEnum>
  }


  /**
   * gateways create
   */
  export type gatewaysCreateArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * The data needed to create a gateways.
     * 
    **/
    data: XOR<gatewaysCreateInput, gatewaysUncheckedCreateInput>
  }


  /**
   * gateways createMany
   */
  export type gatewaysCreateManyArgs = {
    data: Enumerable<gatewaysCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * gateways update
   */
  export type gatewaysUpdateArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * The data needed to update a gateways.
     * 
    **/
    data: XOR<gatewaysUpdateInput, gatewaysUncheckedUpdateInput>
    /**
     * Choose, which gateways to update.
     * 
    **/
    where: gatewaysWhereUniqueInput
  }


  /**
   * gateways updateMany
   */
  export type gatewaysUpdateManyArgs = {
    data: XOR<gatewaysUpdateManyMutationInput, gatewaysUncheckedUpdateManyInput>
    where?: gatewaysWhereInput
  }


  /**
   * gateways upsert
   */
  export type gatewaysUpsertArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * The filter to search for the gateways to update in case it exists.
     * 
    **/
    where: gatewaysWhereUniqueInput
    /**
     * In case the gateways found by the `where` argument doesn't exist, create a new gateways with this data.
     * 
    **/
    create: XOR<gatewaysCreateInput, gatewaysUncheckedCreateInput>
    /**
     * In case the gateways was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<gatewaysUpdateInput, gatewaysUncheckedUpdateInput>
  }


  /**
   * gateways delete
   */
  export type gatewaysDeleteArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
    /**
     * Filter which gateways to delete.
     * 
    **/
    where: gatewaysWhereUniqueInput
  }


  /**
   * gateways deleteMany
   */
  export type gatewaysDeleteManyArgs = {
    where?: gatewaysWhereInput
  }


  /**
   * gateways without action
   */
  export type gatewaysArgs = {
    /**
     * Select specific fields to fetch from the gateways
     * 
    **/
    select?: gatewaysSelect | null
  }



  /**
   * Model subscriptionFunds
   */


  export type AggregateSubscriptionFunds = {
    _count: SubscriptionFundsCountAggregateOutputType | null
    _avg: SubscriptionFundsAvgAggregateOutputType | null
    _sum: SubscriptionFundsSumAggregateOutputType | null
    _min: SubscriptionFundsMinAggregateOutputType | null
    _max: SubscriptionFundsMaxAggregateOutputType | null
  }

  export type SubscriptionFundsAvgAggregateOutputType = {
    amount: number | null
  }

  export type SubscriptionFundsSumAggregateOutputType = {
    amount: number | null
  }

  export type SubscriptionFundsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    subscriptionId: string | null
    fundId: string | null
    amount: number | null
  }

  export type SubscriptionFundsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    subscriptionId: string | null
    fundId: string | null
    amount: number | null
  }

  export type SubscriptionFundsCountAggregateOutputType = {
    id: number
    churchId: number
    subscriptionId: number
    fundId: number
    amount: number
    _all: number
  }


  export type SubscriptionFundsAvgAggregateInputType = {
    amount?: true
  }

  export type SubscriptionFundsSumAggregateInputType = {
    amount?: true
  }

  export type SubscriptionFundsMinAggregateInputType = {
    id?: true
    churchId?: true
    subscriptionId?: true
    fundId?: true
    amount?: true
  }

  export type SubscriptionFundsMaxAggregateInputType = {
    id?: true
    churchId?: true
    subscriptionId?: true
    fundId?: true
    amount?: true
  }

  export type SubscriptionFundsCountAggregateInputType = {
    id?: true
    churchId?: true
    subscriptionId?: true
    fundId?: true
    amount?: true
    _all?: true
  }

  export type SubscriptionFundsAggregateArgs = {
    /**
     * Filter which subscriptionFunds to aggregate.
     * 
    **/
    where?: subscriptionFundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptionFunds to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionFundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: subscriptionFundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptionFunds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptionFunds.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned subscriptionFunds
    **/
    _count?: true | SubscriptionFundsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SubscriptionFundsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SubscriptionFundsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SubscriptionFundsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SubscriptionFundsMaxAggregateInputType
  }

  export type GetSubscriptionFundsAggregateType<T extends SubscriptionFundsAggregateArgs> = {
        [P in keyof T & keyof AggregateSubscriptionFunds]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSubscriptionFunds[P]>
      : GetScalarType<T[P], AggregateSubscriptionFunds[P]>
  }




  export type SubscriptionFundsGroupByArgs = {
    where?: subscriptionFundsWhereInput
    orderBy?: Enumerable<subscriptionFundsOrderByWithAggregationInput>
    by: Array<SubscriptionFundsScalarFieldEnum>
    having?: subscriptionFundsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SubscriptionFundsCountAggregateInputType | true
    _avg?: SubscriptionFundsAvgAggregateInputType
    _sum?: SubscriptionFundsSumAggregateInputType
    _min?: SubscriptionFundsMinAggregateInputType
    _max?: SubscriptionFundsMaxAggregateInputType
  }


  export type SubscriptionFundsGroupByOutputType = {
    id: string
    churchId: string
    subscriptionId: string | null
    fundId: string | null
    amount: number | null
    _count: SubscriptionFundsCountAggregateOutputType | null
    _avg: SubscriptionFundsAvgAggregateOutputType | null
    _sum: SubscriptionFundsSumAggregateOutputType | null
    _min: SubscriptionFundsMinAggregateOutputType | null
    _max: SubscriptionFundsMaxAggregateOutputType | null
  }

  type GetSubscriptionFundsGroupByPayload<T extends SubscriptionFundsGroupByArgs> = Promise<
    Array<
      PickArray<SubscriptionFundsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SubscriptionFundsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SubscriptionFundsGroupByOutputType[P]>
            : GetScalarType<T[P], SubscriptionFundsGroupByOutputType[P]>
        }
      >
    >


  export type subscriptionFundsSelect = {
    id?: boolean
    churchId?: boolean
    subscriptionId?: boolean
    fundId?: boolean
    amount?: boolean
  }

  export type subscriptionFundsGetPayload<
    S extends boolean | null | undefined | subscriptionFundsArgs,
    U = keyof S
      > = S extends true
        ? subscriptionFunds
    : S extends undefined
    ? never
    : S extends subscriptionFundsArgs | subscriptionFundsFindManyArgs
    ?'include' extends U
    ? subscriptionFunds 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof subscriptionFunds ?subscriptionFunds [P]
  : 
     never
  } 
    : subscriptionFunds
  : subscriptionFunds


  type subscriptionFundsCountArgs = Merge<
    Omit<subscriptionFundsFindManyArgs, 'select' | 'include'> & {
      select?: SubscriptionFundsCountAggregateInputType | true
    }
  >

  export interface subscriptionFundsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one SubscriptionFunds that matches the filter.
     * @param {subscriptionFundsFindUniqueArgs} args - Arguments to find a SubscriptionFunds
     * @example
     * // Get one SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends subscriptionFundsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, subscriptionFundsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'subscriptionFunds'> extends True ? CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>> : CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds | null >, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T> | null >>

    /**
     * Find the first SubscriptionFunds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionFundsFindFirstArgs} args - Arguments to find a SubscriptionFunds
     * @example
     * // Get one SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends subscriptionFundsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, subscriptionFundsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'subscriptionFunds'> extends True ? CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>> : CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds | null >, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T> | null >>

    /**
     * Find zero or more SubscriptionFunds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionFundsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.findMany()
     * 
     * // Get first 10 SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const subscriptionFundsWithIdOnly = await prisma.subscriptionFunds.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends subscriptionFundsFindManyArgs>(
      args?: SelectSubset<T, subscriptionFundsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<subscriptionFunds>>, PrismaPromise<Array<subscriptionFundsGetPayload<T>>>>

    /**
     * Create a SubscriptionFunds.
     * @param {subscriptionFundsCreateArgs} args - Arguments to create a SubscriptionFunds.
     * @example
     * // Create one SubscriptionFunds
     * const SubscriptionFunds = await prisma.subscriptionFunds.create({
     *   data: {
     *     // ... data to create a SubscriptionFunds
     *   }
     * })
     * 
    **/
    create<T extends subscriptionFundsCreateArgs>(
      args: SelectSubset<T, subscriptionFundsCreateArgs>
    ): CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>>

    /**
     * Create many SubscriptionFunds.
     *     @param {subscriptionFundsCreateManyArgs} args - Arguments to create many SubscriptionFunds.
     *     @example
     *     // Create many SubscriptionFunds
     *     const subscriptionFunds = await prisma.subscriptionFunds.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends subscriptionFundsCreateManyArgs>(
      args?: SelectSubset<T, subscriptionFundsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a SubscriptionFunds.
     * @param {subscriptionFundsDeleteArgs} args - Arguments to delete one SubscriptionFunds.
     * @example
     * // Delete one SubscriptionFunds
     * const SubscriptionFunds = await prisma.subscriptionFunds.delete({
     *   where: {
     *     // ... filter to delete one SubscriptionFunds
     *   }
     * })
     * 
    **/
    delete<T extends subscriptionFundsDeleteArgs>(
      args: SelectSubset<T, subscriptionFundsDeleteArgs>
    ): CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>>

    /**
     * Update one SubscriptionFunds.
     * @param {subscriptionFundsUpdateArgs} args - Arguments to update one SubscriptionFunds.
     * @example
     * // Update one SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends subscriptionFundsUpdateArgs>(
      args: SelectSubset<T, subscriptionFundsUpdateArgs>
    ): CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>>

    /**
     * Delete zero or more SubscriptionFunds.
     * @param {subscriptionFundsDeleteManyArgs} args - Arguments to filter SubscriptionFunds to delete.
     * @example
     * // Delete a few SubscriptionFunds
     * const { count } = await prisma.subscriptionFunds.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends subscriptionFundsDeleteManyArgs>(
      args?: SelectSubset<T, subscriptionFundsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more SubscriptionFunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionFundsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends subscriptionFundsUpdateManyArgs>(
      args: SelectSubset<T, subscriptionFundsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one SubscriptionFunds.
     * @param {subscriptionFundsUpsertArgs} args - Arguments to update or create a SubscriptionFunds.
     * @example
     * // Update or create a SubscriptionFunds
     * const subscriptionFunds = await prisma.subscriptionFunds.upsert({
     *   create: {
     *     // ... data to create a SubscriptionFunds
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SubscriptionFunds we want to update
     *   }
     * })
    **/
    upsert<T extends subscriptionFundsUpsertArgs>(
      args: SelectSubset<T, subscriptionFundsUpsertArgs>
    ): CheckSelect<T, Prisma__subscriptionFundsClient<subscriptionFunds>, Prisma__subscriptionFundsClient<subscriptionFundsGetPayload<T>>>

    /**
     * Count the number of SubscriptionFunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionFundsCountArgs} args - Arguments to filter SubscriptionFunds to count.
     * @example
     * // Count the number of SubscriptionFunds
     * const count = await prisma.subscriptionFunds.count({
     *   where: {
     *     // ... the filter for the SubscriptionFunds we want to count
     *   }
     * })
    **/
    count<T extends subscriptionFundsCountArgs>(
      args?: Subset<T, subscriptionFundsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SubscriptionFundsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SubscriptionFunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionFundsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SubscriptionFundsAggregateArgs>(args: Subset<T, SubscriptionFundsAggregateArgs>): PrismaPromise<GetSubscriptionFundsAggregateType<T>>

    /**
     * Group by SubscriptionFunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionFundsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SubscriptionFundsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SubscriptionFundsGroupByArgs['orderBy'] }
        : { orderBy?: SubscriptionFundsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SubscriptionFundsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSubscriptionFundsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for subscriptionFunds.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__subscriptionFundsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * subscriptionFunds findUnique
   */
  export type subscriptionFundsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * Throw an Error if a subscriptionFunds can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which subscriptionFunds to fetch.
     * 
    **/
    where: subscriptionFundsWhereUniqueInput
  }


  /**
   * subscriptionFunds findFirst
   */
  export type subscriptionFundsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * Throw an Error if a subscriptionFunds can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which subscriptionFunds to fetch.
     * 
    **/
    where?: subscriptionFundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptionFunds to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionFundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for subscriptionFunds.
     * 
    **/
    cursor?: subscriptionFundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptionFunds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptionFunds.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of subscriptionFunds.
     * 
    **/
    distinct?: Enumerable<SubscriptionFundsScalarFieldEnum>
  }


  /**
   * subscriptionFunds findMany
   */
  export type subscriptionFundsFindManyArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * Filter, which subscriptionFunds to fetch.
     * 
    **/
    where?: subscriptionFundsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptionFunds to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionFundsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing subscriptionFunds.
     * 
    **/
    cursor?: subscriptionFundsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptionFunds from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptionFunds.
     * 
    **/
    skip?: number
    distinct?: Enumerable<SubscriptionFundsScalarFieldEnum>
  }


  /**
   * subscriptionFunds create
   */
  export type subscriptionFundsCreateArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * The data needed to create a subscriptionFunds.
     * 
    **/
    data: XOR<subscriptionFundsCreateInput, subscriptionFundsUncheckedCreateInput>
  }


  /**
   * subscriptionFunds createMany
   */
  export type subscriptionFundsCreateManyArgs = {
    data: Enumerable<subscriptionFundsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * subscriptionFunds update
   */
  export type subscriptionFundsUpdateArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * The data needed to update a subscriptionFunds.
     * 
    **/
    data: XOR<subscriptionFundsUpdateInput, subscriptionFundsUncheckedUpdateInput>
    /**
     * Choose, which subscriptionFunds to update.
     * 
    **/
    where: subscriptionFundsWhereUniqueInput
  }


  /**
   * subscriptionFunds updateMany
   */
  export type subscriptionFundsUpdateManyArgs = {
    data: XOR<subscriptionFundsUpdateManyMutationInput, subscriptionFundsUncheckedUpdateManyInput>
    where?: subscriptionFundsWhereInput
  }


  /**
   * subscriptionFunds upsert
   */
  export type subscriptionFundsUpsertArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * The filter to search for the subscriptionFunds to update in case it exists.
     * 
    **/
    where: subscriptionFundsWhereUniqueInput
    /**
     * In case the subscriptionFunds found by the `where` argument doesn't exist, create a new subscriptionFunds with this data.
     * 
    **/
    create: XOR<subscriptionFundsCreateInput, subscriptionFundsUncheckedCreateInput>
    /**
     * In case the subscriptionFunds was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<subscriptionFundsUpdateInput, subscriptionFundsUncheckedUpdateInput>
  }


  /**
   * subscriptionFunds delete
   */
  export type subscriptionFundsDeleteArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
    /**
     * Filter which subscriptionFunds to delete.
     * 
    **/
    where: subscriptionFundsWhereUniqueInput
  }


  /**
   * subscriptionFunds deleteMany
   */
  export type subscriptionFundsDeleteManyArgs = {
    where?: subscriptionFundsWhereInput
  }


  /**
   * subscriptionFunds without action
   */
  export type subscriptionFundsArgs = {
    /**
     * Select specific fields to fetch from the subscriptionFunds
     * 
    **/
    select?: subscriptionFundsSelect | null
  }



  /**
   * Model subscriptions
   */


  export type AggregateSubscriptions = {
    _count: SubscriptionsCountAggregateOutputType | null
    _min: SubscriptionsMinAggregateOutputType | null
    _max: SubscriptionsMaxAggregateOutputType | null
  }

  export type SubscriptionsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
    customerId: string | null
  }

  export type SubscriptionsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
    customerId: string | null
  }

  export type SubscriptionsCountAggregateOutputType = {
    id: number
    churchId: number
    personId: number
    customerId: number
    _all: number
  }


  export type SubscriptionsMinAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    customerId?: true
  }

  export type SubscriptionsMaxAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    customerId?: true
  }

  export type SubscriptionsCountAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    customerId?: true
    _all?: true
  }

  export type SubscriptionsAggregateArgs = {
    /**
     * Filter which subscriptions to aggregate.
     * 
    **/
    where?: subscriptionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptions to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: subscriptionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned subscriptions
    **/
    _count?: true | SubscriptionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SubscriptionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SubscriptionsMaxAggregateInputType
  }

  export type GetSubscriptionsAggregateType<T extends SubscriptionsAggregateArgs> = {
        [P in keyof T & keyof AggregateSubscriptions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSubscriptions[P]>
      : GetScalarType<T[P], AggregateSubscriptions[P]>
  }




  export type SubscriptionsGroupByArgs = {
    where?: subscriptionsWhereInput
    orderBy?: Enumerable<subscriptionsOrderByWithAggregationInput>
    by: Array<SubscriptionsScalarFieldEnum>
    having?: subscriptionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SubscriptionsCountAggregateInputType | true
    _min?: SubscriptionsMinAggregateInputType
    _max?: SubscriptionsMaxAggregateInputType
  }


  export type SubscriptionsGroupByOutputType = {
    id: string
    churchId: string | null
    personId: string | null
    customerId: string | null
    _count: SubscriptionsCountAggregateOutputType | null
    _min: SubscriptionsMinAggregateOutputType | null
    _max: SubscriptionsMaxAggregateOutputType | null
  }

  type GetSubscriptionsGroupByPayload<T extends SubscriptionsGroupByArgs> = Promise<
    Array<
      PickArray<SubscriptionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SubscriptionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SubscriptionsGroupByOutputType[P]>
            : GetScalarType<T[P], SubscriptionsGroupByOutputType[P]>
        }
      >
    >


  export type subscriptionsSelect = {
    id?: boolean
    churchId?: boolean
    personId?: boolean
    customerId?: boolean
  }

  export type subscriptionsGetPayload<
    S extends boolean | null | undefined | subscriptionsArgs,
    U = keyof S
      > = S extends true
        ? subscriptions
    : S extends undefined
    ? never
    : S extends subscriptionsArgs | subscriptionsFindManyArgs
    ?'include' extends U
    ? subscriptions 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof subscriptions ?subscriptions [P]
  : 
     never
  } 
    : subscriptions
  : subscriptions


  type subscriptionsCountArgs = Merge<
    Omit<subscriptionsFindManyArgs, 'select' | 'include'> & {
      select?: SubscriptionsCountAggregateInputType | true
    }
  >

  export interface subscriptionsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Subscriptions that matches the filter.
     * @param {subscriptionsFindUniqueArgs} args - Arguments to find a Subscriptions
     * @example
     * // Get one Subscriptions
     * const subscriptions = await prisma.subscriptions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends subscriptionsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, subscriptionsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'subscriptions'> extends True ? CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>> : CheckSelect<T, Prisma__subscriptionsClient<subscriptions | null >, Prisma__subscriptionsClient<subscriptionsGetPayload<T> | null >>

    /**
     * Find the first Subscriptions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionsFindFirstArgs} args - Arguments to find a Subscriptions
     * @example
     * // Get one Subscriptions
     * const subscriptions = await prisma.subscriptions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends subscriptionsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, subscriptionsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'subscriptions'> extends True ? CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>> : CheckSelect<T, Prisma__subscriptionsClient<subscriptions | null >, Prisma__subscriptionsClient<subscriptionsGetPayload<T> | null >>

    /**
     * Find zero or more Subscriptions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Subscriptions
     * const subscriptions = await prisma.subscriptions.findMany()
     * 
     * // Get first 10 Subscriptions
     * const subscriptions = await prisma.subscriptions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const subscriptionsWithIdOnly = await prisma.subscriptions.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends subscriptionsFindManyArgs>(
      args?: SelectSubset<T, subscriptionsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<subscriptions>>, PrismaPromise<Array<subscriptionsGetPayload<T>>>>

    /**
     * Create a Subscriptions.
     * @param {subscriptionsCreateArgs} args - Arguments to create a Subscriptions.
     * @example
     * // Create one Subscriptions
     * const Subscriptions = await prisma.subscriptions.create({
     *   data: {
     *     // ... data to create a Subscriptions
     *   }
     * })
     * 
    **/
    create<T extends subscriptionsCreateArgs>(
      args: SelectSubset<T, subscriptionsCreateArgs>
    ): CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>>

    /**
     * Create many Subscriptions.
     *     @param {subscriptionsCreateManyArgs} args - Arguments to create many Subscriptions.
     *     @example
     *     // Create many Subscriptions
     *     const subscriptions = await prisma.subscriptions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends subscriptionsCreateManyArgs>(
      args?: SelectSubset<T, subscriptionsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Subscriptions.
     * @param {subscriptionsDeleteArgs} args - Arguments to delete one Subscriptions.
     * @example
     * // Delete one Subscriptions
     * const Subscriptions = await prisma.subscriptions.delete({
     *   where: {
     *     // ... filter to delete one Subscriptions
     *   }
     * })
     * 
    **/
    delete<T extends subscriptionsDeleteArgs>(
      args: SelectSubset<T, subscriptionsDeleteArgs>
    ): CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>>

    /**
     * Update one Subscriptions.
     * @param {subscriptionsUpdateArgs} args - Arguments to update one Subscriptions.
     * @example
     * // Update one Subscriptions
     * const subscriptions = await prisma.subscriptions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends subscriptionsUpdateArgs>(
      args: SelectSubset<T, subscriptionsUpdateArgs>
    ): CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>>

    /**
     * Delete zero or more Subscriptions.
     * @param {subscriptionsDeleteManyArgs} args - Arguments to filter Subscriptions to delete.
     * @example
     * // Delete a few Subscriptions
     * const { count } = await prisma.subscriptions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends subscriptionsDeleteManyArgs>(
      args?: SelectSubset<T, subscriptionsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Subscriptions
     * const subscriptions = await prisma.subscriptions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends subscriptionsUpdateManyArgs>(
      args: SelectSubset<T, subscriptionsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Subscriptions.
     * @param {subscriptionsUpsertArgs} args - Arguments to update or create a Subscriptions.
     * @example
     * // Update or create a Subscriptions
     * const subscriptions = await prisma.subscriptions.upsert({
     *   create: {
     *     // ... data to create a Subscriptions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Subscriptions we want to update
     *   }
     * })
    **/
    upsert<T extends subscriptionsUpsertArgs>(
      args: SelectSubset<T, subscriptionsUpsertArgs>
    ): CheckSelect<T, Prisma__subscriptionsClient<subscriptions>, Prisma__subscriptionsClient<subscriptionsGetPayload<T>>>

    /**
     * Count the number of Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {subscriptionsCountArgs} args - Arguments to filter Subscriptions to count.
     * @example
     * // Count the number of Subscriptions
     * const count = await prisma.subscriptions.count({
     *   where: {
     *     // ... the filter for the Subscriptions we want to count
     *   }
     * })
    **/
    count<T extends subscriptionsCountArgs>(
      args?: Subset<T, subscriptionsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SubscriptionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SubscriptionsAggregateArgs>(args: Subset<T, SubscriptionsAggregateArgs>): PrismaPromise<GetSubscriptionsAggregateType<T>>

    /**
     * Group by Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SubscriptionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SubscriptionsGroupByArgs['orderBy'] }
        : { orderBy?: SubscriptionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SubscriptionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSubscriptionsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for subscriptions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__subscriptionsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * subscriptions findUnique
   */
  export type subscriptionsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * Throw an Error if a subscriptions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which subscriptions to fetch.
     * 
    **/
    where: subscriptionsWhereUniqueInput
  }


  /**
   * subscriptions findFirst
   */
  export type subscriptionsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * Throw an Error if a subscriptions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which subscriptions to fetch.
     * 
    **/
    where?: subscriptionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptions to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for subscriptions.
     * 
    **/
    cursor?: subscriptionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of subscriptions.
     * 
    **/
    distinct?: Enumerable<SubscriptionsScalarFieldEnum>
  }


  /**
   * subscriptions findMany
   */
  export type subscriptionsFindManyArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * Filter, which subscriptions to fetch.
     * 
    **/
    where?: subscriptionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of subscriptions to fetch.
     * 
    **/
    orderBy?: Enumerable<subscriptionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing subscriptions.
     * 
    **/
    cursor?: subscriptionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` subscriptions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` subscriptions.
     * 
    **/
    skip?: number
    distinct?: Enumerable<SubscriptionsScalarFieldEnum>
  }


  /**
   * subscriptions create
   */
  export type subscriptionsCreateArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * The data needed to create a subscriptions.
     * 
    **/
    data: XOR<subscriptionsCreateInput, subscriptionsUncheckedCreateInput>
  }


  /**
   * subscriptions createMany
   */
  export type subscriptionsCreateManyArgs = {
    data: Enumerable<subscriptionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * subscriptions update
   */
  export type subscriptionsUpdateArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * The data needed to update a subscriptions.
     * 
    **/
    data: XOR<subscriptionsUpdateInput, subscriptionsUncheckedUpdateInput>
    /**
     * Choose, which subscriptions to update.
     * 
    **/
    where: subscriptionsWhereUniqueInput
  }


  /**
   * subscriptions updateMany
   */
  export type subscriptionsUpdateManyArgs = {
    data: XOR<subscriptionsUpdateManyMutationInput, subscriptionsUncheckedUpdateManyInput>
    where?: subscriptionsWhereInput
  }


  /**
   * subscriptions upsert
   */
  export type subscriptionsUpsertArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * The filter to search for the subscriptions to update in case it exists.
     * 
    **/
    where: subscriptionsWhereUniqueInput
    /**
     * In case the subscriptions found by the `where` argument doesn't exist, create a new subscriptions with this data.
     * 
    **/
    create: XOR<subscriptionsCreateInput, subscriptionsUncheckedCreateInput>
    /**
     * In case the subscriptions was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<subscriptionsUpdateInput, subscriptionsUncheckedUpdateInput>
  }


  /**
   * subscriptions delete
   */
  export type subscriptionsDeleteArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
    /**
     * Filter which subscriptions to delete.
     * 
    **/
    where: subscriptionsWhereUniqueInput
  }


  /**
   * subscriptions deleteMany
   */
  export type subscriptionsDeleteManyArgs = {
    where?: subscriptionsWhereInput
  }


  /**
   * subscriptions without action
   */
  export type subscriptionsArgs = {
    /**
     * Select specific fields to fetch from the subscriptions
     * 
    **/
    select?: subscriptionsSelect | null
  }



  /**
   * Model campuses
   */


  export type AggregateCampuses = {
    _count: CampusesCountAggregateOutputType | null
    _min: CampusesMinAggregateOutputType | null
    _max: CampusesMaxAggregateOutputType | null
  }

  export type CampusesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    removed: boolean | null
  }

  export type CampusesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    name: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    removed: boolean | null
  }

  export type CampusesCountAggregateOutputType = {
    id: number
    churchId: number
    name: number
    address1: number
    address2: number
    city: number
    state: number
    zip: number
    removed: number
    _all: number
  }


  export type CampusesMinAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    removed?: true
  }

  export type CampusesMaxAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    removed?: true
  }

  export type CampusesCountAggregateInputType = {
    id?: true
    churchId?: true
    name?: true
    address1?: true
    address2?: true
    city?: true
    state?: true
    zip?: true
    removed?: true
    _all?: true
  }

  export type CampusesAggregateArgs = {
    /**
     * Filter which campuses to aggregate.
     * 
    **/
    where?: campusesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of campuses to fetch.
     * 
    **/
    orderBy?: Enumerable<campusesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: campusesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` campuses from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` campuses.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned campuses
    **/
    _count?: true | CampusesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CampusesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CampusesMaxAggregateInputType
  }

  export type GetCampusesAggregateType<T extends CampusesAggregateArgs> = {
        [P in keyof T & keyof AggregateCampuses]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCampuses[P]>
      : GetScalarType<T[P], AggregateCampuses[P]>
  }




  export type CampusesGroupByArgs = {
    where?: campusesWhereInput
    orderBy?: Enumerable<campusesOrderByWithAggregationInput>
    by: Array<CampusesScalarFieldEnum>
    having?: campusesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CampusesCountAggregateInputType | true
    _min?: CampusesMinAggregateInputType
    _max?: CampusesMaxAggregateInputType
  }


  export type CampusesGroupByOutputType = {
    id: string
    churchId: string | null
    name: string | null
    address1: string | null
    address2: string | null
    city: string | null
    state: string | null
    zip: string | null
    removed: boolean | null
    _count: CampusesCountAggregateOutputType | null
    _min: CampusesMinAggregateOutputType | null
    _max: CampusesMaxAggregateOutputType | null
  }

  type GetCampusesGroupByPayload<T extends CampusesGroupByArgs> = Promise<
    Array<
      PickArray<CampusesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CampusesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CampusesGroupByOutputType[P]>
            : GetScalarType<T[P], CampusesGroupByOutputType[P]>
        }
      >
    >


  export type campusesSelect = {
    id?: boolean
    churchId?: boolean
    name?: boolean
    address1?: boolean
    address2?: boolean
    city?: boolean
    state?: boolean
    zip?: boolean
    removed?: boolean
  }

  export type campusesGetPayload<
    S extends boolean | null | undefined | campusesArgs,
    U = keyof S
      > = S extends true
        ? campuses
    : S extends undefined
    ? never
    : S extends campusesArgs | campusesFindManyArgs
    ?'include' extends U
    ? campuses 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof campuses ?campuses [P]
  : 
     never
  } 
    : campuses
  : campuses


  type campusesCountArgs = Merge<
    Omit<campusesFindManyArgs, 'select' | 'include'> & {
      select?: CampusesCountAggregateInputType | true
    }
  >

  export interface campusesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Campuses that matches the filter.
     * @param {campusesFindUniqueArgs} args - Arguments to find a Campuses
     * @example
     * // Get one Campuses
     * const campuses = await prisma.campuses.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends campusesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, campusesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'campuses'> extends True ? CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>> : CheckSelect<T, Prisma__campusesClient<campuses | null >, Prisma__campusesClient<campusesGetPayload<T> | null >>

    /**
     * Find the first Campuses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {campusesFindFirstArgs} args - Arguments to find a Campuses
     * @example
     * // Get one Campuses
     * const campuses = await prisma.campuses.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends campusesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, campusesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'campuses'> extends True ? CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>> : CheckSelect<T, Prisma__campusesClient<campuses | null >, Prisma__campusesClient<campusesGetPayload<T> | null >>

    /**
     * Find zero or more Campuses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {campusesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Campuses
     * const campuses = await prisma.campuses.findMany()
     * 
     * // Get first 10 Campuses
     * const campuses = await prisma.campuses.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const campusesWithIdOnly = await prisma.campuses.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends campusesFindManyArgs>(
      args?: SelectSubset<T, campusesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<campuses>>, PrismaPromise<Array<campusesGetPayload<T>>>>

    /**
     * Create a Campuses.
     * @param {campusesCreateArgs} args - Arguments to create a Campuses.
     * @example
     * // Create one Campuses
     * const Campuses = await prisma.campuses.create({
     *   data: {
     *     // ... data to create a Campuses
     *   }
     * })
     * 
    **/
    create<T extends campusesCreateArgs>(
      args: SelectSubset<T, campusesCreateArgs>
    ): CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>>

    /**
     * Create many Campuses.
     *     @param {campusesCreateManyArgs} args - Arguments to create many Campuses.
     *     @example
     *     // Create many Campuses
     *     const campuses = await prisma.campuses.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends campusesCreateManyArgs>(
      args?: SelectSubset<T, campusesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Campuses.
     * @param {campusesDeleteArgs} args - Arguments to delete one Campuses.
     * @example
     * // Delete one Campuses
     * const Campuses = await prisma.campuses.delete({
     *   where: {
     *     // ... filter to delete one Campuses
     *   }
     * })
     * 
    **/
    delete<T extends campusesDeleteArgs>(
      args: SelectSubset<T, campusesDeleteArgs>
    ): CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>>

    /**
     * Update one Campuses.
     * @param {campusesUpdateArgs} args - Arguments to update one Campuses.
     * @example
     * // Update one Campuses
     * const campuses = await prisma.campuses.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends campusesUpdateArgs>(
      args: SelectSubset<T, campusesUpdateArgs>
    ): CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>>

    /**
     * Delete zero or more Campuses.
     * @param {campusesDeleteManyArgs} args - Arguments to filter Campuses to delete.
     * @example
     * // Delete a few Campuses
     * const { count } = await prisma.campuses.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends campusesDeleteManyArgs>(
      args?: SelectSubset<T, campusesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Campuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {campusesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Campuses
     * const campuses = await prisma.campuses.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends campusesUpdateManyArgs>(
      args: SelectSubset<T, campusesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Campuses.
     * @param {campusesUpsertArgs} args - Arguments to update or create a Campuses.
     * @example
     * // Update or create a Campuses
     * const campuses = await prisma.campuses.upsert({
     *   create: {
     *     // ... data to create a Campuses
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Campuses we want to update
     *   }
     * })
    **/
    upsert<T extends campusesUpsertArgs>(
      args: SelectSubset<T, campusesUpsertArgs>
    ): CheckSelect<T, Prisma__campusesClient<campuses>, Prisma__campusesClient<campusesGetPayload<T>>>

    /**
     * Count the number of Campuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {campusesCountArgs} args - Arguments to filter Campuses to count.
     * @example
     * // Count the number of Campuses
     * const count = await prisma.campuses.count({
     *   where: {
     *     // ... the filter for the Campuses we want to count
     *   }
     * })
    **/
    count<T extends campusesCountArgs>(
      args?: Subset<T, campusesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CampusesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Campuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CampusesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CampusesAggregateArgs>(args: Subset<T, CampusesAggregateArgs>): PrismaPromise<GetCampusesAggregateType<T>>

    /**
     * Group by Campuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CampusesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CampusesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CampusesGroupByArgs['orderBy'] }
        : { orderBy?: CampusesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CampusesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCampusesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for campuses.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__campusesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * campuses findUnique
   */
  export type campusesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * Throw an Error if a campuses can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which campuses to fetch.
     * 
    **/
    where: campusesWhereUniqueInput
  }


  /**
   * campuses findFirst
   */
  export type campusesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * Throw an Error if a campuses can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which campuses to fetch.
     * 
    **/
    where?: campusesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of campuses to fetch.
     * 
    **/
    orderBy?: Enumerable<campusesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for campuses.
     * 
    **/
    cursor?: campusesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` campuses from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` campuses.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of campuses.
     * 
    **/
    distinct?: Enumerable<CampusesScalarFieldEnum>
  }


  /**
   * campuses findMany
   */
  export type campusesFindManyArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * Filter, which campuses to fetch.
     * 
    **/
    where?: campusesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of campuses to fetch.
     * 
    **/
    orderBy?: Enumerable<campusesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing campuses.
     * 
    **/
    cursor?: campusesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` campuses from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` campuses.
     * 
    **/
    skip?: number
    distinct?: Enumerable<CampusesScalarFieldEnum>
  }


  /**
   * campuses create
   */
  export type campusesCreateArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * The data needed to create a campuses.
     * 
    **/
    data: XOR<campusesCreateInput, campusesUncheckedCreateInput>
  }


  /**
   * campuses createMany
   */
  export type campusesCreateManyArgs = {
    data: Enumerable<campusesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * campuses update
   */
  export type campusesUpdateArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * The data needed to update a campuses.
     * 
    **/
    data: XOR<campusesUpdateInput, campusesUncheckedUpdateInput>
    /**
     * Choose, which campuses to update.
     * 
    **/
    where: campusesWhereUniqueInput
  }


  /**
   * campuses updateMany
   */
  export type campusesUpdateManyArgs = {
    data: XOR<campusesUpdateManyMutationInput, campusesUncheckedUpdateManyInput>
    where?: campusesWhereInput
  }


  /**
   * campuses upsert
   */
  export type campusesUpsertArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * The filter to search for the campuses to update in case it exists.
     * 
    **/
    where: campusesWhereUniqueInput
    /**
     * In case the campuses found by the `where` argument doesn't exist, create a new campuses with this data.
     * 
    **/
    create: XOR<campusesCreateInput, campusesUncheckedCreateInput>
    /**
     * In case the campuses was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<campusesUpdateInput, campusesUncheckedUpdateInput>
  }


  /**
   * campuses delete
   */
  export type campusesDeleteArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
    /**
     * Filter which campuses to delete.
     * 
    **/
    where: campusesWhereUniqueInput
  }


  /**
   * campuses deleteMany
   */
  export type campusesDeleteManyArgs = {
    where?: campusesWhereInput
  }


  /**
   * campuses without action
   */
  export type campusesArgs = {
    /**
     * Select specific fields to fetch from the campuses
     * 
    **/
    select?: campusesSelect | null
  }



  /**
   * Model groupServiceTimes
   */


  export type AggregateGroupServiceTimes = {
    _count: GroupServiceTimesCountAggregateOutputType | null
    _min: GroupServiceTimesMinAggregateOutputType | null
    _max: GroupServiceTimesMaxAggregateOutputType | null
  }

  export type GroupServiceTimesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
  }

  export type GroupServiceTimesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
  }

  export type GroupServiceTimesCountAggregateOutputType = {
    id: number
    churchId: number
    groupId: number
    serviceTimeId: number
    _all: number
  }


  export type GroupServiceTimesMinAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
  }

  export type GroupServiceTimesMaxAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
  }

  export type GroupServiceTimesCountAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
    _all?: true
  }

  export type GroupServiceTimesAggregateArgs = {
    /**
     * Filter which groupServiceTimes to aggregate.
     * 
    **/
    where?: groupServiceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupServiceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<groupServiceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: groupServiceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupServiceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupServiceTimes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned groupServiceTimes
    **/
    _count?: true | GroupServiceTimesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GroupServiceTimesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GroupServiceTimesMaxAggregateInputType
  }

  export type GetGroupServiceTimesAggregateType<T extends GroupServiceTimesAggregateArgs> = {
        [P in keyof T & keyof AggregateGroupServiceTimes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGroupServiceTimes[P]>
      : GetScalarType<T[P], AggregateGroupServiceTimes[P]>
  }




  export type GroupServiceTimesGroupByArgs = {
    where?: groupServiceTimesWhereInput
    orderBy?: Enumerable<groupServiceTimesOrderByWithAggregationInput>
    by: Array<GroupServiceTimesScalarFieldEnum>
    having?: groupServiceTimesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GroupServiceTimesCountAggregateInputType | true
    _min?: GroupServiceTimesMinAggregateInputType
    _max?: GroupServiceTimesMaxAggregateInputType
  }


  export type GroupServiceTimesGroupByOutputType = {
    id: string
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
    _count: GroupServiceTimesCountAggregateOutputType | null
    _min: GroupServiceTimesMinAggregateOutputType | null
    _max: GroupServiceTimesMaxAggregateOutputType | null
  }

  type GetGroupServiceTimesGroupByPayload<T extends GroupServiceTimesGroupByArgs> = Promise<
    Array<
      PickArray<GroupServiceTimesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GroupServiceTimesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GroupServiceTimesGroupByOutputType[P]>
            : GetScalarType<T[P], GroupServiceTimesGroupByOutputType[P]>
        }
      >
    >


  export type groupServiceTimesSelect = {
    id?: boolean
    churchId?: boolean
    groupId?: boolean
    serviceTimeId?: boolean
  }

  export type groupServiceTimesGetPayload<
    S extends boolean | null | undefined | groupServiceTimesArgs,
    U = keyof S
      > = S extends true
        ? groupServiceTimes
    : S extends undefined
    ? never
    : S extends groupServiceTimesArgs | groupServiceTimesFindManyArgs
    ?'include' extends U
    ? groupServiceTimes 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof groupServiceTimes ?groupServiceTimes [P]
  : 
     never
  } 
    : groupServiceTimes
  : groupServiceTimes


  type groupServiceTimesCountArgs = Merge<
    Omit<groupServiceTimesFindManyArgs, 'select' | 'include'> & {
      select?: GroupServiceTimesCountAggregateInputType | true
    }
  >

  export interface groupServiceTimesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one GroupServiceTimes that matches the filter.
     * @param {groupServiceTimesFindUniqueArgs} args - Arguments to find a GroupServiceTimes
     * @example
     * // Get one GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends groupServiceTimesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, groupServiceTimesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'groupServiceTimes'> extends True ? CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>> : CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes | null >, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T> | null >>

    /**
     * Find the first GroupServiceTimes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupServiceTimesFindFirstArgs} args - Arguments to find a GroupServiceTimes
     * @example
     * // Get one GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends groupServiceTimesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, groupServiceTimesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'groupServiceTimes'> extends True ? CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>> : CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes | null >, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T> | null >>

    /**
     * Find zero or more GroupServiceTimes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupServiceTimesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.findMany()
     * 
     * // Get first 10 GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const groupServiceTimesWithIdOnly = await prisma.groupServiceTimes.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends groupServiceTimesFindManyArgs>(
      args?: SelectSubset<T, groupServiceTimesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<groupServiceTimes>>, PrismaPromise<Array<groupServiceTimesGetPayload<T>>>>

    /**
     * Create a GroupServiceTimes.
     * @param {groupServiceTimesCreateArgs} args - Arguments to create a GroupServiceTimes.
     * @example
     * // Create one GroupServiceTimes
     * const GroupServiceTimes = await prisma.groupServiceTimes.create({
     *   data: {
     *     // ... data to create a GroupServiceTimes
     *   }
     * })
     * 
    **/
    create<T extends groupServiceTimesCreateArgs>(
      args: SelectSubset<T, groupServiceTimesCreateArgs>
    ): CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>>

    /**
     * Create many GroupServiceTimes.
     *     @param {groupServiceTimesCreateManyArgs} args - Arguments to create many GroupServiceTimes.
     *     @example
     *     // Create many GroupServiceTimes
     *     const groupServiceTimes = await prisma.groupServiceTimes.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends groupServiceTimesCreateManyArgs>(
      args?: SelectSubset<T, groupServiceTimesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a GroupServiceTimes.
     * @param {groupServiceTimesDeleteArgs} args - Arguments to delete one GroupServiceTimes.
     * @example
     * // Delete one GroupServiceTimes
     * const GroupServiceTimes = await prisma.groupServiceTimes.delete({
     *   where: {
     *     // ... filter to delete one GroupServiceTimes
     *   }
     * })
     * 
    **/
    delete<T extends groupServiceTimesDeleteArgs>(
      args: SelectSubset<T, groupServiceTimesDeleteArgs>
    ): CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>>

    /**
     * Update one GroupServiceTimes.
     * @param {groupServiceTimesUpdateArgs} args - Arguments to update one GroupServiceTimes.
     * @example
     * // Update one GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends groupServiceTimesUpdateArgs>(
      args: SelectSubset<T, groupServiceTimesUpdateArgs>
    ): CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>>

    /**
     * Delete zero or more GroupServiceTimes.
     * @param {groupServiceTimesDeleteManyArgs} args - Arguments to filter GroupServiceTimes to delete.
     * @example
     * // Delete a few GroupServiceTimes
     * const { count } = await prisma.groupServiceTimes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends groupServiceTimesDeleteManyArgs>(
      args?: SelectSubset<T, groupServiceTimesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more GroupServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupServiceTimesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends groupServiceTimesUpdateManyArgs>(
      args: SelectSubset<T, groupServiceTimesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one GroupServiceTimes.
     * @param {groupServiceTimesUpsertArgs} args - Arguments to update or create a GroupServiceTimes.
     * @example
     * // Update or create a GroupServiceTimes
     * const groupServiceTimes = await prisma.groupServiceTimes.upsert({
     *   create: {
     *     // ... data to create a GroupServiceTimes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the GroupServiceTimes we want to update
     *   }
     * })
    **/
    upsert<T extends groupServiceTimesUpsertArgs>(
      args: SelectSubset<T, groupServiceTimesUpsertArgs>
    ): CheckSelect<T, Prisma__groupServiceTimesClient<groupServiceTimes>, Prisma__groupServiceTimesClient<groupServiceTimesGetPayload<T>>>

    /**
     * Count the number of GroupServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {groupServiceTimesCountArgs} args - Arguments to filter GroupServiceTimes to count.
     * @example
     * // Count the number of GroupServiceTimes
     * const count = await prisma.groupServiceTimes.count({
     *   where: {
     *     // ... the filter for the GroupServiceTimes we want to count
     *   }
     * })
    **/
    count<T extends groupServiceTimesCountArgs>(
      args?: Subset<T, groupServiceTimesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GroupServiceTimesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a GroupServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupServiceTimesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GroupServiceTimesAggregateArgs>(args: Subset<T, GroupServiceTimesAggregateArgs>): PrismaPromise<GetGroupServiceTimesAggregateType<T>>

    /**
     * Group by GroupServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GroupServiceTimesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GroupServiceTimesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GroupServiceTimesGroupByArgs['orderBy'] }
        : { orderBy?: GroupServiceTimesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GroupServiceTimesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGroupServiceTimesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for groupServiceTimes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__groupServiceTimesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * groupServiceTimes findUnique
   */
  export type groupServiceTimesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * Throw an Error if a groupServiceTimes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groupServiceTimes to fetch.
     * 
    **/
    where: groupServiceTimesWhereUniqueInput
  }


  /**
   * groupServiceTimes findFirst
   */
  export type groupServiceTimesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * Throw an Error if a groupServiceTimes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which groupServiceTimes to fetch.
     * 
    **/
    where?: groupServiceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupServiceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<groupServiceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for groupServiceTimes.
     * 
    **/
    cursor?: groupServiceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupServiceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupServiceTimes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of groupServiceTimes.
     * 
    **/
    distinct?: Enumerable<GroupServiceTimesScalarFieldEnum>
  }


  /**
   * groupServiceTimes findMany
   */
  export type groupServiceTimesFindManyArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * Filter, which groupServiceTimes to fetch.
     * 
    **/
    where?: groupServiceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of groupServiceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<groupServiceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing groupServiceTimes.
     * 
    **/
    cursor?: groupServiceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` groupServiceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` groupServiceTimes.
     * 
    **/
    skip?: number
    distinct?: Enumerable<GroupServiceTimesScalarFieldEnum>
  }


  /**
   * groupServiceTimes create
   */
  export type groupServiceTimesCreateArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * The data needed to create a groupServiceTimes.
     * 
    **/
    data: XOR<groupServiceTimesCreateInput, groupServiceTimesUncheckedCreateInput>
  }


  /**
   * groupServiceTimes createMany
   */
  export type groupServiceTimesCreateManyArgs = {
    data: Enumerable<groupServiceTimesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * groupServiceTimes update
   */
  export type groupServiceTimesUpdateArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * The data needed to update a groupServiceTimes.
     * 
    **/
    data: XOR<groupServiceTimesUpdateInput, groupServiceTimesUncheckedUpdateInput>
    /**
     * Choose, which groupServiceTimes to update.
     * 
    **/
    where: groupServiceTimesWhereUniqueInput
  }


  /**
   * groupServiceTimes updateMany
   */
  export type groupServiceTimesUpdateManyArgs = {
    data: XOR<groupServiceTimesUpdateManyMutationInput, groupServiceTimesUncheckedUpdateManyInput>
    where?: groupServiceTimesWhereInput
  }


  /**
   * groupServiceTimes upsert
   */
  export type groupServiceTimesUpsertArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * The filter to search for the groupServiceTimes to update in case it exists.
     * 
    **/
    where: groupServiceTimesWhereUniqueInput
    /**
     * In case the groupServiceTimes found by the `where` argument doesn't exist, create a new groupServiceTimes with this data.
     * 
    **/
    create: XOR<groupServiceTimesCreateInput, groupServiceTimesUncheckedCreateInput>
    /**
     * In case the groupServiceTimes was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<groupServiceTimesUpdateInput, groupServiceTimesUncheckedUpdateInput>
  }


  /**
   * groupServiceTimes delete
   */
  export type groupServiceTimesDeleteArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
    /**
     * Filter which groupServiceTimes to delete.
     * 
    **/
    where: groupServiceTimesWhereUniqueInput
  }


  /**
   * groupServiceTimes deleteMany
   */
  export type groupServiceTimesDeleteManyArgs = {
    where?: groupServiceTimesWhereInput
  }


  /**
   * groupServiceTimes without action
   */
  export type groupServiceTimesArgs = {
    /**
     * Select specific fields to fetch from the groupServiceTimes
     * 
    **/
    select?: groupServiceTimesSelect | null
  }



  /**
   * Model serviceTimes
   */


  export type AggregateServiceTimes = {
    _count: ServiceTimesCountAggregateOutputType | null
    _min: ServiceTimesMinAggregateOutputType | null
    _max: ServiceTimesMaxAggregateOutputType | null
  }

  export type ServiceTimesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    serviceId: string | null
    name: string | null
    removed: boolean | null
  }

  export type ServiceTimesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    serviceId: string | null
    name: string | null
    removed: boolean | null
  }

  export type ServiceTimesCountAggregateOutputType = {
    id: number
    churchId: number
    serviceId: number
    name: number
    removed: number
    _all: number
  }


  export type ServiceTimesMinAggregateInputType = {
    id?: true
    churchId?: true
    serviceId?: true
    name?: true
    removed?: true
  }

  export type ServiceTimesMaxAggregateInputType = {
    id?: true
    churchId?: true
    serviceId?: true
    name?: true
    removed?: true
  }

  export type ServiceTimesCountAggregateInputType = {
    id?: true
    churchId?: true
    serviceId?: true
    name?: true
    removed?: true
    _all?: true
  }

  export type ServiceTimesAggregateArgs = {
    /**
     * Filter which serviceTimes to aggregate.
     * 
    **/
    where?: serviceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of serviceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<serviceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: serviceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` serviceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` serviceTimes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned serviceTimes
    **/
    _count?: true | ServiceTimesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ServiceTimesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ServiceTimesMaxAggregateInputType
  }

  export type GetServiceTimesAggregateType<T extends ServiceTimesAggregateArgs> = {
        [P in keyof T & keyof AggregateServiceTimes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateServiceTimes[P]>
      : GetScalarType<T[P], AggregateServiceTimes[P]>
  }




  export type ServiceTimesGroupByArgs = {
    where?: serviceTimesWhereInput
    orderBy?: Enumerable<serviceTimesOrderByWithAggregationInput>
    by: Array<ServiceTimesScalarFieldEnum>
    having?: serviceTimesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ServiceTimesCountAggregateInputType | true
    _min?: ServiceTimesMinAggregateInputType
    _max?: ServiceTimesMaxAggregateInputType
  }


  export type ServiceTimesGroupByOutputType = {
    id: string
    churchId: string | null
    serviceId: string | null
    name: string | null
    removed: boolean | null
    _count: ServiceTimesCountAggregateOutputType | null
    _min: ServiceTimesMinAggregateOutputType | null
    _max: ServiceTimesMaxAggregateOutputType | null
  }

  type GetServiceTimesGroupByPayload<T extends ServiceTimesGroupByArgs> = Promise<
    Array<
      PickArray<ServiceTimesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ServiceTimesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ServiceTimesGroupByOutputType[P]>
            : GetScalarType<T[P], ServiceTimesGroupByOutputType[P]>
        }
      >
    >


  export type serviceTimesSelect = {
    id?: boolean
    churchId?: boolean
    serviceId?: boolean
    name?: boolean
    removed?: boolean
  }

  export type serviceTimesGetPayload<
    S extends boolean | null | undefined | serviceTimesArgs,
    U = keyof S
      > = S extends true
        ? serviceTimes
    : S extends undefined
    ? never
    : S extends serviceTimesArgs | serviceTimesFindManyArgs
    ?'include' extends U
    ? serviceTimes 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof serviceTimes ?serviceTimes [P]
  : 
     never
  } 
    : serviceTimes
  : serviceTimes


  type serviceTimesCountArgs = Merge<
    Omit<serviceTimesFindManyArgs, 'select' | 'include'> & {
      select?: ServiceTimesCountAggregateInputType | true
    }
  >

  export interface serviceTimesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one ServiceTimes that matches the filter.
     * @param {serviceTimesFindUniqueArgs} args - Arguments to find a ServiceTimes
     * @example
     * // Get one ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends serviceTimesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, serviceTimesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'serviceTimes'> extends True ? CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>> : CheckSelect<T, Prisma__serviceTimesClient<serviceTimes | null >, Prisma__serviceTimesClient<serviceTimesGetPayload<T> | null >>

    /**
     * Find the first ServiceTimes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {serviceTimesFindFirstArgs} args - Arguments to find a ServiceTimes
     * @example
     * // Get one ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends serviceTimesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, serviceTimesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'serviceTimes'> extends True ? CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>> : CheckSelect<T, Prisma__serviceTimesClient<serviceTimes | null >, Prisma__serviceTimesClient<serviceTimesGetPayload<T> | null >>

    /**
     * Find zero or more ServiceTimes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {serviceTimesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.findMany()
     * 
     * // Get first 10 ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const serviceTimesWithIdOnly = await prisma.serviceTimes.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends serviceTimesFindManyArgs>(
      args?: SelectSubset<T, serviceTimesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<serviceTimes>>, PrismaPromise<Array<serviceTimesGetPayload<T>>>>

    /**
     * Create a ServiceTimes.
     * @param {serviceTimesCreateArgs} args - Arguments to create a ServiceTimes.
     * @example
     * // Create one ServiceTimes
     * const ServiceTimes = await prisma.serviceTimes.create({
     *   data: {
     *     // ... data to create a ServiceTimes
     *   }
     * })
     * 
    **/
    create<T extends serviceTimesCreateArgs>(
      args: SelectSubset<T, serviceTimesCreateArgs>
    ): CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>>

    /**
     * Create many ServiceTimes.
     *     @param {serviceTimesCreateManyArgs} args - Arguments to create many ServiceTimes.
     *     @example
     *     // Create many ServiceTimes
     *     const serviceTimes = await prisma.serviceTimes.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends serviceTimesCreateManyArgs>(
      args?: SelectSubset<T, serviceTimesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a ServiceTimes.
     * @param {serviceTimesDeleteArgs} args - Arguments to delete one ServiceTimes.
     * @example
     * // Delete one ServiceTimes
     * const ServiceTimes = await prisma.serviceTimes.delete({
     *   where: {
     *     // ... filter to delete one ServiceTimes
     *   }
     * })
     * 
    **/
    delete<T extends serviceTimesDeleteArgs>(
      args: SelectSubset<T, serviceTimesDeleteArgs>
    ): CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>>

    /**
     * Update one ServiceTimes.
     * @param {serviceTimesUpdateArgs} args - Arguments to update one ServiceTimes.
     * @example
     * // Update one ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends serviceTimesUpdateArgs>(
      args: SelectSubset<T, serviceTimesUpdateArgs>
    ): CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>>

    /**
     * Delete zero or more ServiceTimes.
     * @param {serviceTimesDeleteManyArgs} args - Arguments to filter ServiceTimes to delete.
     * @example
     * // Delete a few ServiceTimes
     * const { count } = await prisma.serviceTimes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends serviceTimesDeleteManyArgs>(
      args?: SelectSubset<T, serviceTimesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more ServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {serviceTimesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends serviceTimesUpdateManyArgs>(
      args: SelectSubset<T, serviceTimesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one ServiceTimes.
     * @param {serviceTimesUpsertArgs} args - Arguments to update or create a ServiceTimes.
     * @example
     * // Update or create a ServiceTimes
     * const serviceTimes = await prisma.serviceTimes.upsert({
     *   create: {
     *     // ... data to create a ServiceTimes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ServiceTimes we want to update
     *   }
     * })
    **/
    upsert<T extends serviceTimesUpsertArgs>(
      args: SelectSubset<T, serviceTimesUpsertArgs>
    ): CheckSelect<T, Prisma__serviceTimesClient<serviceTimes>, Prisma__serviceTimesClient<serviceTimesGetPayload<T>>>

    /**
     * Count the number of ServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {serviceTimesCountArgs} args - Arguments to filter ServiceTimes to count.
     * @example
     * // Count the number of ServiceTimes
     * const count = await prisma.serviceTimes.count({
     *   where: {
     *     // ... the filter for the ServiceTimes we want to count
     *   }
     * })
    **/
    count<T extends serviceTimesCountArgs>(
      args?: Subset<T, serviceTimesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ServiceTimesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ServiceTimesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ServiceTimesAggregateArgs>(args: Subset<T, ServiceTimesAggregateArgs>): PrismaPromise<GetServiceTimesAggregateType<T>>

    /**
     * Group by ServiceTimes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ServiceTimesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ServiceTimesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ServiceTimesGroupByArgs['orderBy'] }
        : { orderBy?: ServiceTimesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ServiceTimesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetServiceTimesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for serviceTimes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__serviceTimesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * serviceTimes findUnique
   */
  export type serviceTimesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * Throw an Error if a serviceTimes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which serviceTimes to fetch.
     * 
    **/
    where: serviceTimesWhereUniqueInput
  }


  /**
   * serviceTimes findFirst
   */
  export type serviceTimesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * Throw an Error if a serviceTimes can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which serviceTimes to fetch.
     * 
    **/
    where?: serviceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of serviceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<serviceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for serviceTimes.
     * 
    **/
    cursor?: serviceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` serviceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` serviceTimes.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of serviceTimes.
     * 
    **/
    distinct?: Enumerable<ServiceTimesScalarFieldEnum>
  }


  /**
   * serviceTimes findMany
   */
  export type serviceTimesFindManyArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * Filter, which serviceTimes to fetch.
     * 
    **/
    where?: serviceTimesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of serviceTimes to fetch.
     * 
    **/
    orderBy?: Enumerable<serviceTimesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing serviceTimes.
     * 
    **/
    cursor?: serviceTimesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` serviceTimes from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` serviceTimes.
     * 
    **/
    skip?: number
    distinct?: Enumerable<ServiceTimesScalarFieldEnum>
  }


  /**
   * serviceTimes create
   */
  export type serviceTimesCreateArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * The data needed to create a serviceTimes.
     * 
    **/
    data: XOR<serviceTimesCreateInput, serviceTimesUncheckedCreateInput>
  }


  /**
   * serviceTimes createMany
   */
  export type serviceTimesCreateManyArgs = {
    data: Enumerable<serviceTimesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * serviceTimes update
   */
  export type serviceTimesUpdateArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * The data needed to update a serviceTimes.
     * 
    **/
    data: XOR<serviceTimesUpdateInput, serviceTimesUncheckedUpdateInput>
    /**
     * Choose, which serviceTimes to update.
     * 
    **/
    where: serviceTimesWhereUniqueInput
  }


  /**
   * serviceTimes updateMany
   */
  export type serviceTimesUpdateManyArgs = {
    data: XOR<serviceTimesUpdateManyMutationInput, serviceTimesUncheckedUpdateManyInput>
    where?: serviceTimesWhereInput
  }


  /**
   * serviceTimes upsert
   */
  export type serviceTimesUpsertArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * The filter to search for the serviceTimes to update in case it exists.
     * 
    **/
    where: serviceTimesWhereUniqueInput
    /**
     * In case the serviceTimes found by the `where` argument doesn't exist, create a new serviceTimes with this data.
     * 
    **/
    create: XOR<serviceTimesCreateInput, serviceTimesUncheckedCreateInput>
    /**
     * In case the serviceTimes was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<serviceTimesUpdateInput, serviceTimesUncheckedUpdateInput>
  }


  /**
   * serviceTimes delete
   */
  export type serviceTimesDeleteArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
    /**
     * Filter which serviceTimes to delete.
     * 
    **/
    where: serviceTimesWhereUniqueInput
  }


  /**
   * serviceTimes deleteMany
   */
  export type serviceTimesDeleteManyArgs = {
    where?: serviceTimesWhereInput
  }


  /**
   * serviceTimes without action
   */
  export type serviceTimesArgs = {
    /**
     * Select specific fields to fetch from the serviceTimes
     * 
    **/
    select?: serviceTimesSelect | null
  }



  /**
   * Model services
   */


  export type AggregateServices = {
    _count: ServicesCountAggregateOutputType | null
    _min: ServicesMinAggregateOutputType | null
    _max: ServicesMaxAggregateOutputType | null
  }

  export type ServicesMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    campusId: string | null
    name: string | null
    removed: boolean | null
  }

  export type ServicesMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    campusId: string | null
    name: string | null
    removed: boolean | null
  }

  export type ServicesCountAggregateOutputType = {
    id: number
    churchId: number
    campusId: number
    name: number
    removed: number
    _all: number
  }


  export type ServicesMinAggregateInputType = {
    id?: true
    churchId?: true
    campusId?: true
    name?: true
    removed?: true
  }

  export type ServicesMaxAggregateInputType = {
    id?: true
    churchId?: true
    campusId?: true
    name?: true
    removed?: true
  }

  export type ServicesCountAggregateInputType = {
    id?: true
    churchId?: true
    campusId?: true
    name?: true
    removed?: true
    _all?: true
  }

  export type ServicesAggregateArgs = {
    /**
     * Filter which services to aggregate.
     * 
    **/
    where?: servicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of services to fetch.
     * 
    **/
    orderBy?: Enumerable<servicesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: servicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` services from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` services.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned services
    **/
    _count?: true | ServicesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ServicesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ServicesMaxAggregateInputType
  }

  export type GetServicesAggregateType<T extends ServicesAggregateArgs> = {
        [P in keyof T & keyof AggregateServices]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateServices[P]>
      : GetScalarType<T[P], AggregateServices[P]>
  }




  export type ServicesGroupByArgs = {
    where?: servicesWhereInput
    orderBy?: Enumerable<servicesOrderByWithAggregationInput>
    by: Array<ServicesScalarFieldEnum>
    having?: servicesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ServicesCountAggregateInputType | true
    _min?: ServicesMinAggregateInputType
    _max?: ServicesMaxAggregateInputType
  }


  export type ServicesGroupByOutputType = {
    id: string
    churchId: string | null
    campusId: string | null
    name: string | null
    removed: boolean | null
    _count: ServicesCountAggregateOutputType | null
    _min: ServicesMinAggregateOutputType | null
    _max: ServicesMaxAggregateOutputType | null
  }

  type GetServicesGroupByPayload<T extends ServicesGroupByArgs> = Promise<
    Array<
      PickArray<ServicesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ServicesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ServicesGroupByOutputType[P]>
            : GetScalarType<T[P], ServicesGroupByOutputType[P]>
        }
      >
    >


  export type servicesSelect = {
    id?: boolean
    churchId?: boolean
    campusId?: boolean
    name?: boolean
    removed?: boolean
  }

  export type servicesGetPayload<
    S extends boolean | null | undefined | servicesArgs,
    U = keyof S
      > = S extends true
        ? services
    : S extends undefined
    ? never
    : S extends servicesArgs | servicesFindManyArgs
    ?'include' extends U
    ? services 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof services ?services [P]
  : 
     never
  } 
    : services
  : services


  type servicesCountArgs = Merge<
    Omit<servicesFindManyArgs, 'select' | 'include'> & {
      select?: ServicesCountAggregateInputType | true
    }
  >

  export interface servicesDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Services that matches the filter.
     * @param {servicesFindUniqueArgs} args - Arguments to find a Services
     * @example
     * // Get one Services
     * const services = await prisma.services.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends servicesFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, servicesFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'services'> extends True ? CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>> : CheckSelect<T, Prisma__servicesClient<services | null >, Prisma__servicesClient<servicesGetPayload<T> | null >>

    /**
     * Find the first Services that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {servicesFindFirstArgs} args - Arguments to find a Services
     * @example
     * // Get one Services
     * const services = await prisma.services.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends servicesFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, servicesFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'services'> extends True ? CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>> : CheckSelect<T, Prisma__servicesClient<services | null >, Prisma__servicesClient<servicesGetPayload<T> | null >>

    /**
     * Find zero or more Services that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {servicesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Services
     * const services = await prisma.services.findMany()
     * 
     * // Get first 10 Services
     * const services = await prisma.services.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const servicesWithIdOnly = await prisma.services.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends servicesFindManyArgs>(
      args?: SelectSubset<T, servicesFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<services>>, PrismaPromise<Array<servicesGetPayload<T>>>>

    /**
     * Create a Services.
     * @param {servicesCreateArgs} args - Arguments to create a Services.
     * @example
     * // Create one Services
     * const Services = await prisma.services.create({
     *   data: {
     *     // ... data to create a Services
     *   }
     * })
     * 
    **/
    create<T extends servicesCreateArgs>(
      args: SelectSubset<T, servicesCreateArgs>
    ): CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>>

    /**
     * Create many Services.
     *     @param {servicesCreateManyArgs} args - Arguments to create many Services.
     *     @example
     *     // Create many Services
     *     const services = await prisma.services.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends servicesCreateManyArgs>(
      args?: SelectSubset<T, servicesCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Services.
     * @param {servicesDeleteArgs} args - Arguments to delete one Services.
     * @example
     * // Delete one Services
     * const Services = await prisma.services.delete({
     *   where: {
     *     // ... filter to delete one Services
     *   }
     * })
     * 
    **/
    delete<T extends servicesDeleteArgs>(
      args: SelectSubset<T, servicesDeleteArgs>
    ): CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>>

    /**
     * Update one Services.
     * @param {servicesUpdateArgs} args - Arguments to update one Services.
     * @example
     * // Update one Services
     * const services = await prisma.services.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends servicesUpdateArgs>(
      args: SelectSubset<T, servicesUpdateArgs>
    ): CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>>

    /**
     * Delete zero or more Services.
     * @param {servicesDeleteManyArgs} args - Arguments to filter Services to delete.
     * @example
     * // Delete a few Services
     * const { count } = await prisma.services.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends servicesDeleteManyArgs>(
      args?: SelectSubset<T, servicesDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Services.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {servicesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Services
     * const services = await prisma.services.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends servicesUpdateManyArgs>(
      args: SelectSubset<T, servicesUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Services.
     * @param {servicesUpsertArgs} args - Arguments to update or create a Services.
     * @example
     * // Update or create a Services
     * const services = await prisma.services.upsert({
     *   create: {
     *     // ... data to create a Services
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Services we want to update
     *   }
     * })
    **/
    upsert<T extends servicesUpsertArgs>(
      args: SelectSubset<T, servicesUpsertArgs>
    ): CheckSelect<T, Prisma__servicesClient<services>, Prisma__servicesClient<servicesGetPayload<T>>>

    /**
     * Count the number of Services.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {servicesCountArgs} args - Arguments to filter Services to count.
     * @example
     * // Count the number of Services
     * const count = await prisma.services.count({
     *   where: {
     *     // ... the filter for the Services we want to count
     *   }
     * })
    **/
    count<T extends servicesCountArgs>(
      args?: Subset<T, servicesCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ServicesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Services.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ServicesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ServicesAggregateArgs>(args: Subset<T, ServicesAggregateArgs>): PrismaPromise<GetServicesAggregateType<T>>

    /**
     * Group by Services.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ServicesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ServicesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ServicesGroupByArgs['orderBy'] }
        : { orderBy?: ServicesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ServicesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetServicesGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for services.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__servicesClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * services findUnique
   */
  export type servicesFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * Throw an Error if a services can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which services to fetch.
     * 
    **/
    where: servicesWhereUniqueInput
  }


  /**
   * services findFirst
   */
  export type servicesFindFirstArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * Throw an Error if a services can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which services to fetch.
     * 
    **/
    where?: servicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of services to fetch.
     * 
    **/
    orderBy?: Enumerable<servicesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for services.
     * 
    **/
    cursor?: servicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` services from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` services.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of services.
     * 
    **/
    distinct?: Enumerable<ServicesScalarFieldEnum>
  }


  /**
   * services findMany
   */
  export type servicesFindManyArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * Filter, which services to fetch.
     * 
    **/
    where?: servicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of services to fetch.
     * 
    **/
    orderBy?: Enumerable<servicesOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing services.
     * 
    **/
    cursor?: servicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` services from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` services.
     * 
    **/
    skip?: number
    distinct?: Enumerable<ServicesScalarFieldEnum>
  }


  /**
   * services create
   */
  export type servicesCreateArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * The data needed to create a services.
     * 
    **/
    data: XOR<servicesCreateInput, servicesUncheckedCreateInput>
  }


  /**
   * services createMany
   */
  export type servicesCreateManyArgs = {
    data: Enumerable<servicesCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * services update
   */
  export type servicesUpdateArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * The data needed to update a services.
     * 
    **/
    data: XOR<servicesUpdateInput, servicesUncheckedUpdateInput>
    /**
     * Choose, which services to update.
     * 
    **/
    where: servicesWhereUniqueInput
  }


  /**
   * services updateMany
   */
  export type servicesUpdateManyArgs = {
    data: XOR<servicesUpdateManyMutationInput, servicesUncheckedUpdateManyInput>
    where?: servicesWhereInput
  }


  /**
   * services upsert
   */
  export type servicesUpsertArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * The filter to search for the services to update in case it exists.
     * 
    **/
    where: servicesWhereUniqueInput
    /**
     * In case the services found by the `where` argument doesn't exist, create a new services with this data.
     * 
    **/
    create: XOR<servicesCreateInput, servicesUncheckedCreateInput>
    /**
     * In case the services was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<servicesUpdateInput, servicesUncheckedUpdateInput>
  }


  /**
   * services delete
   */
  export type servicesDeleteArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
    /**
     * Filter which services to delete.
     * 
    **/
    where: servicesWhereUniqueInput
  }


  /**
   * services deleteMany
   */
  export type servicesDeleteManyArgs = {
    where?: servicesWhereInput
  }


  /**
   * services without action
   */
  export type servicesArgs = {
    /**
     * Select specific fields to fetch from the services
     * 
    **/
    select?: servicesSelect | null
  }



  /**
   * Model sessions
   */


  export type AggregateSessions = {
    _count: SessionsCountAggregateOutputType | null
    _min: SessionsMinAggregateOutputType | null
    _max: SessionsMaxAggregateOutputType | null
  }

  export type SessionsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
    sessionDate: Date | null
  }

  export type SessionsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
    sessionDate: Date | null
  }

  export type SessionsCountAggregateOutputType = {
    id: number
    churchId: number
    groupId: number
    serviceTimeId: number
    sessionDate: number
    _all: number
  }


  export type SessionsMinAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
    sessionDate?: true
  }

  export type SessionsMaxAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
    sessionDate?: true
  }

  export type SessionsCountAggregateInputType = {
    id?: true
    churchId?: true
    groupId?: true
    serviceTimeId?: true
    sessionDate?: true
    _all?: true
  }

  export type SessionsAggregateArgs = {
    /**
     * Filter which sessions to aggregate.
     * 
    **/
    where?: sessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of sessions to fetch.
     * 
    **/
    orderBy?: Enumerable<sessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: sessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` sessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` sessions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned sessions
    **/
    _count?: true | SessionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SessionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SessionsMaxAggregateInputType
  }

  export type GetSessionsAggregateType<T extends SessionsAggregateArgs> = {
        [P in keyof T & keyof AggregateSessions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSessions[P]>
      : GetScalarType<T[P], AggregateSessions[P]>
  }




  export type SessionsGroupByArgs = {
    where?: sessionsWhereInput
    orderBy?: Enumerable<sessionsOrderByWithAggregationInput>
    by: Array<SessionsScalarFieldEnum>
    having?: sessionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SessionsCountAggregateInputType | true
    _min?: SessionsMinAggregateInputType
    _max?: SessionsMaxAggregateInputType
  }


  export type SessionsGroupByOutputType = {
    id: string
    churchId: string | null
    groupId: string | null
    serviceTimeId: string | null
    sessionDate: Date | null
    _count: SessionsCountAggregateOutputType | null
    _min: SessionsMinAggregateOutputType | null
    _max: SessionsMaxAggregateOutputType | null
  }

  type GetSessionsGroupByPayload<T extends SessionsGroupByArgs> = Promise<
    Array<
      PickArray<SessionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SessionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SessionsGroupByOutputType[P]>
            : GetScalarType<T[P], SessionsGroupByOutputType[P]>
        }
      >
    >


  export type sessionsSelect = {
    id?: boolean
    churchId?: boolean
    groupId?: boolean
    serviceTimeId?: boolean
    sessionDate?: boolean
    visits?: boolean | visitSessionsFindManyArgs
    _count?: boolean | SessionsCountOutputTypeArgs
  }

  export type sessionsInclude = {
    visits?: boolean | visitSessionsFindManyArgs
    _count?: boolean | SessionsCountOutputTypeArgs
  }

  export type sessionsGetPayload<
    S extends boolean | null | undefined | sessionsArgs,
    U = keyof S
      > = S extends true
        ? sessions
    : S extends undefined
    ? never
    : S extends sessionsArgs | sessionsFindManyArgs
    ?'include' extends U
    ? sessions  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'visits'
        ? Array < visitSessionsGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? SessionsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof sessions ?sessions [P]
  : 
          P extends 'visits'
        ? Array < visitSessionsGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? SessionsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : sessions
  : sessions


  type sessionsCountArgs = Merge<
    Omit<sessionsFindManyArgs, 'select' | 'include'> & {
      select?: SessionsCountAggregateInputType | true
    }
  >

  export interface sessionsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Sessions that matches the filter.
     * @param {sessionsFindUniqueArgs} args - Arguments to find a Sessions
     * @example
     * // Get one Sessions
     * const sessions = await prisma.sessions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends sessionsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, sessionsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'sessions'> extends True ? CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>> : CheckSelect<T, Prisma__sessionsClient<sessions | null >, Prisma__sessionsClient<sessionsGetPayload<T> | null >>

    /**
     * Find the first Sessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sessionsFindFirstArgs} args - Arguments to find a Sessions
     * @example
     * // Get one Sessions
     * const sessions = await prisma.sessions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends sessionsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, sessionsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'sessions'> extends True ? CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>> : CheckSelect<T, Prisma__sessionsClient<sessions | null >, Prisma__sessionsClient<sessionsGetPayload<T> | null >>

    /**
     * Find zero or more Sessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sessionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Sessions
     * const sessions = await prisma.sessions.findMany()
     * 
     * // Get first 10 Sessions
     * const sessions = await prisma.sessions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sessionsWithIdOnly = await prisma.sessions.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends sessionsFindManyArgs>(
      args?: SelectSubset<T, sessionsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<sessions>>, PrismaPromise<Array<sessionsGetPayload<T>>>>

    /**
     * Create a Sessions.
     * @param {sessionsCreateArgs} args - Arguments to create a Sessions.
     * @example
     * // Create one Sessions
     * const Sessions = await prisma.sessions.create({
     *   data: {
     *     // ... data to create a Sessions
     *   }
     * })
     * 
    **/
    create<T extends sessionsCreateArgs>(
      args: SelectSubset<T, sessionsCreateArgs>
    ): CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>>

    /**
     * Create many Sessions.
     *     @param {sessionsCreateManyArgs} args - Arguments to create many Sessions.
     *     @example
     *     // Create many Sessions
     *     const sessions = await prisma.sessions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends sessionsCreateManyArgs>(
      args?: SelectSubset<T, sessionsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Sessions.
     * @param {sessionsDeleteArgs} args - Arguments to delete one Sessions.
     * @example
     * // Delete one Sessions
     * const Sessions = await prisma.sessions.delete({
     *   where: {
     *     // ... filter to delete one Sessions
     *   }
     * })
     * 
    **/
    delete<T extends sessionsDeleteArgs>(
      args: SelectSubset<T, sessionsDeleteArgs>
    ): CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>>

    /**
     * Update one Sessions.
     * @param {sessionsUpdateArgs} args - Arguments to update one Sessions.
     * @example
     * // Update one Sessions
     * const sessions = await prisma.sessions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends sessionsUpdateArgs>(
      args: SelectSubset<T, sessionsUpdateArgs>
    ): CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>>

    /**
     * Delete zero or more Sessions.
     * @param {sessionsDeleteManyArgs} args - Arguments to filter Sessions to delete.
     * @example
     * // Delete a few Sessions
     * const { count } = await prisma.sessions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends sessionsDeleteManyArgs>(
      args?: SelectSubset<T, sessionsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sessionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Sessions
     * const sessions = await prisma.sessions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends sessionsUpdateManyArgs>(
      args: SelectSubset<T, sessionsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Sessions.
     * @param {sessionsUpsertArgs} args - Arguments to update or create a Sessions.
     * @example
     * // Update or create a Sessions
     * const sessions = await prisma.sessions.upsert({
     *   create: {
     *     // ... data to create a Sessions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Sessions we want to update
     *   }
     * })
    **/
    upsert<T extends sessionsUpsertArgs>(
      args: SelectSubset<T, sessionsUpsertArgs>
    ): CheckSelect<T, Prisma__sessionsClient<sessions>, Prisma__sessionsClient<sessionsGetPayload<T>>>

    /**
     * Count the number of Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sessionsCountArgs} args - Arguments to filter Sessions to count.
     * @example
     * // Count the number of Sessions
     * const count = await prisma.sessions.count({
     *   where: {
     *     // ... the filter for the Sessions we want to count
     *   }
     * })
    **/
    count<T extends sessionsCountArgs>(
      args?: Subset<T, sessionsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SessionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SessionsAggregateArgs>(args: Subset<T, SessionsAggregateArgs>): PrismaPromise<GetSessionsAggregateType<T>>

    /**
     * Group by Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SessionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SessionsGroupByArgs['orderBy'] }
        : { orderBy?: SessionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SessionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSessionsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for sessions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__sessionsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    visits<T extends visitSessionsFindManyArgs = {}>(args?: Subset<T, visitSessionsFindManyArgs>): CheckSelect<T, PrismaPromise<Array<visitSessions>>, PrismaPromise<Array<visitSessionsGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * sessions findUnique
   */
  export type sessionsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * Throw an Error if a sessions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which sessions to fetch.
     * 
    **/
    where: sessionsWhereUniqueInput
  }


  /**
   * sessions findFirst
   */
  export type sessionsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * Throw an Error if a sessions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which sessions to fetch.
     * 
    **/
    where?: sessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of sessions to fetch.
     * 
    **/
    orderBy?: Enumerable<sessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for sessions.
     * 
    **/
    cursor?: sessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` sessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` sessions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of sessions.
     * 
    **/
    distinct?: Enumerable<SessionsScalarFieldEnum>
  }


  /**
   * sessions findMany
   */
  export type sessionsFindManyArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * Filter, which sessions to fetch.
     * 
    **/
    where?: sessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of sessions to fetch.
     * 
    **/
    orderBy?: Enumerable<sessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing sessions.
     * 
    **/
    cursor?: sessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` sessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` sessions.
     * 
    **/
    skip?: number
    distinct?: Enumerable<SessionsScalarFieldEnum>
  }


  /**
   * sessions create
   */
  export type sessionsCreateArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * The data needed to create a sessions.
     * 
    **/
    data: XOR<sessionsCreateInput, sessionsUncheckedCreateInput>
  }


  /**
   * sessions createMany
   */
  export type sessionsCreateManyArgs = {
    data: Enumerable<sessionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * sessions update
   */
  export type sessionsUpdateArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * The data needed to update a sessions.
     * 
    **/
    data: XOR<sessionsUpdateInput, sessionsUncheckedUpdateInput>
    /**
     * Choose, which sessions to update.
     * 
    **/
    where: sessionsWhereUniqueInput
  }


  /**
   * sessions updateMany
   */
  export type sessionsUpdateManyArgs = {
    data: XOR<sessionsUpdateManyMutationInput, sessionsUncheckedUpdateManyInput>
    where?: sessionsWhereInput
  }


  /**
   * sessions upsert
   */
  export type sessionsUpsertArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * The filter to search for the sessions to update in case it exists.
     * 
    **/
    where: sessionsWhereUniqueInput
    /**
     * In case the sessions found by the `where` argument doesn't exist, create a new sessions with this data.
     * 
    **/
    create: XOR<sessionsCreateInput, sessionsUncheckedCreateInput>
    /**
     * In case the sessions was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<sessionsUpdateInput, sessionsUncheckedUpdateInput>
  }


  /**
   * sessions delete
   */
  export type sessionsDeleteArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
    /**
     * Filter which sessions to delete.
     * 
    **/
    where: sessionsWhereUniqueInput
  }


  /**
   * sessions deleteMany
   */
  export type sessionsDeleteManyArgs = {
    where?: sessionsWhereInput
  }


  /**
   * sessions without action
   */
  export type sessionsArgs = {
    /**
     * Select specific fields to fetch from the sessions
     * 
    **/
    select?: sessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: sessionsInclude | null
  }



  /**
   * Model visitSessions
   */


  export type AggregateVisitSessions = {
    _count: VisitSessionsCountAggregateOutputType | null
    _min: VisitSessionsMinAggregateOutputType | null
    _max: VisitSessionsMaxAggregateOutputType | null
  }

  export type VisitSessionsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    visitId: string | null
    sessionId: string | null
  }

  export type VisitSessionsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    visitId: string | null
    sessionId: string | null
  }

  export type VisitSessionsCountAggregateOutputType = {
    id: number
    churchId: number
    visitId: number
    sessionId: number
    _all: number
  }


  export type VisitSessionsMinAggregateInputType = {
    id?: true
    churchId?: true
    visitId?: true
    sessionId?: true
  }

  export type VisitSessionsMaxAggregateInputType = {
    id?: true
    churchId?: true
    visitId?: true
    sessionId?: true
  }

  export type VisitSessionsCountAggregateInputType = {
    id?: true
    churchId?: true
    visitId?: true
    sessionId?: true
    _all?: true
  }

  export type VisitSessionsAggregateArgs = {
    /**
     * Filter which visitSessions to aggregate.
     * 
    **/
    where?: visitSessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visitSessions to fetch.
     * 
    **/
    orderBy?: Enumerable<visitSessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: visitSessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visitSessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visitSessions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned visitSessions
    **/
    _count?: true | VisitSessionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VisitSessionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VisitSessionsMaxAggregateInputType
  }

  export type GetVisitSessionsAggregateType<T extends VisitSessionsAggregateArgs> = {
        [P in keyof T & keyof AggregateVisitSessions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVisitSessions[P]>
      : GetScalarType<T[P], AggregateVisitSessions[P]>
  }




  export type VisitSessionsGroupByArgs = {
    where?: visitSessionsWhereInput
    orderBy?: Enumerable<visitSessionsOrderByWithAggregationInput>
    by: Array<VisitSessionsScalarFieldEnum>
    having?: visitSessionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VisitSessionsCountAggregateInputType | true
    _min?: VisitSessionsMinAggregateInputType
    _max?: VisitSessionsMaxAggregateInputType
  }


  export type VisitSessionsGroupByOutputType = {
    id: string
    churchId: string | null
    visitId: string | null
    sessionId: string | null
    _count: VisitSessionsCountAggregateOutputType | null
    _min: VisitSessionsMinAggregateOutputType | null
    _max: VisitSessionsMaxAggregateOutputType | null
  }

  type GetVisitSessionsGroupByPayload<T extends VisitSessionsGroupByArgs> = Promise<
    Array<
      PickArray<VisitSessionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VisitSessionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VisitSessionsGroupByOutputType[P]>
            : GetScalarType<T[P], VisitSessionsGroupByOutputType[P]>
        }
      >
    >


  export type visitSessionsSelect = {
    id?: boolean
    churchId?: boolean
    visitId?: boolean
    sessionId?: boolean
    visit?: boolean | visitsArgs
    session?: boolean | sessionsArgs
  }

  export type visitSessionsInclude = {
    visit?: boolean | visitsArgs
    session?: boolean | sessionsArgs
  }

  export type visitSessionsGetPayload<
    S extends boolean | null | undefined | visitSessionsArgs,
    U = keyof S
      > = S extends true
        ? visitSessions
    : S extends undefined
    ? never
    : S extends visitSessionsArgs | visitSessionsFindManyArgs
    ?'include' extends U
    ? visitSessions  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'visit'
        ? visitsGetPayload<S['include'][P]> | null :
        P extends 'session'
        ? sessionsGetPayload<S['include'][P]> | null : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof visitSessions ?visitSessions [P]
  : 
          P extends 'visit'
        ? visitsGetPayload<S['select'][P]> | null :
        P extends 'session'
        ? sessionsGetPayload<S['select'][P]> | null : never
  } 
    : visitSessions
  : visitSessions


  type visitSessionsCountArgs = Merge<
    Omit<visitSessionsFindManyArgs, 'select' | 'include'> & {
      select?: VisitSessionsCountAggregateInputType | true
    }
  >

  export interface visitSessionsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one VisitSessions that matches the filter.
     * @param {visitSessionsFindUniqueArgs} args - Arguments to find a VisitSessions
     * @example
     * // Get one VisitSessions
     * const visitSessions = await prisma.visitSessions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends visitSessionsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, visitSessionsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'visitSessions'> extends True ? CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>> : CheckSelect<T, Prisma__visitSessionsClient<visitSessions | null >, Prisma__visitSessionsClient<visitSessionsGetPayload<T> | null >>

    /**
     * Find the first VisitSessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitSessionsFindFirstArgs} args - Arguments to find a VisitSessions
     * @example
     * // Get one VisitSessions
     * const visitSessions = await prisma.visitSessions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends visitSessionsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, visitSessionsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'visitSessions'> extends True ? CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>> : CheckSelect<T, Prisma__visitSessionsClient<visitSessions | null >, Prisma__visitSessionsClient<visitSessionsGetPayload<T> | null >>

    /**
     * Find zero or more VisitSessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitSessionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VisitSessions
     * const visitSessions = await prisma.visitSessions.findMany()
     * 
     * // Get first 10 VisitSessions
     * const visitSessions = await prisma.visitSessions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const visitSessionsWithIdOnly = await prisma.visitSessions.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends visitSessionsFindManyArgs>(
      args?: SelectSubset<T, visitSessionsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<visitSessions>>, PrismaPromise<Array<visitSessionsGetPayload<T>>>>

    /**
     * Create a VisitSessions.
     * @param {visitSessionsCreateArgs} args - Arguments to create a VisitSessions.
     * @example
     * // Create one VisitSessions
     * const VisitSessions = await prisma.visitSessions.create({
     *   data: {
     *     // ... data to create a VisitSessions
     *   }
     * })
     * 
    **/
    create<T extends visitSessionsCreateArgs>(
      args: SelectSubset<T, visitSessionsCreateArgs>
    ): CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>>

    /**
     * Create many VisitSessions.
     *     @param {visitSessionsCreateManyArgs} args - Arguments to create many VisitSessions.
     *     @example
     *     // Create many VisitSessions
     *     const visitSessions = await prisma.visitSessions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends visitSessionsCreateManyArgs>(
      args?: SelectSubset<T, visitSessionsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a VisitSessions.
     * @param {visitSessionsDeleteArgs} args - Arguments to delete one VisitSessions.
     * @example
     * // Delete one VisitSessions
     * const VisitSessions = await prisma.visitSessions.delete({
     *   where: {
     *     // ... filter to delete one VisitSessions
     *   }
     * })
     * 
    **/
    delete<T extends visitSessionsDeleteArgs>(
      args: SelectSubset<T, visitSessionsDeleteArgs>
    ): CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>>

    /**
     * Update one VisitSessions.
     * @param {visitSessionsUpdateArgs} args - Arguments to update one VisitSessions.
     * @example
     * // Update one VisitSessions
     * const visitSessions = await prisma.visitSessions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends visitSessionsUpdateArgs>(
      args: SelectSubset<T, visitSessionsUpdateArgs>
    ): CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>>

    /**
     * Delete zero or more VisitSessions.
     * @param {visitSessionsDeleteManyArgs} args - Arguments to filter VisitSessions to delete.
     * @example
     * // Delete a few VisitSessions
     * const { count } = await prisma.visitSessions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends visitSessionsDeleteManyArgs>(
      args?: SelectSubset<T, visitSessionsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more VisitSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitSessionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VisitSessions
     * const visitSessions = await prisma.visitSessions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends visitSessionsUpdateManyArgs>(
      args: SelectSubset<T, visitSessionsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one VisitSessions.
     * @param {visitSessionsUpsertArgs} args - Arguments to update or create a VisitSessions.
     * @example
     * // Update or create a VisitSessions
     * const visitSessions = await prisma.visitSessions.upsert({
     *   create: {
     *     // ... data to create a VisitSessions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VisitSessions we want to update
     *   }
     * })
    **/
    upsert<T extends visitSessionsUpsertArgs>(
      args: SelectSubset<T, visitSessionsUpsertArgs>
    ): CheckSelect<T, Prisma__visitSessionsClient<visitSessions>, Prisma__visitSessionsClient<visitSessionsGetPayload<T>>>

    /**
     * Count the number of VisitSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitSessionsCountArgs} args - Arguments to filter VisitSessions to count.
     * @example
     * // Count the number of VisitSessions
     * const count = await prisma.visitSessions.count({
     *   where: {
     *     // ... the filter for the VisitSessions we want to count
     *   }
     * })
    **/
    count<T extends visitSessionsCountArgs>(
      args?: Subset<T, visitSessionsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VisitSessionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VisitSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VisitSessionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VisitSessionsAggregateArgs>(args: Subset<T, VisitSessionsAggregateArgs>): PrismaPromise<GetVisitSessionsAggregateType<T>>

    /**
     * Group by VisitSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VisitSessionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VisitSessionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VisitSessionsGroupByArgs['orderBy'] }
        : { orderBy?: VisitSessionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VisitSessionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVisitSessionsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for visitSessions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__visitSessionsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    visit<T extends visitsArgs = {}>(args?: Subset<T, visitsArgs>): CheckSelect<T, Prisma__visitsClient<visits | null >, Prisma__visitsClient<visitsGetPayload<T> | null >>;

    session<T extends sessionsArgs = {}>(args?: Subset<T, sessionsArgs>): CheckSelect<T, Prisma__sessionsClient<sessions | null >, Prisma__sessionsClient<sessionsGetPayload<T> | null >>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * visitSessions findUnique
   */
  export type visitSessionsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * Throw an Error if a visitSessions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which visitSessions to fetch.
     * 
    **/
    where: visitSessionsWhereUniqueInput
  }


  /**
   * visitSessions findFirst
   */
  export type visitSessionsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * Throw an Error if a visitSessions can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which visitSessions to fetch.
     * 
    **/
    where?: visitSessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visitSessions to fetch.
     * 
    **/
    orderBy?: Enumerable<visitSessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for visitSessions.
     * 
    **/
    cursor?: visitSessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visitSessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visitSessions.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of visitSessions.
     * 
    **/
    distinct?: Enumerable<VisitSessionsScalarFieldEnum>
  }


  /**
   * visitSessions findMany
   */
  export type visitSessionsFindManyArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * Filter, which visitSessions to fetch.
     * 
    **/
    where?: visitSessionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visitSessions to fetch.
     * 
    **/
    orderBy?: Enumerable<visitSessionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing visitSessions.
     * 
    **/
    cursor?: visitSessionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visitSessions from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visitSessions.
     * 
    **/
    skip?: number
    distinct?: Enumerable<VisitSessionsScalarFieldEnum>
  }


  /**
   * visitSessions create
   */
  export type visitSessionsCreateArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * The data needed to create a visitSessions.
     * 
    **/
    data: XOR<visitSessionsCreateInput, visitSessionsUncheckedCreateInput>
  }


  /**
   * visitSessions createMany
   */
  export type visitSessionsCreateManyArgs = {
    data: Enumerable<visitSessionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * visitSessions update
   */
  export type visitSessionsUpdateArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * The data needed to update a visitSessions.
     * 
    **/
    data: XOR<visitSessionsUpdateInput, visitSessionsUncheckedUpdateInput>
    /**
     * Choose, which visitSessions to update.
     * 
    **/
    where: visitSessionsWhereUniqueInput
  }


  /**
   * visitSessions updateMany
   */
  export type visitSessionsUpdateManyArgs = {
    data: XOR<visitSessionsUpdateManyMutationInput, visitSessionsUncheckedUpdateManyInput>
    where?: visitSessionsWhereInput
  }


  /**
   * visitSessions upsert
   */
  export type visitSessionsUpsertArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * The filter to search for the visitSessions to update in case it exists.
     * 
    **/
    where: visitSessionsWhereUniqueInput
    /**
     * In case the visitSessions found by the `where` argument doesn't exist, create a new visitSessions with this data.
     * 
    **/
    create: XOR<visitSessionsCreateInput, visitSessionsUncheckedCreateInput>
    /**
     * In case the visitSessions was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<visitSessionsUpdateInput, visitSessionsUncheckedUpdateInput>
  }


  /**
   * visitSessions delete
   */
  export type visitSessionsDeleteArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
    /**
     * Filter which visitSessions to delete.
     * 
    **/
    where: visitSessionsWhereUniqueInput
  }


  /**
   * visitSessions deleteMany
   */
  export type visitSessionsDeleteManyArgs = {
    where?: visitSessionsWhereInput
  }


  /**
   * visitSessions without action
   */
  export type visitSessionsArgs = {
    /**
     * Select specific fields to fetch from the visitSessions
     * 
    **/
    select?: visitSessionsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitSessionsInclude | null
  }



  /**
   * Model visits
   */


  export type AggregateVisits = {
    _count: VisitsCountAggregateOutputType | null
    _min: VisitsMinAggregateOutputType | null
    _max: VisitsMaxAggregateOutputType | null
  }

  export type VisitsMinAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
    serviceId: string | null
    groupId: string | null
    visitDate: Date | null
    checkinTime: Date | null
    addedBy: string | null
  }

  export type VisitsMaxAggregateOutputType = {
    id: string | null
    churchId: string | null
    personId: string | null
    serviceId: string | null
    groupId: string | null
    visitDate: Date | null
    checkinTime: Date | null
    addedBy: string | null
  }

  export type VisitsCountAggregateOutputType = {
    id: number
    churchId: number
    personId: number
    serviceId: number
    groupId: number
    visitDate: number
    checkinTime: number
    addedBy: number
    _all: number
  }


  export type VisitsMinAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    serviceId?: true
    groupId?: true
    visitDate?: true
    checkinTime?: true
    addedBy?: true
  }

  export type VisitsMaxAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    serviceId?: true
    groupId?: true
    visitDate?: true
    checkinTime?: true
    addedBy?: true
  }

  export type VisitsCountAggregateInputType = {
    id?: true
    churchId?: true
    personId?: true
    serviceId?: true
    groupId?: true
    visitDate?: true
    checkinTime?: true
    addedBy?: true
    _all?: true
  }

  export type VisitsAggregateArgs = {
    /**
     * Filter which visits to aggregate.
     * 
    **/
    where?: visitsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visits to fetch.
     * 
    **/
    orderBy?: Enumerable<visitsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     * 
    **/
    cursor?: visitsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visits from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visits.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned visits
    **/
    _count?: true | VisitsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VisitsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VisitsMaxAggregateInputType
  }

  export type GetVisitsAggregateType<T extends VisitsAggregateArgs> = {
        [P in keyof T & keyof AggregateVisits]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVisits[P]>
      : GetScalarType<T[P], AggregateVisits[P]>
  }




  export type VisitsGroupByArgs = {
    where?: visitsWhereInput
    orderBy?: Enumerable<visitsOrderByWithAggregationInput>
    by: Array<VisitsScalarFieldEnum>
    having?: visitsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VisitsCountAggregateInputType | true
    _min?: VisitsMinAggregateInputType
    _max?: VisitsMaxAggregateInputType
  }


  export type VisitsGroupByOutputType = {
    id: string
    churchId: string | null
    personId: string | null
    serviceId: string | null
    groupId: string | null
    visitDate: Date | null
    checkinTime: Date | null
    addedBy: string | null
    _count: VisitsCountAggregateOutputType | null
    _min: VisitsMinAggregateOutputType | null
    _max: VisitsMaxAggregateOutputType | null
  }

  type GetVisitsGroupByPayload<T extends VisitsGroupByArgs> = Promise<
    Array<
      PickArray<VisitsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VisitsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VisitsGroupByOutputType[P]>
            : GetScalarType<T[P], VisitsGroupByOutputType[P]>
        }
      >
    >


  export type visitsSelect = {
    id?: boolean
    churchId?: boolean
    personId?: boolean
    serviceId?: boolean
    groupId?: boolean
    visitDate?: boolean
    checkinTime?: boolean
    addedBy?: boolean
    session?: boolean | visitSessionsFindManyArgs
    _count?: boolean | VisitsCountOutputTypeArgs
  }

  export type visitsInclude = {
    session?: boolean | visitSessionsFindManyArgs
    _count?: boolean | VisitsCountOutputTypeArgs
  }

  export type visitsGetPayload<
    S extends boolean | null | undefined | visitsArgs,
    U = keyof S
      > = S extends true
        ? visits
    : S extends undefined
    ? never
    : S extends visitsArgs | visitsFindManyArgs
    ?'include' extends U
    ? visits  & {
    [P in TrueKeys<S['include']>]: 
          P extends 'session'
        ? Array < visitSessionsGetPayload<S['include'][P]>>  :
        P extends '_count'
        ? VisitsCountOutputTypeGetPayload<S['include'][P]> : never
  } 
    : 'select' extends U
    ? {
    [P in TrueKeys<S['select']>]: P extends keyof visits ?visits [P]
  : 
          P extends 'session'
        ? Array < visitSessionsGetPayload<S['select'][P]>>  :
        P extends '_count'
        ? VisitsCountOutputTypeGetPayload<S['select'][P]> : never
  } 
    : visits
  : visits


  type visitsCountArgs = Merge<
    Omit<visitsFindManyArgs, 'select' | 'include'> & {
      select?: VisitsCountAggregateInputType | true
    }
  >

  export interface visitsDelegate<GlobalRejectSettings> {
    /**
     * Find zero or one Visits that matches the filter.
     * @param {visitsFindUniqueArgs} args - Arguments to find a Visits
     * @example
     * // Get one Visits
     * const visits = await prisma.visits.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends visitsFindUniqueArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, visitsFindUniqueArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'visits'> extends True ? CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>> : CheckSelect<T, Prisma__visitsClient<visits | null >, Prisma__visitsClient<visitsGetPayload<T> | null >>

    /**
     * Find the first Visits that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitsFindFirstArgs} args - Arguments to find a Visits
     * @example
     * // Get one Visits
     * const visits = await prisma.visits.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends visitsFindFirstArgs,  LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, visitsFindFirstArgs>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'visits'> extends True ? CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>> : CheckSelect<T, Prisma__visitsClient<visits | null >, Prisma__visitsClient<visitsGetPayload<T> | null >>

    /**
     * Find zero or more Visits that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Visits
     * const visits = await prisma.visits.findMany()
     * 
     * // Get first 10 Visits
     * const visits = await prisma.visits.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const visitsWithIdOnly = await prisma.visits.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends visitsFindManyArgs>(
      args?: SelectSubset<T, visitsFindManyArgs>
    ): CheckSelect<T, PrismaPromise<Array<visits>>, PrismaPromise<Array<visitsGetPayload<T>>>>

    /**
     * Create a Visits.
     * @param {visitsCreateArgs} args - Arguments to create a Visits.
     * @example
     * // Create one Visits
     * const Visits = await prisma.visits.create({
     *   data: {
     *     // ... data to create a Visits
     *   }
     * })
     * 
    **/
    create<T extends visitsCreateArgs>(
      args: SelectSubset<T, visitsCreateArgs>
    ): CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>>

    /**
     * Create many Visits.
     *     @param {visitsCreateManyArgs} args - Arguments to create many Visits.
     *     @example
     *     // Create many Visits
     *     const visits = await prisma.visits.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends visitsCreateManyArgs>(
      args?: SelectSubset<T, visitsCreateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Delete a Visits.
     * @param {visitsDeleteArgs} args - Arguments to delete one Visits.
     * @example
     * // Delete one Visits
     * const Visits = await prisma.visits.delete({
     *   where: {
     *     // ... filter to delete one Visits
     *   }
     * })
     * 
    **/
    delete<T extends visitsDeleteArgs>(
      args: SelectSubset<T, visitsDeleteArgs>
    ): CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>>

    /**
     * Update one Visits.
     * @param {visitsUpdateArgs} args - Arguments to update one Visits.
     * @example
     * // Update one Visits
     * const visits = await prisma.visits.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends visitsUpdateArgs>(
      args: SelectSubset<T, visitsUpdateArgs>
    ): CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>>

    /**
     * Delete zero or more Visits.
     * @param {visitsDeleteManyArgs} args - Arguments to filter Visits to delete.
     * @example
     * // Delete a few Visits
     * const { count } = await prisma.visits.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends visitsDeleteManyArgs>(
      args?: SelectSubset<T, visitsDeleteManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Update zero or more Visits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Visits
     * const visits = await prisma.visits.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends visitsUpdateManyArgs>(
      args: SelectSubset<T, visitsUpdateManyArgs>
    ): PrismaPromise<BatchPayload>

    /**
     * Create or update one Visits.
     * @param {visitsUpsertArgs} args - Arguments to update or create a Visits.
     * @example
     * // Update or create a Visits
     * const visits = await prisma.visits.upsert({
     *   create: {
     *     // ... data to create a Visits
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Visits we want to update
     *   }
     * })
    **/
    upsert<T extends visitsUpsertArgs>(
      args: SelectSubset<T, visitsUpsertArgs>
    ): CheckSelect<T, Prisma__visitsClient<visits>, Prisma__visitsClient<visitsGetPayload<T>>>

    /**
     * Count the number of Visits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {visitsCountArgs} args - Arguments to filter Visits to count.
     * @example
     * // Count the number of Visits
     * const count = await prisma.visits.count({
     *   where: {
     *     // ... the filter for the Visits we want to count
     *   }
     * })
    **/
    count<T extends visitsCountArgs>(
      args?: Subset<T, visitsCountArgs>,
    ): PrismaPromise<
      T extends _Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VisitsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Visits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VisitsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VisitsAggregateArgs>(args: Subset<T, VisitsAggregateArgs>): PrismaPromise<GetVisitsAggregateType<T>>

    /**
     * Group by Visits.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VisitsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VisitsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VisitsGroupByArgs['orderBy'] }
        : { orderBy?: VisitsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VisitsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVisitsGroupByPayload<T> : Promise<InputErrors>
  }

  /**
   * The delegate class that acts as a "Promise-like" for visits.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__visitsClient<T> implements PrismaPromise<T> {
    [prisma]: true;
    private readonly _dmmf;
    private readonly _fetcher;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    constructor(_dmmf: runtime.DMMFClass, _fetcher: PrismaClientFetcher, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);
    readonly [Symbol.toStringTag]: 'PrismaClientPromise';

    session<T extends visitSessionsFindManyArgs = {}>(args?: Subset<T, visitSessionsFindManyArgs>): CheckSelect<T, PrismaPromise<Array<visitSessions>>, PrismaPromise<Array<visitSessionsGetPayload<T>>>>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }

  // Custom InputTypes

  /**
   * visits findUnique
   */
  export type visitsFindUniqueArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * Throw an Error if a visits can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which visits to fetch.
     * 
    **/
    where: visitsWhereUniqueInput
  }


  /**
   * visits findFirst
   */
  export type visitsFindFirstArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * Throw an Error if a visits can't be found
     * 
    **/
    rejectOnNotFound?: RejectOnNotFound
    /**
     * Filter, which visits to fetch.
     * 
    **/
    where?: visitsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visits to fetch.
     * 
    **/
    orderBy?: Enumerable<visitsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for visits.
     * 
    **/
    cursor?: visitsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visits from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visits.
     * 
    **/
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of visits.
     * 
    **/
    distinct?: Enumerable<VisitsScalarFieldEnum>
  }


  /**
   * visits findMany
   */
  export type visitsFindManyArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * Filter, which visits to fetch.
     * 
    **/
    where?: visitsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of visits to fetch.
     * 
    **/
    orderBy?: Enumerable<visitsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing visits.
     * 
    **/
    cursor?: visitsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` visits from the position of the cursor.
     * 
    **/
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` visits.
     * 
    **/
    skip?: number
    distinct?: Enumerable<VisitsScalarFieldEnum>
  }


  /**
   * visits create
   */
  export type visitsCreateArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * The data needed to create a visits.
     * 
    **/
    data: XOR<visitsCreateInput, visitsUncheckedCreateInput>
  }


  /**
   * visits createMany
   */
  export type visitsCreateManyArgs = {
    data: Enumerable<visitsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * visits update
   */
  export type visitsUpdateArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * The data needed to update a visits.
     * 
    **/
    data: XOR<visitsUpdateInput, visitsUncheckedUpdateInput>
    /**
     * Choose, which visits to update.
     * 
    **/
    where: visitsWhereUniqueInput
  }


  /**
   * visits updateMany
   */
  export type visitsUpdateManyArgs = {
    data: XOR<visitsUpdateManyMutationInput, visitsUncheckedUpdateManyInput>
    where?: visitsWhereInput
  }


  /**
   * visits upsert
   */
  export type visitsUpsertArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * The filter to search for the visits to update in case it exists.
     * 
    **/
    where: visitsWhereUniqueInput
    /**
     * In case the visits found by the `where` argument doesn't exist, create a new visits with this data.
     * 
    **/
    create: XOR<visitsCreateInput, visitsUncheckedCreateInput>
    /**
     * In case the visits was found with the provided `where` argument, update it with this data.
     * 
    **/
    update: XOR<visitsUpdateInput, visitsUncheckedUpdateInput>
  }


  /**
   * visits delete
   */
  export type visitsDeleteArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
    /**
     * Filter which visits to delete.
     * 
    **/
    where: visitsWhereUniqueInput
  }


  /**
   * visits deleteMany
   */
  export type visitsDeleteManyArgs = {
    where?: visitsWhereInput
  }


  /**
   * visits without action
   */
  export type visitsArgs = {
    /**
     * Select specific fields to fetch from the visits
     * 
    **/
    select?: visitsSelect | null
    /**
     * Choose, which related nodes to fetch as well.
     * 
    **/
    include?: visitsInclude | null
  }



  /**
   * Enums
   */

  // Based on
  // https://github.com/microsoft/TypeScript/issues/3192#issuecomment-261720275

  export const AnswersScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    formSubmissionId: 'formSubmissionId',
    questionId: 'questionId',
    value: 'value'
  };

  export type AnswersScalarFieldEnum = (typeof AnswersScalarFieldEnum)[keyof typeof AnswersScalarFieldEnum]


  export const FormSubmissionsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    formId: 'formId',
    contentType: 'contentType',
    contentId: 'contentId',
    submissionDate: 'submissionDate',
    submittedBy: 'submittedBy',
    revisionDate: 'revisionDate',
    revisedBy: 'revisedBy'
  };

  export type FormSubmissionsScalarFieldEnum = (typeof FormSubmissionsScalarFieldEnum)[keyof typeof FormSubmissionsScalarFieldEnum]


  export const FormsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    name: 'name',
    contentType: 'contentType',
    createdTime: 'createdTime',
    modifiedTime: 'modifiedTime',
    removed: 'removed'
  };

  export type FormsScalarFieldEnum = (typeof FormsScalarFieldEnum)[keyof typeof FormsScalarFieldEnum]


  export const GroupMembersScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    groupId: 'groupId',
    personId: 'personId',
    joinDate: 'joinDate'
  };

  export type GroupMembersScalarFieldEnum = (typeof GroupMembersScalarFieldEnum)[keyof typeof GroupMembersScalarFieldEnum]


  export const GroupsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    categoryName: 'categoryName',
    name: 'name',
    trackAttendance: 'trackAttendance',
    parentPickup: 'parentPickup',
    removed: 'removed'
  };

  export type GroupsScalarFieldEnum = (typeof GroupsScalarFieldEnum)[keyof typeof GroupsScalarFieldEnum]


  export const HouseholdsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    name: 'name'
  };

  export type HouseholdsScalarFieldEnum = (typeof HouseholdsScalarFieldEnum)[keyof typeof HouseholdsScalarFieldEnum]


  export const NotesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    contentType: 'contentType',
    contentId: 'contentId',
    noteType: 'noteType',
    addedBy: 'addedBy',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    contents: 'contents'
  };

  export type NotesScalarFieldEnum = (typeof NotesScalarFieldEnum)[keyof typeof NotesScalarFieldEnum]


  export const PeopleScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    displayName: 'displayName',
    firstName: 'firstName',
    middleName: 'middleName',
    lastName: 'lastName',
    nickName: 'nickName',
    prefix: 'prefix',
    suffix: 'suffix',
    birthDate: 'birthDate',
    gender: 'gender',
    maritalStatus: 'maritalStatus',
    anniversary: 'anniversary',
    membershipStatus: 'membershipStatus',
    homePhone: 'homePhone',
    mobilePhone: 'mobilePhone',
    workPhone: 'workPhone',
    email: 'email',
    address1: 'address1',
    address2: 'address2',
    city: 'city',
    state: 'state',
    zip: 'zip',
    photoUpdated: 'photoUpdated',
    householdId: 'householdId',
    householdRole: 'householdRole',
    removed: 'removed'
  };

  export type PeopleScalarFieldEnum = (typeof PeopleScalarFieldEnum)[keyof typeof PeopleScalarFieldEnum]


  export const QuestionsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    formId: 'formId',
    parentId: 'parentId',
    title: 'title',
    description: 'description',
    fieldType: 'fieldType',
    placeholder: 'placeholder',
    sort: 'sort',
    choices: 'choices',
    removed: 'removed'
  };

  export type QuestionsScalarFieldEnum = (typeof QuestionsScalarFieldEnum)[keyof typeof QuestionsScalarFieldEnum]


  export const CustomersScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    personId: 'personId'
  };

  export type CustomersScalarFieldEnum = (typeof CustomersScalarFieldEnum)[keyof typeof CustomersScalarFieldEnum]


  export const DonationBatchesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    name: 'name',
    batchDate: 'batchDate'
  };

  export type DonationBatchesScalarFieldEnum = (typeof DonationBatchesScalarFieldEnum)[keyof typeof DonationBatchesScalarFieldEnum]


  export const DonationsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    batchId: 'batchId',
    personId: 'personId',
    donationDate: 'donationDate',
    amount: 'amount',
    method: 'method',
    methodDetails: 'methodDetails',
    notes: 'notes'
  };

  export type DonationsScalarFieldEnum = (typeof DonationsScalarFieldEnum)[keyof typeof DonationsScalarFieldEnum]


  export const EventLogsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    customerId: 'customerId',
    provider: 'provider',
    status: 'status',
    eventType: 'eventType',
    message: 'message',
    created: 'created',
    resolved: 'resolved'
  };

  export type EventLogsScalarFieldEnum = (typeof EventLogsScalarFieldEnum)[keyof typeof EventLogsScalarFieldEnum]


  export const FundDonationsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    donationId: 'donationId',
    fundId: 'fundId',
    amount: 'amount'
  };

  export type FundDonationsScalarFieldEnum = (typeof FundDonationsScalarFieldEnum)[keyof typeof FundDonationsScalarFieldEnum]


  export const FundsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    name: 'name',
    productId: 'productId',
    removed: 'removed'
  };

  export type FundsScalarFieldEnum = (typeof FundsScalarFieldEnum)[keyof typeof FundsScalarFieldEnum]


  export const GatewaysScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    provider: 'provider',
    publicKey: 'publicKey',
    privateKey: 'privateKey',
    webhookKey: 'webhookKey',
    productId: 'productId'
  };

  export type GatewaysScalarFieldEnum = (typeof GatewaysScalarFieldEnum)[keyof typeof GatewaysScalarFieldEnum]


  export const SubscriptionFundsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    subscriptionId: 'subscriptionId',
    fundId: 'fundId',
    amount: 'amount'
  };

  export type SubscriptionFundsScalarFieldEnum = (typeof SubscriptionFundsScalarFieldEnum)[keyof typeof SubscriptionFundsScalarFieldEnum]


  export const SubscriptionsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    personId: 'personId',
    customerId: 'customerId'
  };

  export type SubscriptionsScalarFieldEnum = (typeof SubscriptionsScalarFieldEnum)[keyof typeof SubscriptionsScalarFieldEnum]


  export const CampusesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    name: 'name',
    address1: 'address1',
    address2: 'address2',
    city: 'city',
    state: 'state',
    zip: 'zip',
    removed: 'removed'
  };

  export type CampusesScalarFieldEnum = (typeof CampusesScalarFieldEnum)[keyof typeof CampusesScalarFieldEnum]


  export const GroupServiceTimesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    groupId: 'groupId',
    serviceTimeId: 'serviceTimeId'
  };

  export type GroupServiceTimesScalarFieldEnum = (typeof GroupServiceTimesScalarFieldEnum)[keyof typeof GroupServiceTimesScalarFieldEnum]


  export const ServiceTimesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    serviceId: 'serviceId',
    name: 'name',
    removed: 'removed'
  };

  export type ServiceTimesScalarFieldEnum = (typeof ServiceTimesScalarFieldEnum)[keyof typeof ServiceTimesScalarFieldEnum]


  export const ServicesScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    campusId: 'campusId',
    name: 'name',
    removed: 'removed'
  };

  export type ServicesScalarFieldEnum = (typeof ServicesScalarFieldEnum)[keyof typeof ServicesScalarFieldEnum]


  export const SessionsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    groupId: 'groupId',
    serviceTimeId: 'serviceTimeId',
    sessionDate: 'sessionDate'
  };

  export type SessionsScalarFieldEnum = (typeof SessionsScalarFieldEnum)[keyof typeof SessionsScalarFieldEnum]


  export const VisitSessionsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    visitId: 'visitId',
    sessionId: 'sessionId'
  };

  export type VisitSessionsScalarFieldEnum = (typeof VisitSessionsScalarFieldEnum)[keyof typeof VisitSessionsScalarFieldEnum]


  export const VisitsScalarFieldEnum: {
    id: 'id',
    churchId: 'churchId',
    personId: 'personId',
    serviceId: 'serviceId',
    groupId: 'groupId',
    visitDate: 'visitDate',
    checkinTime: 'checkinTime',
    addedBy: 'addedBy'
  };

  export type VisitsScalarFieldEnum = (typeof VisitsScalarFieldEnum)[keyof typeof VisitsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  /**
   * Deep Input Types
   */


  export type answersWhereInput = {
    AND?: Enumerable<answersWhereInput>
    OR?: Enumerable<answersWhereInput>
    NOT?: Enumerable<answersWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    formSubmissionId?: StringNullableFilter | string | null
    questionId?: StringNullableFilter | string | null
    value?: StringNullableFilter | string | null
  }

  export type answersOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formSubmissionId?: SortOrder
    questionId?: SortOrder
    value?: SortOrder
  }

  export type answersWhereUniqueInput = {
    id?: string
  }

  export type answersOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formSubmissionId?: SortOrder
    questionId?: SortOrder
    value?: SortOrder
    _count?: answersCountOrderByAggregateInput
    _max?: answersMaxOrderByAggregateInput
    _min?: answersMinOrderByAggregateInput
  }

  export type answersScalarWhereWithAggregatesInput = {
    AND?: Enumerable<answersScalarWhereWithAggregatesInput>
    OR?: Enumerable<answersScalarWhereWithAggregatesInput>
    NOT?: Enumerable<answersScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    formSubmissionId?: StringNullableWithAggregatesFilter | string | null
    questionId?: StringNullableWithAggregatesFilter | string | null
    value?: StringNullableWithAggregatesFilter | string | null
  }

  export type formSubmissionsWhereInput = {
    AND?: Enumerable<formSubmissionsWhereInput>
    OR?: Enumerable<formSubmissionsWhereInput>
    NOT?: Enumerable<formSubmissionsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    formId?: StringNullableFilter | string | null
    contentType?: StringNullableFilter | string | null
    contentId?: StringNullableFilter | string | null
    submissionDate?: DateTimeNullableFilter | Date | string | null
    submittedBy?: StringNullableFilter | string | null
    revisionDate?: DateTimeNullableFilter | Date | string | null
    revisedBy?: StringNullableFilter | string | null
  }

  export type formSubmissionsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    submissionDate?: SortOrder
    submittedBy?: SortOrder
    revisionDate?: SortOrder
    revisedBy?: SortOrder
  }

  export type formSubmissionsWhereUniqueInput = {
    id?: string
  }

  export type formSubmissionsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    submissionDate?: SortOrder
    submittedBy?: SortOrder
    revisionDate?: SortOrder
    revisedBy?: SortOrder
    _count?: formSubmissionsCountOrderByAggregateInput
    _max?: formSubmissionsMaxOrderByAggregateInput
    _min?: formSubmissionsMinOrderByAggregateInput
  }

  export type formSubmissionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<formSubmissionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<formSubmissionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<formSubmissionsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    formId?: StringNullableWithAggregatesFilter | string | null
    contentType?: StringNullableWithAggregatesFilter | string | null
    contentId?: StringNullableWithAggregatesFilter | string | null
    submissionDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
    submittedBy?: StringNullableWithAggregatesFilter | string | null
    revisionDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
    revisedBy?: StringNullableWithAggregatesFilter | string | null
  }

  export type formsWhereInput = {
    AND?: Enumerable<formsWhereInput>
    OR?: Enumerable<formsWhereInput>
    NOT?: Enumerable<formsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    contentType?: StringNullableFilter | string | null
    createdTime?: DateTimeNullableFilter | Date | string | null
    modifiedTime?: DateTimeNullableFilter | Date | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type formsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    contentType?: SortOrder
    createdTime?: SortOrder
    modifiedTime?: SortOrder
    removed?: SortOrder
  }

  export type formsWhereUniqueInput = {
    id?: string
  }

  export type formsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    contentType?: SortOrder
    createdTime?: SortOrder
    modifiedTime?: SortOrder
    removed?: SortOrder
    _count?: formsCountOrderByAggregateInput
    _max?: formsMaxOrderByAggregateInput
    _min?: formsMinOrderByAggregateInput
  }

  export type formsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<formsScalarWhereWithAggregatesInput>
    OR?: Enumerable<formsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<formsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    contentType?: StringNullableWithAggregatesFilter | string | null
    createdTime?: DateTimeNullableWithAggregatesFilter | Date | string | null
    modifiedTime?: DateTimeNullableWithAggregatesFilter | Date | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type groupMembersWhereInput = {
    AND?: Enumerable<groupMembersWhereInput>
    OR?: Enumerable<groupMembersWhereInput>
    NOT?: Enumerable<groupMembersWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    groupId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    joinDate?: DateTimeNullableFilter | Date | string | null
    group?: XOR<GroupsRelationFilter, groupsWhereInput> | null
    person?: XOR<PeopleRelationFilter, peopleWhereInput> | null
  }

  export type groupMembersOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    personId?: SortOrder
    joinDate?: SortOrder
    group?: groupsOrderByWithRelationInput
    person?: peopleOrderByWithRelationInput
  }

  export type groupMembersWhereUniqueInput = {
    id?: string
  }

  export type groupMembersOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    personId?: SortOrder
    joinDate?: SortOrder
    _count?: groupMembersCountOrderByAggregateInput
    _max?: groupMembersMaxOrderByAggregateInput
    _min?: groupMembersMinOrderByAggregateInput
  }

  export type groupMembersScalarWhereWithAggregatesInput = {
    AND?: Enumerable<groupMembersScalarWhereWithAggregatesInput>
    OR?: Enumerable<groupMembersScalarWhereWithAggregatesInput>
    NOT?: Enumerable<groupMembersScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    groupId?: StringNullableWithAggregatesFilter | string | null
    personId?: StringNullableWithAggregatesFilter | string | null
    joinDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
  }

  export type groupsWhereInput = {
    AND?: Enumerable<groupsWhereInput>
    OR?: Enumerable<groupsWhereInput>
    NOT?: Enumerable<groupsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    categoryName?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    trackAttendance?: BoolNullableFilter | boolean | null
    parentPickup?: BoolNullableFilter | boolean | null
    removed?: BoolNullableFilter | boolean | null
    users?: GroupMembersListRelationFilter
  }

  export type groupsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    categoryName?: SortOrder
    name?: SortOrder
    trackAttendance?: SortOrder
    parentPickup?: SortOrder
    removed?: SortOrder
    users?: groupMembersOrderByRelationAggregateInput
  }

  export type groupsWhereUniqueInput = {
    id?: string
  }

  export type groupsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    categoryName?: SortOrder
    name?: SortOrder
    trackAttendance?: SortOrder
    parentPickup?: SortOrder
    removed?: SortOrder
    _count?: groupsCountOrderByAggregateInput
    _max?: groupsMaxOrderByAggregateInput
    _min?: groupsMinOrderByAggregateInput
  }

  export type groupsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<groupsScalarWhereWithAggregatesInput>
    OR?: Enumerable<groupsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<groupsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    categoryName?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    trackAttendance?: BoolNullableWithAggregatesFilter | boolean | null
    parentPickup?: BoolNullableWithAggregatesFilter | boolean | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type householdsWhereInput = {
    AND?: Enumerable<householdsWhereInput>
    OR?: Enumerable<householdsWhereInput>
    NOT?: Enumerable<householdsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    people?: PeopleListRelationFilter
  }

  export type householdsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    people?: peopleOrderByRelationAggregateInput
  }

  export type householdsWhereUniqueInput = {
    id?: string
  }

  export type householdsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    _count?: householdsCountOrderByAggregateInput
    _max?: householdsMaxOrderByAggregateInput
    _min?: householdsMinOrderByAggregateInput
  }

  export type householdsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<householdsScalarWhereWithAggregatesInput>
    OR?: Enumerable<householdsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<householdsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
  }

  export type notesWhereInput = {
    AND?: Enumerable<notesWhereInput>
    OR?: Enumerable<notesWhereInput>
    NOT?: Enumerable<notesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    contentType?: StringNullableFilter | string | null
    contentId?: StringNullableFilter | string | null
    noteType?: StringNullableFilter | string | null
    addedBy?: StringNullableFilter | string | null
    createdAt?: DateTimeNullableFilter | Date | string | null
    updatedAt?: DateTimeNullableFilter | Date | string | null
    contents?: StringNullableFilter | string | null
  }

  export type notesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    noteType?: SortOrder
    addedBy?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contents?: SortOrder
  }

  export type notesWhereUniqueInput = {
    id?: string
  }

  export type notesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    noteType?: SortOrder
    addedBy?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contents?: SortOrder
    _count?: notesCountOrderByAggregateInput
    _max?: notesMaxOrderByAggregateInput
    _min?: notesMinOrderByAggregateInput
  }

  export type notesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<notesScalarWhereWithAggregatesInput>
    OR?: Enumerable<notesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<notesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    contentType?: StringNullableWithAggregatesFilter | string | null
    contentId?: StringNullableWithAggregatesFilter | string | null
    noteType?: StringNullableWithAggregatesFilter | string | null
    addedBy?: StringNullableWithAggregatesFilter | string | null
    createdAt?: DateTimeNullableWithAggregatesFilter | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter | Date | string | null
    contents?: StringNullableWithAggregatesFilter | string | null
  }

  export type peopleWhereInput = {
    AND?: Enumerable<peopleWhereInput>
    OR?: Enumerable<peopleWhereInput>
    NOT?: Enumerable<peopleWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    displayName?: StringNullableFilter | string | null
    firstName?: StringNullableFilter | string | null
    middleName?: StringNullableFilter | string | null
    lastName?: StringNullableFilter | string | null
    nickName?: StringNullableFilter | string | null
    prefix?: StringNullableFilter | string | null
    suffix?: StringNullableFilter | string | null
    birthDate?: DateTimeNullableFilter | Date | string | null
    gender?: StringNullableFilter | string | null
    maritalStatus?: StringNullableFilter | string | null
    anniversary?: DateTimeNullableFilter | Date | string | null
    membershipStatus?: StringNullableFilter | string | null
    homePhone?: StringNullableFilter | string | null
    mobilePhone?: StringNullableFilter | string | null
    workPhone?: StringNullableFilter | string | null
    email?: StringNullableFilter | string | null
    address1?: StringNullableFilter | string | null
    address2?: StringNullableFilter | string | null
    city?: StringNullableFilter | string | null
    state?: StringNullableFilter | string | null
    zip?: StringNullableFilter | string | null
    photoUpdated?: DateTimeNullableFilter | Date | string | null
    householdId?: StringNullableFilter | string | null
    householdRole?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
    groups?: GroupMembersListRelationFilter
    household?: XOR<HouseholdsRelationFilter, householdsWhereInput> | null
  }

  export type peopleOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    displayName?: SortOrder
    firstName?: SortOrder
    middleName?: SortOrder
    lastName?: SortOrder
    nickName?: SortOrder
    prefix?: SortOrder
    suffix?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    maritalStatus?: SortOrder
    anniversary?: SortOrder
    membershipStatus?: SortOrder
    homePhone?: SortOrder
    mobilePhone?: SortOrder
    workPhone?: SortOrder
    email?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    photoUpdated?: SortOrder
    householdId?: SortOrder
    householdRole?: SortOrder
    removed?: SortOrder
    groups?: groupMembersOrderByRelationAggregateInput
    household?: householdsOrderByWithRelationInput
  }

  export type peopleWhereUniqueInput = {
    id?: string
  }

  export type peopleOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    displayName?: SortOrder
    firstName?: SortOrder
    middleName?: SortOrder
    lastName?: SortOrder
    nickName?: SortOrder
    prefix?: SortOrder
    suffix?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    maritalStatus?: SortOrder
    anniversary?: SortOrder
    membershipStatus?: SortOrder
    homePhone?: SortOrder
    mobilePhone?: SortOrder
    workPhone?: SortOrder
    email?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    photoUpdated?: SortOrder
    householdId?: SortOrder
    householdRole?: SortOrder
    removed?: SortOrder
    _count?: peopleCountOrderByAggregateInput
    _max?: peopleMaxOrderByAggregateInput
    _min?: peopleMinOrderByAggregateInput
  }

  export type peopleScalarWhereWithAggregatesInput = {
    AND?: Enumerable<peopleScalarWhereWithAggregatesInput>
    OR?: Enumerable<peopleScalarWhereWithAggregatesInput>
    NOT?: Enumerable<peopleScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    displayName?: StringNullableWithAggregatesFilter | string | null
    firstName?: StringNullableWithAggregatesFilter | string | null
    middleName?: StringNullableWithAggregatesFilter | string | null
    lastName?: StringNullableWithAggregatesFilter | string | null
    nickName?: StringNullableWithAggregatesFilter | string | null
    prefix?: StringNullableWithAggregatesFilter | string | null
    suffix?: StringNullableWithAggregatesFilter | string | null
    birthDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
    gender?: StringNullableWithAggregatesFilter | string | null
    maritalStatus?: StringNullableWithAggregatesFilter | string | null
    anniversary?: DateTimeNullableWithAggregatesFilter | Date | string | null
    membershipStatus?: StringNullableWithAggregatesFilter | string | null
    homePhone?: StringNullableWithAggregatesFilter | string | null
    mobilePhone?: StringNullableWithAggregatesFilter | string | null
    workPhone?: StringNullableWithAggregatesFilter | string | null
    email?: StringNullableWithAggregatesFilter | string | null
    address1?: StringNullableWithAggregatesFilter | string | null
    address2?: StringNullableWithAggregatesFilter | string | null
    city?: StringNullableWithAggregatesFilter | string | null
    state?: StringNullableWithAggregatesFilter | string | null
    zip?: StringNullableWithAggregatesFilter | string | null
    photoUpdated?: DateTimeNullableWithAggregatesFilter | Date | string | null
    householdId?: StringNullableWithAggregatesFilter | string | null
    householdRole?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type questionsWhereInput = {
    AND?: Enumerable<questionsWhereInput>
    OR?: Enumerable<questionsWhereInput>
    NOT?: Enumerable<questionsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    formId?: StringNullableFilter | string | null
    parentId?: StringNullableFilter | string | null
    title?: StringNullableFilter | string | null
    description?: StringNullableFilter | string | null
    fieldType?: StringNullableFilter | string | null
    placeholder?: StringNullableFilter | string | null
    sort?: StringNullableFilter | string | null
    choices?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type questionsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    parentId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    fieldType?: SortOrder
    placeholder?: SortOrder
    sort?: SortOrder
    choices?: SortOrder
    removed?: SortOrder
  }

  export type questionsWhereUniqueInput = {
    id?: string
  }

  export type questionsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    parentId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    fieldType?: SortOrder
    placeholder?: SortOrder
    sort?: SortOrder
    choices?: SortOrder
    removed?: SortOrder
    _count?: questionsCountOrderByAggregateInput
    _max?: questionsMaxOrderByAggregateInput
    _min?: questionsMinOrderByAggregateInput
  }

  export type questionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<questionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<questionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<questionsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    formId?: StringNullableWithAggregatesFilter | string | null
    parentId?: StringNullableWithAggregatesFilter | string | null
    title?: StringNullableWithAggregatesFilter | string | null
    description?: StringNullableWithAggregatesFilter | string | null
    fieldType?: StringNullableWithAggregatesFilter | string | null
    placeholder?: StringNullableWithAggregatesFilter | string | null
    sort?: StringNullableWithAggregatesFilter | string | null
    choices?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type customersWhereInput = {
    AND?: Enumerable<customersWhereInput>
    OR?: Enumerable<customersWhereInput>
    NOT?: Enumerable<customersWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
  }

  export type customersOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
  }

  export type customersWhereUniqueInput = {
    id?: string
  }

  export type customersOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    _count?: customersCountOrderByAggregateInput
    _max?: customersMaxOrderByAggregateInput
    _min?: customersMinOrderByAggregateInput
  }

  export type customersScalarWhereWithAggregatesInput = {
    AND?: Enumerable<customersScalarWhereWithAggregatesInput>
    OR?: Enumerable<customersScalarWhereWithAggregatesInput>
    NOT?: Enumerable<customersScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    personId?: StringNullableWithAggregatesFilter | string | null
  }

  export type donationBatchesWhereInput = {
    AND?: Enumerable<donationBatchesWhereInput>
    OR?: Enumerable<donationBatchesWhereInput>
    NOT?: Enumerable<donationBatchesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    batchDate?: DateTimeNullableFilter | Date | string | null
    donations?: DonationsListRelationFilter
  }

  export type donationBatchesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    batchDate?: SortOrder
    donations?: donationsOrderByRelationAggregateInput
  }

  export type donationBatchesWhereUniqueInput = {
    id?: string
  }

  export type donationBatchesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    batchDate?: SortOrder
    _count?: donationBatchesCountOrderByAggregateInput
    _max?: donationBatchesMaxOrderByAggregateInput
    _min?: donationBatchesMinOrderByAggregateInput
  }

  export type donationBatchesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<donationBatchesScalarWhereWithAggregatesInput>
    OR?: Enumerable<donationBatchesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<donationBatchesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    batchDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
  }

  export type donationsWhereInput = {
    AND?: Enumerable<donationsWhereInput>
    OR?: Enumerable<donationsWhereInput>
    NOT?: Enumerable<donationsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    batchId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    donationDate?: DateTimeNullableFilter | Date | string | null
    amount?: FloatNullableFilter | number | null
    method?: StringNullableFilter | string | null
    methodDetails?: StringNullableFilter | string | null
    notes?: StringNullableFilter | string | null
    donationBatches?: XOR<DonationBatchesRelationFilter, donationBatchesWhereInput> | null
    fundDonations?: FundDonationsListRelationFilter
  }

  export type donationsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    batchId?: SortOrder
    personId?: SortOrder
    donationDate?: SortOrder
    amount?: SortOrder
    method?: SortOrder
    methodDetails?: SortOrder
    notes?: SortOrder
    donationBatches?: donationBatchesOrderByWithRelationInput
    fundDonations?: fundDonationsOrderByRelationAggregateInput
  }

  export type donationsWhereUniqueInput = {
    id?: string
  }

  export type donationsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    batchId?: SortOrder
    personId?: SortOrder
    donationDate?: SortOrder
    amount?: SortOrder
    method?: SortOrder
    methodDetails?: SortOrder
    notes?: SortOrder
    _count?: donationsCountOrderByAggregateInput
    _avg?: donationsAvgOrderByAggregateInput
    _max?: donationsMaxOrderByAggregateInput
    _min?: donationsMinOrderByAggregateInput
    _sum?: donationsSumOrderByAggregateInput
  }

  export type donationsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<donationsScalarWhereWithAggregatesInput>
    OR?: Enumerable<donationsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<donationsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    batchId?: StringNullableWithAggregatesFilter | string | null
    personId?: StringNullableWithAggregatesFilter | string | null
    donationDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
    amount?: FloatNullableWithAggregatesFilter | number | null
    method?: StringNullableWithAggregatesFilter | string | null
    methodDetails?: StringNullableWithAggregatesFilter | string | null
    notes?: StringNullableWithAggregatesFilter | string | null
  }

  export type eventLogsWhereInput = {
    AND?: Enumerable<eventLogsWhereInput>
    OR?: Enumerable<eventLogsWhereInput>
    NOT?: Enumerable<eventLogsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    customerId?: StringNullableFilter | string | null
    provider?: StringNullableFilter | string | null
    status?: StringNullableFilter | string | null
    eventType?: StringNullableFilter | string | null
    message?: StringNullableFilter | string | null
    created?: DateTimeNullableFilter | Date | string | null
    resolved?: BoolNullableFilter | boolean | null
  }

  export type eventLogsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    customerId?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    eventType?: SortOrder
    message?: SortOrder
    created?: SortOrder
    resolved?: SortOrder
  }

  export type eventLogsWhereUniqueInput = {
    id?: string
  }

  export type eventLogsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    customerId?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    eventType?: SortOrder
    message?: SortOrder
    created?: SortOrder
    resolved?: SortOrder
    _count?: eventLogsCountOrderByAggregateInput
    _max?: eventLogsMaxOrderByAggregateInput
    _min?: eventLogsMinOrderByAggregateInput
  }

  export type eventLogsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<eventLogsScalarWhereWithAggregatesInput>
    OR?: Enumerable<eventLogsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<eventLogsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    customerId?: StringNullableWithAggregatesFilter | string | null
    provider?: StringNullableWithAggregatesFilter | string | null
    status?: StringNullableWithAggregatesFilter | string | null
    eventType?: StringNullableWithAggregatesFilter | string | null
    message?: StringNullableWithAggregatesFilter | string | null
    created?: DateTimeNullableWithAggregatesFilter | Date | string | null
    resolved?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type fundDonationsWhereInput = {
    AND?: Enumerable<fundDonationsWhereInput>
    OR?: Enumerable<fundDonationsWhereInput>
    NOT?: Enumerable<fundDonationsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    donationId?: StringNullableFilter | string | null
    fundId?: StringNullableFilter | string | null
    amount?: FloatNullableFilter | number | null
    fund?: XOR<FundsRelationFilter, fundsWhereInput> | null
    donation?: XOR<DonationsRelationFilter, donationsWhereInput> | null
  }

  export type fundDonationsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    donationId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
    fund?: fundsOrderByWithRelationInput
    donation?: donationsOrderByWithRelationInput
  }

  export type fundDonationsWhereUniqueInput = {
    id?: string
  }

  export type fundDonationsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    donationId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
    _count?: fundDonationsCountOrderByAggregateInput
    _avg?: fundDonationsAvgOrderByAggregateInput
    _max?: fundDonationsMaxOrderByAggregateInput
    _min?: fundDonationsMinOrderByAggregateInput
    _sum?: fundDonationsSumOrderByAggregateInput
  }

  export type fundDonationsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<fundDonationsScalarWhereWithAggregatesInput>
    OR?: Enumerable<fundDonationsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<fundDonationsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    donationId?: StringNullableWithAggregatesFilter | string | null
    fundId?: StringNullableWithAggregatesFilter | string | null
    amount?: FloatNullableWithAggregatesFilter | number | null
  }

  export type fundsWhereInput = {
    AND?: Enumerable<fundsWhereInput>
    OR?: Enumerable<fundsWhereInput>
    NOT?: Enumerable<fundsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    productId?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
    fundDonations?: FundDonationsListRelationFilter
  }

  export type fundsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    productId?: SortOrder
    removed?: SortOrder
    fundDonations?: fundDonationsOrderByRelationAggregateInput
  }

  export type fundsWhereUniqueInput = {
    id?: string
  }

  export type fundsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    productId?: SortOrder
    removed?: SortOrder
    _count?: fundsCountOrderByAggregateInput
    _max?: fundsMaxOrderByAggregateInput
    _min?: fundsMinOrderByAggregateInput
  }

  export type fundsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<fundsScalarWhereWithAggregatesInput>
    OR?: Enumerable<fundsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<fundsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    productId?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type gatewaysWhereInput = {
    AND?: Enumerable<gatewaysWhereInput>
    OR?: Enumerable<gatewaysWhereInput>
    NOT?: Enumerable<gatewaysWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    provider?: StringNullableFilter | string | null
    publicKey?: StringNullableFilter | string | null
    privateKey?: StringNullableFilter | string | null
    webhookKey?: StringNullableFilter | string | null
    productId?: StringNullableFilter | string | null
  }

  export type gatewaysOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    provider?: SortOrder
    publicKey?: SortOrder
    privateKey?: SortOrder
    webhookKey?: SortOrder
    productId?: SortOrder
  }

  export type gatewaysWhereUniqueInput = {
    id?: string
  }

  export type gatewaysOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    provider?: SortOrder
    publicKey?: SortOrder
    privateKey?: SortOrder
    webhookKey?: SortOrder
    productId?: SortOrder
    _count?: gatewaysCountOrderByAggregateInput
    _max?: gatewaysMaxOrderByAggregateInput
    _min?: gatewaysMinOrderByAggregateInput
  }

  export type gatewaysScalarWhereWithAggregatesInput = {
    AND?: Enumerable<gatewaysScalarWhereWithAggregatesInput>
    OR?: Enumerable<gatewaysScalarWhereWithAggregatesInput>
    NOT?: Enumerable<gatewaysScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    provider?: StringNullableWithAggregatesFilter | string | null
    publicKey?: StringNullableWithAggregatesFilter | string | null
    privateKey?: StringNullableWithAggregatesFilter | string | null
    webhookKey?: StringNullableWithAggregatesFilter | string | null
    productId?: StringNullableWithAggregatesFilter | string | null
  }

  export type subscriptionFundsWhereInput = {
    AND?: Enumerable<subscriptionFundsWhereInput>
    OR?: Enumerable<subscriptionFundsWhereInput>
    NOT?: Enumerable<subscriptionFundsWhereInput>
    id?: StringFilter | string
    churchId?: StringFilter | string
    subscriptionId?: StringNullableFilter | string | null
    fundId?: StringNullableFilter | string | null
    amount?: FloatNullableFilter | number | null
  }

  export type subscriptionFundsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    subscriptionId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type subscriptionFundsWhereUniqueInput = {
    id?: string
  }

  export type subscriptionFundsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    subscriptionId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
    _count?: subscriptionFundsCountOrderByAggregateInput
    _avg?: subscriptionFundsAvgOrderByAggregateInput
    _max?: subscriptionFundsMaxOrderByAggregateInput
    _min?: subscriptionFundsMinOrderByAggregateInput
    _sum?: subscriptionFundsSumOrderByAggregateInput
  }

  export type subscriptionFundsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<subscriptionFundsScalarWhereWithAggregatesInput>
    OR?: Enumerable<subscriptionFundsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<subscriptionFundsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringWithAggregatesFilter | string
    subscriptionId?: StringNullableWithAggregatesFilter | string | null
    fundId?: StringNullableWithAggregatesFilter | string | null
    amount?: FloatNullableWithAggregatesFilter | number | null
  }

  export type subscriptionsWhereInput = {
    AND?: Enumerable<subscriptionsWhereInput>
    OR?: Enumerable<subscriptionsWhereInput>
    NOT?: Enumerable<subscriptionsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    customerId?: StringNullableFilter | string | null
  }

  export type subscriptionsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    customerId?: SortOrder
  }

  export type subscriptionsWhereUniqueInput = {
    id?: string
  }

  export type subscriptionsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    customerId?: SortOrder
    _count?: subscriptionsCountOrderByAggregateInput
    _max?: subscriptionsMaxOrderByAggregateInput
    _min?: subscriptionsMinOrderByAggregateInput
  }

  export type subscriptionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<subscriptionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<subscriptionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<subscriptionsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    personId?: StringNullableWithAggregatesFilter | string | null
    customerId?: StringNullableWithAggregatesFilter | string | null
  }

  export type campusesWhereInput = {
    AND?: Enumerable<campusesWhereInput>
    OR?: Enumerable<campusesWhereInput>
    NOT?: Enumerable<campusesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    address1?: StringNullableFilter | string | null
    address2?: StringNullableFilter | string | null
    city?: StringNullableFilter | string | null
    state?: StringNullableFilter | string | null
    zip?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type campusesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    removed?: SortOrder
  }

  export type campusesWhereUniqueInput = {
    id?: string
  }

  export type campusesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    removed?: SortOrder
    _count?: campusesCountOrderByAggregateInput
    _max?: campusesMaxOrderByAggregateInput
    _min?: campusesMinOrderByAggregateInput
  }

  export type campusesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<campusesScalarWhereWithAggregatesInput>
    OR?: Enumerable<campusesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<campusesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    address1?: StringNullableWithAggregatesFilter | string | null
    address2?: StringNullableWithAggregatesFilter | string | null
    city?: StringNullableWithAggregatesFilter | string | null
    state?: StringNullableWithAggregatesFilter | string | null
    zip?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type groupServiceTimesWhereInput = {
    AND?: Enumerable<groupServiceTimesWhereInput>
    OR?: Enumerable<groupServiceTimesWhereInput>
    NOT?: Enumerable<groupServiceTimesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    groupId?: StringNullableFilter | string | null
    serviceTimeId?: StringNullableFilter | string | null
  }

  export type groupServiceTimesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
  }

  export type groupServiceTimesWhereUniqueInput = {
    id?: string
  }

  export type groupServiceTimesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    _count?: groupServiceTimesCountOrderByAggregateInput
    _max?: groupServiceTimesMaxOrderByAggregateInput
    _min?: groupServiceTimesMinOrderByAggregateInput
  }

  export type groupServiceTimesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<groupServiceTimesScalarWhereWithAggregatesInput>
    OR?: Enumerable<groupServiceTimesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<groupServiceTimesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    groupId?: StringNullableWithAggregatesFilter | string | null
    serviceTimeId?: StringNullableWithAggregatesFilter | string | null
  }

  export type serviceTimesWhereInput = {
    AND?: Enumerable<serviceTimesWhereInput>
    OR?: Enumerable<serviceTimesWhereInput>
    NOT?: Enumerable<serviceTimesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    serviceId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type serviceTimesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    serviceId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type serviceTimesWhereUniqueInput = {
    id?: string
  }

  export type serviceTimesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    serviceId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
    _count?: serviceTimesCountOrderByAggregateInput
    _max?: serviceTimesMaxOrderByAggregateInput
    _min?: serviceTimesMinOrderByAggregateInput
  }

  export type serviceTimesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<serviceTimesScalarWhereWithAggregatesInput>
    OR?: Enumerable<serviceTimesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<serviceTimesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    serviceId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type servicesWhereInput = {
    AND?: Enumerable<servicesWhereInput>
    OR?: Enumerable<servicesWhereInput>
    NOT?: Enumerable<servicesWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    campusId?: StringNullableFilter | string | null
    name?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type servicesOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    campusId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type servicesWhereUniqueInput = {
    id?: string
  }

  export type servicesOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    campusId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
    _count?: servicesCountOrderByAggregateInput
    _max?: servicesMaxOrderByAggregateInput
    _min?: servicesMinOrderByAggregateInput
  }

  export type servicesScalarWhereWithAggregatesInput = {
    AND?: Enumerable<servicesScalarWhereWithAggregatesInput>
    OR?: Enumerable<servicesScalarWhereWithAggregatesInput>
    NOT?: Enumerable<servicesScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    campusId?: StringNullableWithAggregatesFilter | string | null
    name?: StringNullableWithAggregatesFilter | string | null
    removed?: BoolNullableWithAggregatesFilter | boolean | null
  }

  export type sessionsWhereInput = {
    AND?: Enumerable<sessionsWhereInput>
    OR?: Enumerable<sessionsWhereInput>
    NOT?: Enumerable<sessionsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    groupId?: StringNullableFilter | string | null
    serviceTimeId?: StringNullableFilter | string | null
    sessionDate?: DateTimeNullableFilter | Date | string | null
    visits?: VisitSessionsListRelationFilter
  }

  export type sessionsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    sessionDate?: SortOrder
    visits?: visitSessionsOrderByRelationAggregateInput
  }

  export type sessionsWhereUniqueInput = {
    id?: string
  }

  export type sessionsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    sessionDate?: SortOrder
    _count?: sessionsCountOrderByAggregateInput
    _max?: sessionsMaxOrderByAggregateInput
    _min?: sessionsMinOrderByAggregateInput
  }

  export type sessionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<sessionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<sessionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<sessionsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    groupId?: StringNullableWithAggregatesFilter | string | null
    serviceTimeId?: StringNullableWithAggregatesFilter | string | null
    sessionDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
  }

  export type visitSessionsWhereInput = {
    AND?: Enumerable<visitSessionsWhereInput>
    OR?: Enumerable<visitSessionsWhereInput>
    NOT?: Enumerable<visitSessionsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    visitId?: StringNullableFilter | string | null
    sessionId?: StringNullableFilter | string | null
    visit?: XOR<VisitsRelationFilter, visitsWhereInput> | null
    session?: XOR<SessionsRelationFilter, sessionsWhereInput> | null
  }

  export type visitSessionsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    visitId?: SortOrder
    sessionId?: SortOrder
    visit?: visitsOrderByWithRelationInput
    session?: sessionsOrderByWithRelationInput
  }

  export type visitSessionsWhereUniqueInput = {
    id?: string
  }

  export type visitSessionsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    visitId?: SortOrder
    sessionId?: SortOrder
    _count?: visitSessionsCountOrderByAggregateInput
    _max?: visitSessionsMaxOrderByAggregateInput
    _min?: visitSessionsMinOrderByAggregateInput
  }

  export type visitSessionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<visitSessionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<visitSessionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<visitSessionsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    visitId?: StringNullableWithAggregatesFilter | string | null
    sessionId?: StringNullableWithAggregatesFilter | string | null
  }

  export type visitsWhereInput = {
    AND?: Enumerable<visitsWhereInput>
    OR?: Enumerable<visitsWhereInput>
    NOT?: Enumerable<visitsWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    serviceId?: StringNullableFilter | string | null
    groupId?: StringNullableFilter | string | null
    visitDate?: DateTimeNullableFilter | Date | string | null
    checkinTime?: DateTimeNullableFilter | Date | string | null
    addedBy?: StringNullableFilter | string | null
    session?: VisitSessionsListRelationFilter
  }

  export type visitsOrderByWithRelationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    serviceId?: SortOrder
    groupId?: SortOrder
    visitDate?: SortOrder
    checkinTime?: SortOrder
    addedBy?: SortOrder
    session?: visitSessionsOrderByRelationAggregateInput
  }

  export type visitsWhereUniqueInput = {
    id?: string
  }

  export type visitsOrderByWithAggregationInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    serviceId?: SortOrder
    groupId?: SortOrder
    visitDate?: SortOrder
    checkinTime?: SortOrder
    addedBy?: SortOrder
    _count?: visitsCountOrderByAggregateInput
    _max?: visitsMaxOrderByAggregateInput
    _min?: visitsMinOrderByAggregateInput
  }

  export type visitsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<visitsScalarWhereWithAggregatesInput>
    OR?: Enumerable<visitsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<visitsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    churchId?: StringNullableWithAggregatesFilter | string | null
    personId?: StringNullableWithAggregatesFilter | string | null
    serviceId?: StringNullableWithAggregatesFilter | string | null
    groupId?: StringNullableWithAggregatesFilter | string | null
    visitDate?: DateTimeNullableWithAggregatesFilter | Date | string | null
    checkinTime?: DateTimeNullableWithAggregatesFilter | Date | string | null
    addedBy?: StringNullableWithAggregatesFilter | string | null
  }

  export type answersCreateInput = {
    id: string
    churchId?: string | null
    formSubmissionId?: string | null
    questionId?: string | null
    value?: string | null
  }

  export type answersUncheckedCreateInput = {
    id: string
    churchId?: string | null
    formSubmissionId?: string | null
    questionId?: string | null
    value?: string | null
  }

  export type answersUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formSubmissionId?: NullableStringFieldUpdateOperationsInput | string | null
    questionId?: NullableStringFieldUpdateOperationsInput | string | null
    value?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type answersUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formSubmissionId?: NullableStringFieldUpdateOperationsInput | string | null
    questionId?: NullableStringFieldUpdateOperationsInput | string | null
    value?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type answersCreateManyInput = {
    id: string
    churchId?: string | null
    formSubmissionId?: string | null
    questionId?: string | null
    value?: string | null
  }

  export type answersUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formSubmissionId?: NullableStringFieldUpdateOperationsInput | string | null
    questionId?: NullableStringFieldUpdateOperationsInput | string | null
    value?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type answersUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formSubmissionId?: NullableStringFieldUpdateOperationsInput | string | null
    questionId?: NullableStringFieldUpdateOperationsInput | string | null
    value?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type formSubmissionsCreateInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    contentType?: string | null
    contentId?: string | null
    submissionDate?: Date | string | null
    submittedBy?: string | null
    revisionDate?: Date | string | null
    revisedBy?: string | null
  }

  export type formSubmissionsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    contentType?: string | null
    contentId?: string | null
    submissionDate?: Date | string | null
    submittedBy?: string | null
    revisionDate?: Date | string | null
    revisedBy?: string | null
  }

  export type formSubmissionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    submissionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    submittedBy?: NullableStringFieldUpdateOperationsInput | string | null
    revisionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    revisedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type formSubmissionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    submissionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    submittedBy?: NullableStringFieldUpdateOperationsInput | string | null
    revisionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    revisedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type formSubmissionsCreateManyInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    contentType?: string | null
    contentId?: string | null
    submissionDate?: Date | string | null
    submittedBy?: string | null
    revisionDate?: Date | string | null
    revisedBy?: string | null
  }

  export type formSubmissionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    submissionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    submittedBy?: NullableStringFieldUpdateOperationsInput | string | null
    revisionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    revisedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type formSubmissionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    submissionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    submittedBy?: NullableStringFieldUpdateOperationsInput | string | null
    revisionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    revisedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type formsCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    contentType?: string | null
    createdTime?: Date | string | null
    modifiedTime?: Date | string | null
    removed?: boolean | null
  }

  export type formsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    contentType?: string | null
    createdTime?: Date | string | null
    modifiedTime?: Date | string | null
    removed?: boolean | null
  }

  export type formsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    createdTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    modifiedTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type formsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    createdTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    modifiedTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type formsCreateManyInput = {
    id: string
    churchId?: string | null
    name?: string | null
    contentType?: string | null
    createdTime?: Date | string | null
    modifiedTime?: Date | string | null
    removed?: boolean | null
  }

  export type formsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    createdTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    modifiedTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type formsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    createdTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    modifiedTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupMembersCreateInput = {
    id: string
    churchId?: string | null
    joinDate?: Date | string | null
    group?: groupsCreateNestedOneWithoutUsersInput
    person?: peopleCreateNestedOneWithoutGroupsInput
  }

  export type groupMembersUncheckedCreateInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    personId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    group?: groupsUpdateOneWithoutUsersInput
    person?: peopleUpdateOneWithoutGroupsInput
  }

  export type groupMembersUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type groupMembersCreateManyInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    personId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type groupMembersUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type groupsCreateInput = {
    id: string
    churchId?: string | null
    categoryName?: string | null
    name?: string | null
    trackAttendance?: boolean | null
    parentPickup?: boolean | null
    removed?: boolean | null
    users?: groupMembersCreateNestedManyWithoutGroupInput
  }

  export type groupsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    categoryName?: string | null
    name?: string | null
    trackAttendance?: boolean | null
    parentPickup?: boolean | null
    removed?: boolean | null
    users?: groupMembersUncheckedCreateNestedManyWithoutGroupInput
  }

  export type groupsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    users?: groupMembersUpdateManyWithoutGroupInput
  }

  export type groupsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    users?: groupMembersUncheckedUpdateManyWithoutGroupInput
  }

  export type groupsCreateManyInput = {
    id: string
    churchId?: string | null
    categoryName?: string | null
    name?: string | null
    trackAttendance?: boolean | null
    parentPickup?: boolean | null
    removed?: boolean | null
  }

  export type groupsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type householdsCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    people?: peopleCreateNestedManyWithoutHouseholdInput
  }

  export type householdsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    people?: peopleUncheckedCreateNestedManyWithoutHouseholdInput
  }

  export type householdsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    people?: peopleUpdateManyWithoutHouseholdInput
  }

  export type householdsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    people?: peopleUncheckedUpdateManyWithoutHouseholdInput
  }

  export type householdsCreateManyInput = {
    id: string
    churchId?: string | null
    name?: string | null
  }

  export type householdsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type householdsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type notesCreateInput = {
    id: string
    churchId?: string | null
    contentType?: string | null
    contentId?: string | null
    noteType?: string | null
    addedBy?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    contents?: string | null
  }

  export type notesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    contentType?: string | null
    contentId?: string | null
    noteType?: string | null
    addedBy?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    contents?: string | null
  }

  export type notesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    noteType?: NullableStringFieldUpdateOperationsInput | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    contents?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type notesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    noteType?: NullableStringFieldUpdateOperationsInput | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    contents?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type notesCreateManyInput = {
    id: string
    churchId?: string | null
    contentType?: string | null
    contentId?: string | null
    noteType?: string | null
    addedBy?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    contents?: string | null
  }

  export type notesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    noteType?: NullableStringFieldUpdateOperationsInput | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    contents?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type notesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: NullableStringFieldUpdateOperationsInput | string | null
    contentId?: NullableStringFieldUpdateOperationsInput | string | null
    noteType?: NullableStringFieldUpdateOperationsInput | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    contents?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type peopleCreateInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdRole?: string | null
    removed?: boolean | null
    groups?: groupMembersCreateNestedManyWithoutPersonInput
    household?: householdsCreateNestedOneWithoutPeopleInput
  }

  export type peopleUncheckedCreateInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdId?: string | null
    householdRole?: string | null
    removed?: boolean | null
    groups?: groupMembersUncheckedCreateNestedManyWithoutPersonInput
  }

  export type peopleUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    groups?: groupMembersUpdateManyWithoutPersonInput
    household?: householdsUpdateOneWithoutPeopleInput
  }

  export type peopleUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdId?: NullableStringFieldUpdateOperationsInput | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    groups?: groupMembersUncheckedUpdateManyWithoutPersonInput
  }

  export type peopleCreateManyInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdId?: string | null
    householdRole?: string | null
    removed?: boolean | null
  }

  export type peopleUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type peopleUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdId?: NullableStringFieldUpdateOperationsInput | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type questionsCreateInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    parentId?: string | null
    title?: string | null
    description?: string | null
    fieldType?: string | null
    placeholder?: string | null
    sort?: string | null
    choices?: string | null
    removed?: boolean | null
  }

  export type questionsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    parentId?: string | null
    title?: string | null
    description?: string | null
    fieldType?: string | null
    placeholder?: string | null
    sort?: string | null
    choices?: string | null
    removed?: boolean | null
  }

  export type questionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    title?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    fieldType?: NullableStringFieldUpdateOperationsInput | string | null
    placeholder?: NullableStringFieldUpdateOperationsInput | string | null
    sort?: NullableStringFieldUpdateOperationsInput | string | null
    choices?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type questionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    title?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    fieldType?: NullableStringFieldUpdateOperationsInput | string | null
    placeholder?: NullableStringFieldUpdateOperationsInput | string | null
    sort?: NullableStringFieldUpdateOperationsInput | string | null
    choices?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type questionsCreateManyInput = {
    id: string
    churchId?: string | null
    formId?: string | null
    parentId?: string | null
    title?: string | null
    description?: string | null
    fieldType?: string | null
    placeholder?: string | null
    sort?: string | null
    choices?: string | null
    removed?: boolean | null
  }

  export type questionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    title?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    fieldType?: NullableStringFieldUpdateOperationsInput | string | null
    placeholder?: NullableStringFieldUpdateOperationsInput | string | null
    sort?: NullableStringFieldUpdateOperationsInput | string | null
    choices?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type questionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    formId?: NullableStringFieldUpdateOperationsInput | string | null
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    title?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    fieldType?: NullableStringFieldUpdateOperationsInput | string | null
    placeholder?: NullableStringFieldUpdateOperationsInput | string | null
    sort?: NullableStringFieldUpdateOperationsInput | string | null
    choices?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type customersCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
  }

  export type customersUncheckedCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
  }

  export type customersUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type customersUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type customersCreateManyInput = {
    id: string
    churchId?: string | null
    personId?: string | null
  }

  export type customersUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type customersUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type donationBatchesCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    batchDate?: Date | string | null
    donations?: donationsCreateNestedManyWithoutDonationBatchesInput
  }

  export type donationBatchesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    batchDate?: Date | string | null
    donations?: donationsUncheckedCreateNestedManyWithoutDonationBatchesInput
  }

  export type donationBatchesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    donations?: donationsUpdateManyWithoutDonationBatchesInput
  }

  export type donationBatchesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    donations?: donationsUncheckedUpdateManyWithoutDonationBatchesInput
  }

  export type donationBatchesCreateManyInput = {
    id: string
    churchId?: string | null
    name?: string | null
    batchDate?: Date | string | null
  }

  export type donationBatchesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type donationBatchesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type donationsCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
    donationBatches?: donationBatchesCreateNestedOneWithoutDonationsInput
    fundDonations?: fundDonationsCreateNestedManyWithoutDonationInput
  }

  export type donationsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    batchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
    fundDonations?: fundDonationsUncheckedCreateNestedManyWithoutDonationInput
  }

  export type donationsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    donationBatches?: donationBatchesUpdateOneWithoutDonationsInput
    fundDonations?: fundDonationsUpdateManyWithoutDonationInput
  }

  export type donationsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    batchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    fundDonations?: fundDonationsUncheckedUpdateManyWithoutDonationInput
  }

  export type donationsCreateManyInput = {
    id: string
    churchId?: string | null
    batchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
  }

  export type donationsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type donationsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    batchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eventLogsCreateInput = {
    id: string
    churchId?: string | null
    customerId?: string | null
    provider?: string | null
    status?: string | null
    eventType?: string | null
    message?: string | null
    created?: Date | string | null
    resolved?: boolean | null
  }

  export type eventLogsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    customerId?: string | null
    provider?: string | null
    status?: string | null
    eventType?: string | null
    message?: string | null
    created?: Date | string | null
    resolved?: boolean | null
  }

  export type eventLogsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    created?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    resolved?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type eventLogsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    created?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    resolved?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type eventLogsCreateManyInput = {
    id: string
    churchId?: string | null
    customerId?: string | null
    provider?: string | null
    status?: string | null
    eventType?: string | null
    message?: string | null
    created?: Date | string | null
    resolved?: boolean | null
  }

  export type eventLogsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    created?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    resolved?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type eventLogsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    created?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    resolved?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type fundDonationsCreateInput = {
    id: string
    churchId?: string | null
    amount?: number | null
    fund?: fundsCreateNestedOneWithoutFundDonationsInput
    donation?: donationsCreateNestedOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    donationId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type fundDonationsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    fund?: fundsUpdateOneWithoutFundDonationsInput
    donation?: donationsUpdateOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    donationId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type fundDonationsCreateManyInput = {
    id: string
    churchId?: string | null
    donationId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type fundDonationsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type fundDonationsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    donationId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type fundsCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    productId?: string | null
    removed?: boolean | null
    fundDonations?: fundDonationsCreateNestedManyWithoutFundInput
  }

  export type fundsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    productId?: string | null
    removed?: boolean | null
    fundDonations?: fundDonationsUncheckedCreateNestedManyWithoutFundInput
  }

  export type fundsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    fundDonations?: fundDonationsUpdateManyWithoutFundInput
  }

  export type fundsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    fundDonations?: fundDonationsUncheckedUpdateManyWithoutFundInput
  }

  export type fundsCreateManyInput = {
    id: string
    churchId?: string | null
    name?: string | null
    productId?: string | null
    removed?: boolean | null
  }

  export type fundsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type fundsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type gatewaysCreateInput = {
    id: string
    churchId?: string | null
    provider?: string | null
    publicKey?: string | null
    privateKey?: string | null
    webhookKey?: string | null
    productId?: string | null
  }

  export type gatewaysUncheckedCreateInput = {
    id: string
    churchId?: string | null
    provider?: string | null
    publicKey?: string | null
    privateKey?: string | null
    webhookKey?: string | null
    productId?: string | null
  }

  export type gatewaysUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    publicKey?: NullableStringFieldUpdateOperationsInput | string | null
    privateKey?: NullableStringFieldUpdateOperationsInput | string | null
    webhookKey?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type gatewaysUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    publicKey?: NullableStringFieldUpdateOperationsInput | string | null
    privateKey?: NullableStringFieldUpdateOperationsInput | string | null
    webhookKey?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type gatewaysCreateManyInput = {
    id: string
    churchId?: string | null
    provider?: string | null
    publicKey?: string | null
    privateKey?: string | null
    webhookKey?: string | null
    productId?: string | null
  }

  export type gatewaysUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    publicKey?: NullableStringFieldUpdateOperationsInput | string | null
    privateKey?: NullableStringFieldUpdateOperationsInput | string | null
    webhookKey?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type gatewaysUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    publicKey?: NullableStringFieldUpdateOperationsInput | string | null
    privateKey?: NullableStringFieldUpdateOperationsInput | string | null
    webhookKey?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type subscriptionFundsCreateInput = {
    id: string
    churchId: string
    subscriptionId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type subscriptionFundsUncheckedCreateInput = {
    id: string
    churchId: string
    subscriptionId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type subscriptionFundsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type subscriptionFundsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type subscriptionFundsCreateManyInput = {
    id: string
    churchId: string
    subscriptionId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type subscriptionFundsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type subscriptionFundsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type subscriptionsCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    customerId?: string | null
  }

  export type subscriptionsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    customerId?: string | null
  }

  export type subscriptionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type subscriptionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type subscriptionsCreateManyInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    customerId?: string | null
  }

  export type subscriptionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type subscriptionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type campusesCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    removed?: boolean | null
  }

  export type campusesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    name?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    removed?: boolean | null
  }

  export type campusesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type campusesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type campusesCreateManyInput = {
    id: string
    churchId?: string | null
    name?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    removed?: boolean | null
  }

  export type campusesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type campusesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupServiceTimesCreateInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
  }

  export type groupServiceTimesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
  }

  export type groupServiceTimesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type groupServiceTimesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type groupServiceTimesCreateManyInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
  }

  export type groupServiceTimesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type groupServiceTimesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type serviceTimesCreateInput = {
    id: string
    churchId?: string | null
    serviceId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type serviceTimesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    serviceId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type serviceTimesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type serviceTimesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type serviceTimesCreateManyInput = {
    id: string
    churchId?: string | null
    serviceId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type serviceTimesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type serviceTimesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type servicesCreateInput = {
    id: string
    churchId?: string | null
    campusId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type servicesUncheckedCreateInput = {
    id: string
    churchId?: string | null
    campusId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type servicesUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    campusId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type servicesUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    campusId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type servicesCreateManyInput = {
    id: string
    churchId?: string | null
    campusId?: string | null
    name?: string | null
    removed?: boolean | null
  }

  export type servicesUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    campusId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type servicesUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    campusId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type sessionsCreateInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
    sessionDate?: Date | string | null
    visits?: visitSessionsCreateNestedManyWithoutSessionInput
  }

  export type sessionsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
    sessionDate?: Date | string | null
    visits?: visitSessionsUncheckedCreateNestedManyWithoutSessionInput
  }

  export type sessionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    visits?: visitSessionsUpdateManyWithoutSessionInput
  }

  export type sessionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    visits?: visitSessionsUncheckedUpdateManyWithoutSessionInput
  }

  export type sessionsCreateManyInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
    sessionDate?: Date | string | null
  }

  export type sessionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type sessionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type visitSessionsCreateInput = {
    id: string
    churchId?: string | null
    visit?: visitsCreateNestedOneWithoutSessionInput
    session?: sessionsCreateNestedOneWithoutVisitsInput
  }

  export type visitSessionsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    visitId?: string | null
    sessionId?: string | null
  }

  export type visitSessionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visit?: visitsUpdateOneWithoutSessionInput
    session?: sessionsUpdateOneWithoutVisitsInput
  }

  export type visitSessionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visitId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitSessionsCreateManyInput = {
    id: string
    churchId?: string | null
    visitId?: string | null
    sessionId?: string | null
  }

  export type visitSessionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitSessionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visitId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitsCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    serviceId?: string | null
    groupId?: string | null
    visitDate?: Date | string | null
    checkinTime?: Date | string | null
    addedBy?: string | null
    session?: visitSessionsCreateNestedManyWithoutVisitInput
  }

  export type visitsUncheckedCreateInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    serviceId?: string | null
    groupId?: string | null
    visitDate?: Date | string | null
    checkinTime?: Date | string | null
    addedBy?: string | null
    session?: visitSessionsUncheckedCreateNestedManyWithoutVisitInput
  }

  export type visitsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    session?: visitSessionsUpdateManyWithoutVisitInput
  }

  export type visitsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
    session?: visitSessionsUncheckedUpdateManyWithoutVisitInput
  }

  export type visitsCreateManyInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    serviceId?: string | null
    groupId?: string | null
    visitDate?: Date | string | null
    checkinTime?: Date | string | null
    addedBy?: string | null
  }

  export type visitsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type StringFilter = {
    equals?: string
    in?: Enumerable<string>
    notIn?: Enumerable<string>
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringFilter | string
  }

  export type StringNullableFilter = {
    equals?: string | null
    in?: Enumerable<string> | null
    notIn?: Enumerable<string> | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableFilter | string | null
  }

  export type answersCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formSubmissionId?: SortOrder
    questionId?: SortOrder
    value?: SortOrder
  }

  export type answersMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formSubmissionId?: SortOrder
    questionId?: SortOrder
    value?: SortOrder
  }

  export type answersMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formSubmissionId?: SortOrder
    questionId?: SortOrder
    value?: SortOrder
  }

  export type StringWithAggregatesFilter = {
    equals?: string
    in?: Enumerable<string>
    notIn?: Enumerable<string>
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringWithAggregatesFilter | string
    _count?: NestedIntFilter
    _min?: NestedStringFilter
    _max?: NestedStringFilter
  }

  export type StringNullableWithAggregatesFilter = {
    equals?: string | null
    in?: Enumerable<string> | null
    notIn?: Enumerable<string> | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableWithAggregatesFilter | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedStringNullableFilter
    _max?: NestedStringNullableFilter
  }

  export type DateTimeNullableFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | null
    notIn?: Enumerable<Date> | Enumerable<string> | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableFilter | Date | string | null
  }

  export type formSubmissionsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    submissionDate?: SortOrder
    submittedBy?: SortOrder
    revisionDate?: SortOrder
    revisedBy?: SortOrder
  }

  export type formSubmissionsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    submissionDate?: SortOrder
    submittedBy?: SortOrder
    revisionDate?: SortOrder
    revisedBy?: SortOrder
  }

  export type formSubmissionsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    submissionDate?: SortOrder
    submittedBy?: SortOrder
    revisionDate?: SortOrder
    revisedBy?: SortOrder
  }

  export type DateTimeNullableWithAggregatesFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | null
    notIn?: Enumerable<Date> | Enumerable<string> | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableWithAggregatesFilter | Date | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedDateTimeNullableFilter
    _max?: NestedDateTimeNullableFilter
  }

  export type BoolNullableFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableFilter | boolean | null
  }

  export type formsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    contentType?: SortOrder
    createdTime?: SortOrder
    modifiedTime?: SortOrder
    removed?: SortOrder
  }

  export type formsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    contentType?: SortOrder
    createdTime?: SortOrder
    modifiedTime?: SortOrder
    removed?: SortOrder
  }

  export type formsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    contentType?: SortOrder
    createdTime?: SortOrder
    modifiedTime?: SortOrder
    removed?: SortOrder
  }

  export type BoolNullableWithAggregatesFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableWithAggregatesFilter | boolean | null
    _count?: NestedIntNullableFilter
    _min?: NestedBoolNullableFilter
    _max?: NestedBoolNullableFilter
  }

  export type GroupsRelationFilter = {
    is?: groupsWhereInput | null
    isNot?: groupsWhereInput | null
  }

  export type PeopleRelationFilter = {
    is?: peopleWhereInput | null
    isNot?: peopleWhereInput | null
  }

  export type groupMembersCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    personId?: SortOrder
    joinDate?: SortOrder
  }

  export type groupMembersMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    personId?: SortOrder
    joinDate?: SortOrder
  }

  export type groupMembersMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    personId?: SortOrder
    joinDate?: SortOrder
  }

  export type GroupMembersListRelationFilter = {
    every?: groupMembersWhereInput
    some?: groupMembersWhereInput
    none?: groupMembersWhereInput
  }

  export type groupMembersOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type groupsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    categoryName?: SortOrder
    name?: SortOrder
    trackAttendance?: SortOrder
    parentPickup?: SortOrder
    removed?: SortOrder
  }

  export type groupsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    categoryName?: SortOrder
    name?: SortOrder
    trackAttendance?: SortOrder
    parentPickup?: SortOrder
    removed?: SortOrder
  }

  export type groupsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    categoryName?: SortOrder
    name?: SortOrder
    trackAttendance?: SortOrder
    parentPickup?: SortOrder
    removed?: SortOrder
  }

  export type PeopleListRelationFilter = {
    every?: peopleWhereInput
    some?: peopleWhereInput
    none?: peopleWhereInput
  }

  export type peopleOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type householdsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
  }

  export type householdsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
  }

  export type householdsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
  }

  export type notesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    noteType?: SortOrder
    addedBy?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contents?: SortOrder
  }

  export type notesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    noteType?: SortOrder
    addedBy?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contents?: SortOrder
  }

  export type notesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    contentType?: SortOrder
    contentId?: SortOrder
    noteType?: SortOrder
    addedBy?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contents?: SortOrder
  }

  export type HouseholdsRelationFilter = {
    is?: householdsWhereInput | null
    isNot?: householdsWhereInput | null
  }

  export type peopleCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    displayName?: SortOrder
    firstName?: SortOrder
    middleName?: SortOrder
    lastName?: SortOrder
    nickName?: SortOrder
    prefix?: SortOrder
    suffix?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    maritalStatus?: SortOrder
    anniversary?: SortOrder
    membershipStatus?: SortOrder
    homePhone?: SortOrder
    mobilePhone?: SortOrder
    workPhone?: SortOrder
    email?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    photoUpdated?: SortOrder
    householdId?: SortOrder
    householdRole?: SortOrder
    removed?: SortOrder
  }

  export type peopleMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    displayName?: SortOrder
    firstName?: SortOrder
    middleName?: SortOrder
    lastName?: SortOrder
    nickName?: SortOrder
    prefix?: SortOrder
    suffix?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    maritalStatus?: SortOrder
    anniversary?: SortOrder
    membershipStatus?: SortOrder
    homePhone?: SortOrder
    mobilePhone?: SortOrder
    workPhone?: SortOrder
    email?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    photoUpdated?: SortOrder
    householdId?: SortOrder
    householdRole?: SortOrder
    removed?: SortOrder
  }

  export type peopleMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    displayName?: SortOrder
    firstName?: SortOrder
    middleName?: SortOrder
    lastName?: SortOrder
    nickName?: SortOrder
    prefix?: SortOrder
    suffix?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    maritalStatus?: SortOrder
    anniversary?: SortOrder
    membershipStatus?: SortOrder
    homePhone?: SortOrder
    mobilePhone?: SortOrder
    workPhone?: SortOrder
    email?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    photoUpdated?: SortOrder
    householdId?: SortOrder
    householdRole?: SortOrder
    removed?: SortOrder
  }

  export type questionsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    parentId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    fieldType?: SortOrder
    placeholder?: SortOrder
    sort?: SortOrder
    choices?: SortOrder
    removed?: SortOrder
  }

  export type questionsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    parentId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    fieldType?: SortOrder
    placeholder?: SortOrder
    sort?: SortOrder
    choices?: SortOrder
    removed?: SortOrder
  }

  export type questionsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    formId?: SortOrder
    parentId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    fieldType?: SortOrder
    placeholder?: SortOrder
    sort?: SortOrder
    choices?: SortOrder
    removed?: SortOrder
  }

  export type customersCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
  }

  export type customersMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
  }

  export type customersMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
  }

  export type DonationsListRelationFilter = {
    every?: donationsWhereInput
    some?: donationsWhereInput
    none?: donationsWhereInput
  }

  export type donationsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type donationBatchesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    batchDate?: SortOrder
  }

  export type donationBatchesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    batchDate?: SortOrder
  }

  export type donationBatchesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    batchDate?: SortOrder
  }

  export type FloatNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | null
    notIn?: Enumerable<number> | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatNullableFilter | number | null
  }

  export type DonationBatchesRelationFilter = {
    is?: donationBatchesWhereInput | null
    isNot?: donationBatchesWhereInput | null
  }

  export type FundDonationsListRelationFilter = {
    every?: fundDonationsWhereInput
    some?: fundDonationsWhereInput
    none?: fundDonationsWhereInput
  }

  export type fundDonationsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type donationsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    batchId?: SortOrder
    personId?: SortOrder
    donationDate?: SortOrder
    amount?: SortOrder
    method?: SortOrder
    methodDetails?: SortOrder
    notes?: SortOrder
  }

  export type donationsAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type donationsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    batchId?: SortOrder
    personId?: SortOrder
    donationDate?: SortOrder
    amount?: SortOrder
    method?: SortOrder
    methodDetails?: SortOrder
    notes?: SortOrder
  }

  export type donationsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    batchId?: SortOrder
    personId?: SortOrder
    donationDate?: SortOrder
    amount?: SortOrder
    method?: SortOrder
    methodDetails?: SortOrder
    notes?: SortOrder
  }

  export type donationsSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type FloatNullableWithAggregatesFilter = {
    equals?: number | null
    in?: Enumerable<number> | null
    notIn?: Enumerable<number> | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatNullableWithAggregatesFilter | number | null
    _count?: NestedIntNullableFilter
    _avg?: NestedFloatNullableFilter
    _sum?: NestedFloatNullableFilter
    _min?: NestedFloatNullableFilter
    _max?: NestedFloatNullableFilter
  }

  export type eventLogsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    customerId?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    eventType?: SortOrder
    message?: SortOrder
    created?: SortOrder
    resolved?: SortOrder
  }

  export type eventLogsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    customerId?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    eventType?: SortOrder
    message?: SortOrder
    created?: SortOrder
    resolved?: SortOrder
  }

  export type eventLogsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    customerId?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    eventType?: SortOrder
    message?: SortOrder
    created?: SortOrder
    resolved?: SortOrder
  }

  export type FundsRelationFilter = {
    is?: fundsWhereInput | null
    isNot?: fundsWhereInput | null
  }

  export type DonationsRelationFilter = {
    is?: donationsWhereInput | null
    isNot?: donationsWhereInput | null
  }

  export type fundDonationsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    donationId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type fundDonationsAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type fundDonationsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    donationId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type fundDonationsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    donationId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type fundDonationsSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type fundsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    productId?: SortOrder
    removed?: SortOrder
  }

  export type fundsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    productId?: SortOrder
    removed?: SortOrder
  }

  export type fundsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    productId?: SortOrder
    removed?: SortOrder
  }

  export type gatewaysCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    provider?: SortOrder
    publicKey?: SortOrder
    privateKey?: SortOrder
    webhookKey?: SortOrder
    productId?: SortOrder
  }

  export type gatewaysMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    provider?: SortOrder
    publicKey?: SortOrder
    privateKey?: SortOrder
    webhookKey?: SortOrder
    productId?: SortOrder
  }

  export type gatewaysMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    provider?: SortOrder
    publicKey?: SortOrder
    privateKey?: SortOrder
    webhookKey?: SortOrder
    productId?: SortOrder
  }

  export type subscriptionFundsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    subscriptionId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type subscriptionFundsAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type subscriptionFundsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    subscriptionId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type subscriptionFundsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    subscriptionId?: SortOrder
    fundId?: SortOrder
    amount?: SortOrder
  }

  export type subscriptionFundsSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type subscriptionsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    customerId?: SortOrder
  }

  export type subscriptionsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    customerId?: SortOrder
  }

  export type subscriptionsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    customerId?: SortOrder
  }

  export type campusesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    removed?: SortOrder
  }

  export type campusesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    removed?: SortOrder
  }

  export type campusesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    name?: SortOrder
    address1?: SortOrder
    address2?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip?: SortOrder
    removed?: SortOrder
  }

  export type groupServiceTimesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
  }

  export type groupServiceTimesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
  }

  export type groupServiceTimesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
  }

  export type serviceTimesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    serviceId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type serviceTimesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    serviceId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type serviceTimesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    serviceId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type servicesCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    campusId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type servicesMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    campusId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type servicesMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    campusId?: SortOrder
    name?: SortOrder
    removed?: SortOrder
  }

  export type VisitSessionsListRelationFilter = {
    every?: visitSessionsWhereInput
    some?: visitSessionsWhereInput
    none?: visitSessionsWhereInput
  }

  export type visitSessionsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type sessionsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    sessionDate?: SortOrder
  }

  export type sessionsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    sessionDate?: SortOrder
  }

  export type sessionsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    groupId?: SortOrder
    serviceTimeId?: SortOrder
    sessionDate?: SortOrder
  }

  export type VisitsRelationFilter = {
    is?: visitsWhereInput | null
    isNot?: visitsWhereInput | null
  }

  export type SessionsRelationFilter = {
    is?: sessionsWhereInput | null
    isNot?: sessionsWhereInput | null
  }

  export type visitSessionsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    visitId?: SortOrder
    sessionId?: SortOrder
  }

  export type visitSessionsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    visitId?: SortOrder
    sessionId?: SortOrder
  }

  export type visitSessionsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    visitId?: SortOrder
    sessionId?: SortOrder
  }

  export type visitsCountOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    serviceId?: SortOrder
    groupId?: SortOrder
    visitDate?: SortOrder
    checkinTime?: SortOrder
    addedBy?: SortOrder
  }

  export type visitsMaxOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    serviceId?: SortOrder
    groupId?: SortOrder
    visitDate?: SortOrder
    checkinTime?: SortOrder
    addedBy?: SortOrder
  }

  export type visitsMinOrderByAggregateInput = {
    id?: SortOrder
    churchId?: SortOrder
    personId?: SortOrder
    serviceId?: SortOrder
    groupId?: SortOrder
    visitDate?: SortOrder
    checkinTime?: SortOrder
    addedBy?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type groupsCreateNestedOneWithoutUsersInput = {
    create?: XOR<groupsCreateWithoutUsersInput, groupsUncheckedCreateWithoutUsersInput>
    connectOrCreate?: groupsCreateOrConnectWithoutUsersInput
    connect?: groupsWhereUniqueInput
  }

  export type peopleCreateNestedOneWithoutGroupsInput = {
    create?: XOR<peopleCreateWithoutGroupsInput, peopleUncheckedCreateWithoutGroupsInput>
    connectOrCreate?: peopleCreateOrConnectWithoutGroupsInput
    connect?: peopleWhereUniqueInput
  }

  export type groupsUpdateOneWithoutUsersInput = {
    create?: XOR<groupsCreateWithoutUsersInput, groupsUncheckedCreateWithoutUsersInput>
    connectOrCreate?: groupsCreateOrConnectWithoutUsersInput
    upsert?: groupsUpsertWithoutUsersInput
    disconnect?: boolean
    delete?: boolean
    connect?: groupsWhereUniqueInput
    update?: XOR<groupsUpdateWithoutUsersInput, groupsUncheckedUpdateWithoutUsersInput>
  }

  export type peopleUpdateOneWithoutGroupsInput = {
    create?: XOR<peopleCreateWithoutGroupsInput, peopleUncheckedCreateWithoutGroupsInput>
    connectOrCreate?: peopleCreateOrConnectWithoutGroupsInput
    upsert?: peopleUpsertWithoutGroupsInput
    disconnect?: boolean
    delete?: boolean
    connect?: peopleWhereUniqueInput
    update?: XOR<peopleUpdateWithoutGroupsInput, peopleUncheckedUpdateWithoutGroupsInput>
  }

  export type groupMembersCreateNestedManyWithoutGroupInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutGroupInput>, Enumerable<groupMembersUncheckedCreateWithoutGroupInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutGroupInput>
    createMany?: groupMembersCreateManyGroupInputEnvelope
    connect?: Enumerable<groupMembersWhereUniqueInput>
  }

  export type groupMembersUncheckedCreateNestedManyWithoutGroupInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutGroupInput>, Enumerable<groupMembersUncheckedCreateWithoutGroupInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutGroupInput>
    createMany?: groupMembersCreateManyGroupInputEnvelope
    connect?: Enumerable<groupMembersWhereUniqueInput>
  }

  export type groupMembersUpdateManyWithoutGroupInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutGroupInput>, Enumerable<groupMembersUncheckedCreateWithoutGroupInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutGroupInput>
    upsert?: Enumerable<groupMembersUpsertWithWhereUniqueWithoutGroupInput>
    createMany?: groupMembersCreateManyGroupInputEnvelope
    set?: Enumerable<groupMembersWhereUniqueInput>
    disconnect?: Enumerable<groupMembersWhereUniqueInput>
    delete?: Enumerable<groupMembersWhereUniqueInput>
    connect?: Enumerable<groupMembersWhereUniqueInput>
    update?: Enumerable<groupMembersUpdateWithWhereUniqueWithoutGroupInput>
    updateMany?: Enumerable<groupMembersUpdateManyWithWhereWithoutGroupInput>
    deleteMany?: Enumerable<groupMembersScalarWhereInput>
  }

  export type groupMembersUncheckedUpdateManyWithoutGroupInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutGroupInput>, Enumerable<groupMembersUncheckedCreateWithoutGroupInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutGroupInput>
    upsert?: Enumerable<groupMembersUpsertWithWhereUniqueWithoutGroupInput>
    createMany?: groupMembersCreateManyGroupInputEnvelope
    set?: Enumerable<groupMembersWhereUniqueInput>
    disconnect?: Enumerable<groupMembersWhereUniqueInput>
    delete?: Enumerable<groupMembersWhereUniqueInput>
    connect?: Enumerable<groupMembersWhereUniqueInput>
    update?: Enumerable<groupMembersUpdateWithWhereUniqueWithoutGroupInput>
    updateMany?: Enumerable<groupMembersUpdateManyWithWhereWithoutGroupInput>
    deleteMany?: Enumerable<groupMembersScalarWhereInput>
  }

  export type peopleCreateNestedManyWithoutHouseholdInput = {
    create?: XOR<Enumerable<peopleCreateWithoutHouseholdInput>, Enumerable<peopleUncheckedCreateWithoutHouseholdInput>>
    connectOrCreate?: Enumerable<peopleCreateOrConnectWithoutHouseholdInput>
    createMany?: peopleCreateManyHouseholdInputEnvelope
    connect?: Enumerable<peopleWhereUniqueInput>
  }

  export type peopleUncheckedCreateNestedManyWithoutHouseholdInput = {
    create?: XOR<Enumerable<peopleCreateWithoutHouseholdInput>, Enumerable<peopleUncheckedCreateWithoutHouseholdInput>>
    connectOrCreate?: Enumerable<peopleCreateOrConnectWithoutHouseholdInput>
    createMany?: peopleCreateManyHouseholdInputEnvelope
    connect?: Enumerable<peopleWhereUniqueInput>
  }

  export type peopleUpdateManyWithoutHouseholdInput = {
    create?: XOR<Enumerable<peopleCreateWithoutHouseholdInput>, Enumerable<peopleUncheckedCreateWithoutHouseholdInput>>
    connectOrCreate?: Enumerable<peopleCreateOrConnectWithoutHouseholdInput>
    upsert?: Enumerable<peopleUpsertWithWhereUniqueWithoutHouseholdInput>
    createMany?: peopleCreateManyHouseholdInputEnvelope
    set?: Enumerable<peopleWhereUniqueInput>
    disconnect?: Enumerable<peopleWhereUniqueInput>
    delete?: Enumerable<peopleWhereUniqueInput>
    connect?: Enumerable<peopleWhereUniqueInput>
    update?: Enumerable<peopleUpdateWithWhereUniqueWithoutHouseholdInput>
    updateMany?: Enumerable<peopleUpdateManyWithWhereWithoutHouseholdInput>
    deleteMany?: Enumerable<peopleScalarWhereInput>
  }

  export type peopleUncheckedUpdateManyWithoutHouseholdInput = {
    create?: XOR<Enumerable<peopleCreateWithoutHouseholdInput>, Enumerable<peopleUncheckedCreateWithoutHouseholdInput>>
    connectOrCreate?: Enumerable<peopleCreateOrConnectWithoutHouseholdInput>
    upsert?: Enumerable<peopleUpsertWithWhereUniqueWithoutHouseholdInput>
    createMany?: peopleCreateManyHouseholdInputEnvelope
    set?: Enumerable<peopleWhereUniqueInput>
    disconnect?: Enumerable<peopleWhereUniqueInput>
    delete?: Enumerable<peopleWhereUniqueInput>
    connect?: Enumerable<peopleWhereUniqueInput>
    update?: Enumerable<peopleUpdateWithWhereUniqueWithoutHouseholdInput>
    updateMany?: Enumerable<peopleUpdateManyWithWhereWithoutHouseholdInput>
    deleteMany?: Enumerable<peopleScalarWhereInput>
  }

  export type groupMembersCreateNestedManyWithoutPersonInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutPersonInput>, Enumerable<groupMembersUncheckedCreateWithoutPersonInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutPersonInput>
    createMany?: groupMembersCreateManyPersonInputEnvelope
    connect?: Enumerable<groupMembersWhereUniqueInput>
  }

  export type householdsCreateNestedOneWithoutPeopleInput = {
    create?: XOR<householdsCreateWithoutPeopleInput, householdsUncheckedCreateWithoutPeopleInput>
    connectOrCreate?: householdsCreateOrConnectWithoutPeopleInput
    connect?: householdsWhereUniqueInput
  }

  export type groupMembersUncheckedCreateNestedManyWithoutPersonInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutPersonInput>, Enumerable<groupMembersUncheckedCreateWithoutPersonInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutPersonInput>
    createMany?: groupMembersCreateManyPersonInputEnvelope
    connect?: Enumerable<groupMembersWhereUniqueInput>
  }

  export type groupMembersUpdateManyWithoutPersonInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutPersonInput>, Enumerable<groupMembersUncheckedCreateWithoutPersonInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutPersonInput>
    upsert?: Enumerable<groupMembersUpsertWithWhereUniqueWithoutPersonInput>
    createMany?: groupMembersCreateManyPersonInputEnvelope
    set?: Enumerable<groupMembersWhereUniqueInput>
    disconnect?: Enumerable<groupMembersWhereUniqueInput>
    delete?: Enumerable<groupMembersWhereUniqueInput>
    connect?: Enumerable<groupMembersWhereUniqueInput>
    update?: Enumerable<groupMembersUpdateWithWhereUniqueWithoutPersonInput>
    updateMany?: Enumerable<groupMembersUpdateManyWithWhereWithoutPersonInput>
    deleteMany?: Enumerable<groupMembersScalarWhereInput>
  }

  export type householdsUpdateOneWithoutPeopleInput = {
    create?: XOR<householdsCreateWithoutPeopleInput, householdsUncheckedCreateWithoutPeopleInput>
    connectOrCreate?: householdsCreateOrConnectWithoutPeopleInput
    upsert?: householdsUpsertWithoutPeopleInput
    disconnect?: boolean
    delete?: boolean
    connect?: householdsWhereUniqueInput
    update?: XOR<householdsUpdateWithoutPeopleInput, householdsUncheckedUpdateWithoutPeopleInput>
  }

  export type groupMembersUncheckedUpdateManyWithoutPersonInput = {
    create?: XOR<Enumerable<groupMembersCreateWithoutPersonInput>, Enumerable<groupMembersUncheckedCreateWithoutPersonInput>>
    connectOrCreate?: Enumerable<groupMembersCreateOrConnectWithoutPersonInput>
    upsert?: Enumerable<groupMembersUpsertWithWhereUniqueWithoutPersonInput>
    createMany?: groupMembersCreateManyPersonInputEnvelope
    set?: Enumerable<groupMembersWhereUniqueInput>
    disconnect?: Enumerable<groupMembersWhereUniqueInput>
    delete?: Enumerable<groupMembersWhereUniqueInput>
    connect?: Enumerable<groupMembersWhereUniqueInput>
    update?: Enumerable<groupMembersUpdateWithWhereUniqueWithoutPersonInput>
    updateMany?: Enumerable<groupMembersUpdateManyWithWhereWithoutPersonInput>
    deleteMany?: Enumerable<groupMembersScalarWhereInput>
  }

  export type donationsCreateNestedManyWithoutDonationBatchesInput = {
    create?: XOR<Enumerable<donationsCreateWithoutDonationBatchesInput>, Enumerable<donationsUncheckedCreateWithoutDonationBatchesInput>>
    connectOrCreate?: Enumerable<donationsCreateOrConnectWithoutDonationBatchesInput>
    createMany?: donationsCreateManyDonationBatchesInputEnvelope
    connect?: Enumerable<donationsWhereUniqueInput>
  }

  export type donationsUncheckedCreateNestedManyWithoutDonationBatchesInput = {
    create?: XOR<Enumerable<donationsCreateWithoutDonationBatchesInput>, Enumerable<donationsUncheckedCreateWithoutDonationBatchesInput>>
    connectOrCreate?: Enumerable<donationsCreateOrConnectWithoutDonationBatchesInput>
    createMany?: donationsCreateManyDonationBatchesInputEnvelope
    connect?: Enumerable<donationsWhereUniqueInput>
  }

  export type donationsUpdateManyWithoutDonationBatchesInput = {
    create?: XOR<Enumerable<donationsCreateWithoutDonationBatchesInput>, Enumerable<donationsUncheckedCreateWithoutDonationBatchesInput>>
    connectOrCreate?: Enumerable<donationsCreateOrConnectWithoutDonationBatchesInput>
    upsert?: Enumerable<donationsUpsertWithWhereUniqueWithoutDonationBatchesInput>
    createMany?: donationsCreateManyDonationBatchesInputEnvelope
    set?: Enumerable<donationsWhereUniqueInput>
    disconnect?: Enumerable<donationsWhereUniqueInput>
    delete?: Enumerable<donationsWhereUniqueInput>
    connect?: Enumerable<donationsWhereUniqueInput>
    update?: Enumerable<donationsUpdateWithWhereUniqueWithoutDonationBatchesInput>
    updateMany?: Enumerable<donationsUpdateManyWithWhereWithoutDonationBatchesInput>
    deleteMany?: Enumerable<donationsScalarWhereInput>
  }

  export type donationsUncheckedUpdateManyWithoutDonationBatchesInput = {
    create?: XOR<Enumerable<donationsCreateWithoutDonationBatchesInput>, Enumerable<donationsUncheckedCreateWithoutDonationBatchesInput>>
    connectOrCreate?: Enumerable<donationsCreateOrConnectWithoutDonationBatchesInput>
    upsert?: Enumerable<donationsUpsertWithWhereUniqueWithoutDonationBatchesInput>
    createMany?: donationsCreateManyDonationBatchesInputEnvelope
    set?: Enumerable<donationsWhereUniqueInput>
    disconnect?: Enumerable<donationsWhereUniqueInput>
    delete?: Enumerable<donationsWhereUniqueInput>
    connect?: Enumerable<donationsWhereUniqueInput>
    update?: Enumerable<donationsUpdateWithWhereUniqueWithoutDonationBatchesInput>
    updateMany?: Enumerable<donationsUpdateManyWithWhereWithoutDonationBatchesInput>
    deleteMany?: Enumerable<donationsScalarWhereInput>
  }

  export type donationBatchesCreateNestedOneWithoutDonationsInput = {
    create?: XOR<donationBatchesCreateWithoutDonationsInput, donationBatchesUncheckedCreateWithoutDonationsInput>
    connectOrCreate?: donationBatchesCreateOrConnectWithoutDonationsInput
    connect?: donationBatchesWhereUniqueInput
  }

  export type fundDonationsCreateNestedManyWithoutDonationInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutDonationInput>, Enumerable<fundDonationsUncheckedCreateWithoutDonationInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutDonationInput>
    createMany?: fundDonationsCreateManyDonationInputEnvelope
    connect?: Enumerable<fundDonationsWhereUniqueInput>
  }

  export type fundDonationsUncheckedCreateNestedManyWithoutDonationInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutDonationInput>, Enumerable<fundDonationsUncheckedCreateWithoutDonationInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutDonationInput>
    createMany?: fundDonationsCreateManyDonationInputEnvelope
    connect?: Enumerable<fundDonationsWhereUniqueInput>
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type donationBatchesUpdateOneWithoutDonationsInput = {
    create?: XOR<donationBatchesCreateWithoutDonationsInput, donationBatchesUncheckedCreateWithoutDonationsInput>
    connectOrCreate?: donationBatchesCreateOrConnectWithoutDonationsInput
    upsert?: donationBatchesUpsertWithoutDonationsInput
    disconnect?: boolean
    delete?: boolean
    connect?: donationBatchesWhereUniqueInput
    update?: XOR<donationBatchesUpdateWithoutDonationsInput, donationBatchesUncheckedUpdateWithoutDonationsInput>
  }

  export type fundDonationsUpdateManyWithoutDonationInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutDonationInput>, Enumerable<fundDonationsUncheckedCreateWithoutDonationInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutDonationInput>
    upsert?: Enumerable<fundDonationsUpsertWithWhereUniqueWithoutDonationInput>
    createMany?: fundDonationsCreateManyDonationInputEnvelope
    set?: Enumerable<fundDonationsWhereUniqueInput>
    disconnect?: Enumerable<fundDonationsWhereUniqueInput>
    delete?: Enumerable<fundDonationsWhereUniqueInput>
    connect?: Enumerable<fundDonationsWhereUniqueInput>
    update?: Enumerable<fundDonationsUpdateWithWhereUniqueWithoutDonationInput>
    updateMany?: Enumerable<fundDonationsUpdateManyWithWhereWithoutDonationInput>
    deleteMany?: Enumerable<fundDonationsScalarWhereInput>
  }

  export type fundDonationsUncheckedUpdateManyWithoutDonationInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutDonationInput>, Enumerable<fundDonationsUncheckedCreateWithoutDonationInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutDonationInput>
    upsert?: Enumerable<fundDonationsUpsertWithWhereUniqueWithoutDonationInput>
    createMany?: fundDonationsCreateManyDonationInputEnvelope
    set?: Enumerable<fundDonationsWhereUniqueInput>
    disconnect?: Enumerable<fundDonationsWhereUniqueInput>
    delete?: Enumerable<fundDonationsWhereUniqueInput>
    connect?: Enumerable<fundDonationsWhereUniqueInput>
    update?: Enumerable<fundDonationsUpdateWithWhereUniqueWithoutDonationInput>
    updateMany?: Enumerable<fundDonationsUpdateManyWithWhereWithoutDonationInput>
    deleteMany?: Enumerable<fundDonationsScalarWhereInput>
  }

  export type fundsCreateNestedOneWithoutFundDonationsInput = {
    create?: XOR<fundsCreateWithoutFundDonationsInput, fundsUncheckedCreateWithoutFundDonationsInput>
    connectOrCreate?: fundsCreateOrConnectWithoutFundDonationsInput
    connect?: fundsWhereUniqueInput
  }

  export type donationsCreateNestedOneWithoutFundDonationsInput = {
    create?: XOR<donationsCreateWithoutFundDonationsInput, donationsUncheckedCreateWithoutFundDonationsInput>
    connectOrCreate?: donationsCreateOrConnectWithoutFundDonationsInput
    connect?: donationsWhereUniqueInput
  }

  export type fundsUpdateOneWithoutFundDonationsInput = {
    create?: XOR<fundsCreateWithoutFundDonationsInput, fundsUncheckedCreateWithoutFundDonationsInput>
    connectOrCreate?: fundsCreateOrConnectWithoutFundDonationsInput
    upsert?: fundsUpsertWithoutFundDonationsInput
    disconnect?: boolean
    delete?: boolean
    connect?: fundsWhereUniqueInput
    update?: XOR<fundsUpdateWithoutFundDonationsInput, fundsUncheckedUpdateWithoutFundDonationsInput>
  }

  export type donationsUpdateOneWithoutFundDonationsInput = {
    create?: XOR<donationsCreateWithoutFundDonationsInput, donationsUncheckedCreateWithoutFundDonationsInput>
    connectOrCreate?: donationsCreateOrConnectWithoutFundDonationsInput
    upsert?: donationsUpsertWithoutFundDonationsInput
    disconnect?: boolean
    delete?: boolean
    connect?: donationsWhereUniqueInput
    update?: XOR<donationsUpdateWithoutFundDonationsInput, donationsUncheckedUpdateWithoutFundDonationsInput>
  }

  export type fundDonationsCreateNestedManyWithoutFundInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutFundInput>, Enumerable<fundDonationsUncheckedCreateWithoutFundInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutFundInput>
    createMany?: fundDonationsCreateManyFundInputEnvelope
    connect?: Enumerable<fundDonationsWhereUniqueInput>
  }

  export type fundDonationsUncheckedCreateNestedManyWithoutFundInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutFundInput>, Enumerable<fundDonationsUncheckedCreateWithoutFundInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutFundInput>
    createMany?: fundDonationsCreateManyFundInputEnvelope
    connect?: Enumerable<fundDonationsWhereUniqueInput>
  }

  export type fundDonationsUpdateManyWithoutFundInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutFundInput>, Enumerable<fundDonationsUncheckedCreateWithoutFundInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutFundInput>
    upsert?: Enumerable<fundDonationsUpsertWithWhereUniqueWithoutFundInput>
    createMany?: fundDonationsCreateManyFundInputEnvelope
    set?: Enumerable<fundDonationsWhereUniqueInput>
    disconnect?: Enumerable<fundDonationsWhereUniqueInput>
    delete?: Enumerable<fundDonationsWhereUniqueInput>
    connect?: Enumerable<fundDonationsWhereUniqueInput>
    update?: Enumerable<fundDonationsUpdateWithWhereUniqueWithoutFundInput>
    updateMany?: Enumerable<fundDonationsUpdateManyWithWhereWithoutFundInput>
    deleteMany?: Enumerable<fundDonationsScalarWhereInput>
  }

  export type fundDonationsUncheckedUpdateManyWithoutFundInput = {
    create?: XOR<Enumerable<fundDonationsCreateWithoutFundInput>, Enumerable<fundDonationsUncheckedCreateWithoutFundInput>>
    connectOrCreate?: Enumerable<fundDonationsCreateOrConnectWithoutFundInput>
    upsert?: Enumerable<fundDonationsUpsertWithWhereUniqueWithoutFundInput>
    createMany?: fundDonationsCreateManyFundInputEnvelope
    set?: Enumerable<fundDonationsWhereUniqueInput>
    disconnect?: Enumerable<fundDonationsWhereUniqueInput>
    delete?: Enumerable<fundDonationsWhereUniqueInput>
    connect?: Enumerable<fundDonationsWhereUniqueInput>
    update?: Enumerable<fundDonationsUpdateWithWhereUniqueWithoutFundInput>
    updateMany?: Enumerable<fundDonationsUpdateManyWithWhereWithoutFundInput>
    deleteMany?: Enumerable<fundDonationsScalarWhereInput>
  }

  export type visitSessionsCreateNestedManyWithoutSessionInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutSessionInput>, Enumerable<visitSessionsUncheckedCreateWithoutSessionInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutSessionInput>
    createMany?: visitSessionsCreateManySessionInputEnvelope
    connect?: Enumerable<visitSessionsWhereUniqueInput>
  }

  export type visitSessionsUncheckedCreateNestedManyWithoutSessionInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutSessionInput>, Enumerable<visitSessionsUncheckedCreateWithoutSessionInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutSessionInput>
    createMany?: visitSessionsCreateManySessionInputEnvelope
    connect?: Enumerable<visitSessionsWhereUniqueInput>
  }

  export type visitSessionsUpdateManyWithoutSessionInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutSessionInput>, Enumerable<visitSessionsUncheckedCreateWithoutSessionInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutSessionInput>
    upsert?: Enumerable<visitSessionsUpsertWithWhereUniqueWithoutSessionInput>
    createMany?: visitSessionsCreateManySessionInputEnvelope
    set?: Enumerable<visitSessionsWhereUniqueInput>
    disconnect?: Enumerable<visitSessionsWhereUniqueInput>
    delete?: Enumerable<visitSessionsWhereUniqueInput>
    connect?: Enumerable<visitSessionsWhereUniqueInput>
    update?: Enumerable<visitSessionsUpdateWithWhereUniqueWithoutSessionInput>
    updateMany?: Enumerable<visitSessionsUpdateManyWithWhereWithoutSessionInput>
    deleteMany?: Enumerable<visitSessionsScalarWhereInput>
  }

  export type visitSessionsUncheckedUpdateManyWithoutSessionInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutSessionInput>, Enumerable<visitSessionsUncheckedCreateWithoutSessionInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutSessionInput>
    upsert?: Enumerable<visitSessionsUpsertWithWhereUniqueWithoutSessionInput>
    createMany?: visitSessionsCreateManySessionInputEnvelope
    set?: Enumerable<visitSessionsWhereUniqueInput>
    disconnect?: Enumerable<visitSessionsWhereUniqueInput>
    delete?: Enumerable<visitSessionsWhereUniqueInput>
    connect?: Enumerable<visitSessionsWhereUniqueInput>
    update?: Enumerable<visitSessionsUpdateWithWhereUniqueWithoutSessionInput>
    updateMany?: Enumerable<visitSessionsUpdateManyWithWhereWithoutSessionInput>
    deleteMany?: Enumerable<visitSessionsScalarWhereInput>
  }

  export type visitsCreateNestedOneWithoutSessionInput = {
    create?: XOR<visitsCreateWithoutSessionInput, visitsUncheckedCreateWithoutSessionInput>
    connectOrCreate?: visitsCreateOrConnectWithoutSessionInput
    connect?: visitsWhereUniqueInput
  }

  export type sessionsCreateNestedOneWithoutVisitsInput = {
    create?: XOR<sessionsCreateWithoutVisitsInput, sessionsUncheckedCreateWithoutVisitsInput>
    connectOrCreate?: sessionsCreateOrConnectWithoutVisitsInput
    connect?: sessionsWhereUniqueInput
  }

  export type visitsUpdateOneWithoutSessionInput = {
    create?: XOR<visitsCreateWithoutSessionInput, visitsUncheckedCreateWithoutSessionInput>
    connectOrCreate?: visitsCreateOrConnectWithoutSessionInput
    upsert?: visitsUpsertWithoutSessionInput
    disconnect?: boolean
    delete?: boolean
    connect?: visitsWhereUniqueInput
    update?: XOR<visitsUpdateWithoutSessionInput, visitsUncheckedUpdateWithoutSessionInput>
  }

  export type sessionsUpdateOneWithoutVisitsInput = {
    create?: XOR<sessionsCreateWithoutVisitsInput, sessionsUncheckedCreateWithoutVisitsInput>
    connectOrCreate?: sessionsCreateOrConnectWithoutVisitsInput
    upsert?: sessionsUpsertWithoutVisitsInput
    disconnect?: boolean
    delete?: boolean
    connect?: sessionsWhereUniqueInput
    update?: XOR<sessionsUpdateWithoutVisitsInput, sessionsUncheckedUpdateWithoutVisitsInput>
  }

  export type visitSessionsCreateNestedManyWithoutVisitInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutVisitInput>, Enumerable<visitSessionsUncheckedCreateWithoutVisitInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutVisitInput>
    createMany?: visitSessionsCreateManyVisitInputEnvelope
    connect?: Enumerable<visitSessionsWhereUniqueInput>
  }

  export type visitSessionsUncheckedCreateNestedManyWithoutVisitInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutVisitInput>, Enumerable<visitSessionsUncheckedCreateWithoutVisitInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutVisitInput>
    createMany?: visitSessionsCreateManyVisitInputEnvelope
    connect?: Enumerable<visitSessionsWhereUniqueInput>
  }

  export type visitSessionsUpdateManyWithoutVisitInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutVisitInput>, Enumerable<visitSessionsUncheckedCreateWithoutVisitInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutVisitInput>
    upsert?: Enumerable<visitSessionsUpsertWithWhereUniqueWithoutVisitInput>
    createMany?: visitSessionsCreateManyVisitInputEnvelope
    set?: Enumerable<visitSessionsWhereUniqueInput>
    disconnect?: Enumerable<visitSessionsWhereUniqueInput>
    delete?: Enumerable<visitSessionsWhereUniqueInput>
    connect?: Enumerable<visitSessionsWhereUniqueInput>
    update?: Enumerable<visitSessionsUpdateWithWhereUniqueWithoutVisitInput>
    updateMany?: Enumerable<visitSessionsUpdateManyWithWhereWithoutVisitInput>
    deleteMany?: Enumerable<visitSessionsScalarWhereInput>
  }

  export type visitSessionsUncheckedUpdateManyWithoutVisitInput = {
    create?: XOR<Enumerable<visitSessionsCreateWithoutVisitInput>, Enumerable<visitSessionsUncheckedCreateWithoutVisitInput>>
    connectOrCreate?: Enumerable<visitSessionsCreateOrConnectWithoutVisitInput>
    upsert?: Enumerable<visitSessionsUpsertWithWhereUniqueWithoutVisitInput>
    createMany?: visitSessionsCreateManyVisitInputEnvelope
    set?: Enumerable<visitSessionsWhereUniqueInput>
    disconnect?: Enumerable<visitSessionsWhereUniqueInput>
    delete?: Enumerable<visitSessionsWhereUniqueInput>
    connect?: Enumerable<visitSessionsWhereUniqueInput>
    update?: Enumerable<visitSessionsUpdateWithWhereUniqueWithoutVisitInput>
    updateMany?: Enumerable<visitSessionsUpdateManyWithWhereWithoutVisitInput>
    deleteMany?: Enumerable<visitSessionsScalarWhereInput>
  }

  export type NestedStringFilter = {
    equals?: string
    in?: Enumerable<string>
    notIn?: Enumerable<string>
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringFilter | string
  }

  export type NestedStringNullableFilter = {
    equals?: string | null
    in?: Enumerable<string> | null
    notIn?: Enumerable<string> | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableFilter | string | null
  }

  export type NestedStringWithAggregatesFilter = {
    equals?: string
    in?: Enumerable<string>
    notIn?: Enumerable<string>
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringWithAggregatesFilter | string
    _count?: NestedIntFilter
    _min?: NestedStringFilter
    _max?: NestedStringFilter
  }

  export type NestedIntFilter = {
    equals?: number
    in?: Enumerable<number>
    notIn?: Enumerable<number>
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntFilter | number
  }

  export type NestedStringNullableWithAggregatesFilter = {
    equals?: string | null
    in?: Enumerable<string> | null
    notIn?: Enumerable<string> | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableWithAggregatesFilter | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedStringNullableFilter
    _max?: NestedStringNullableFilter
  }

  export type NestedIntNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | null
    notIn?: Enumerable<number> | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntNullableFilter | number | null
  }

  export type NestedDateTimeNullableFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | null
    notIn?: Enumerable<Date> | Enumerable<string> | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableFilter | Date | string | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | null
    notIn?: Enumerable<Date> | Enumerable<string> | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableWithAggregatesFilter | Date | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedDateTimeNullableFilter
    _max?: NestedDateTimeNullableFilter
  }

  export type NestedBoolNullableFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableFilter | boolean | null
  }

  export type NestedBoolNullableWithAggregatesFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableWithAggregatesFilter | boolean | null
    _count?: NestedIntNullableFilter
    _min?: NestedBoolNullableFilter
    _max?: NestedBoolNullableFilter
  }

  export type NestedFloatNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | null
    notIn?: Enumerable<number> | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatNullableFilter | number | null
  }

  export type NestedFloatNullableWithAggregatesFilter = {
    equals?: number | null
    in?: Enumerable<number> | null
    notIn?: Enumerable<number> | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatNullableWithAggregatesFilter | number | null
    _count?: NestedIntNullableFilter
    _avg?: NestedFloatNullableFilter
    _sum?: NestedFloatNullableFilter
    _min?: NestedFloatNullableFilter
    _max?: NestedFloatNullableFilter
  }

  export type groupsCreateWithoutUsersInput = {
    id: string
    churchId?: string | null
    categoryName?: string | null
    name?: string | null
    trackAttendance?: boolean | null
    parentPickup?: boolean | null
    removed?: boolean | null
  }

  export type groupsUncheckedCreateWithoutUsersInput = {
    id: string
    churchId?: string | null
    categoryName?: string | null
    name?: string | null
    trackAttendance?: boolean | null
    parentPickup?: boolean | null
    removed?: boolean | null
  }

  export type groupsCreateOrConnectWithoutUsersInput = {
    where: groupsWhereUniqueInput
    create: XOR<groupsCreateWithoutUsersInput, groupsUncheckedCreateWithoutUsersInput>
  }

  export type peopleCreateWithoutGroupsInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdRole?: string | null
    removed?: boolean | null
    household?: householdsCreateNestedOneWithoutPeopleInput
  }

  export type peopleUncheckedCreateWithoutGroupsInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdId?: string | null
    householdRole?: string | null
    removed?: boolean | null
  }

  export type peopleCreateOrConnectWithoutGroupsInput = {
    where: peopleWhereUniqueInput
    create: XOR<peopleCreateWithoutGroupsInput, peopleUncheckedCreateWithoutGroupsInput>
  }

  export type groupsUpsertWithoutUsersInput = {
    update: XOR<groupsUpdateWithoutUsersInput, groupsUncheckedUpdateWithoutUsersInput>
    create: XOR<groupsCreateWithoutUsersInput, groupsUncheckedCreateWithoutUsersInput>
  }

  export type groupsUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupsUncheckedUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    categoryName?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trackAttendance?: NullableBoolFieldUpdateOperationsInput | boolean | null
    parentPickup?: NullableBoolFieldUpdateOperationsInput | boolean | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type peopleUpsertWithoutGroupsInput = {
    update: XOR<peopleUpdateWithoutGroupsInput, peopleUncheckedUpdateWithoutGroupsInput>
    create: XOR<peopleCreateWithoutGroupsInput, peopleUncheckedCreateWithoutGroupsInput>
  }

  export type peopleUpdateWithoutGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    household?: householdsUpdateOneWithoutPeopleInput
  }

  export type peopleUncheckedUpdateWithoutGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdId?: NullableStringFieldUpdateOperationsInput | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupMembersCreateWithoutGroupInput = {
    id: string
    churchId?: string | null
    joinDate?: Date | string | null
    person?: peopleCreateNestedOneWithoutGroupsInput
  }

  export type groupMembersUncheckedCreateWithoutGroupInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersCreateOrConnectWithoutGroupInput = {
    where: groupMembersWhereUniqueInput
    create: XOR<groupMembersCreateWithoutGroupInput, groupMembersUncheckedCreateWithoutGroupInput>
  }

  export type groupMembersCreateManyGroupInputEnvelope = {
    data: Enumerable<groupMembersCreateManyGroupInput>
    skipDuplicates?: boolean
  }

  export type groupMembersUpsertWithWhereUniqueWithoutGroupInput = {
    where: groupMembersWhereUniqueInput
    update: XOR<groupMembersUpdateWithoutGroupInput, groupMembersUncheckedUpdateWithoutGroupInput>
    create: XOR<groupMembersCreateWithoutGroupInput, groupMembersUncheckedCreateWithoutGroupInput>
  }

  export type groupMembersUpdateWithWhereUniqueWithoutGroupInput = {
    where: groupMembersWhereUniqueInput
    data: XOR<groupMembersUpdateWithoutGroupInput, groupMembersUncheckedUpdateWithoutGroupInput>
  }

  export type groupMembersUpdateManyWithWhereWithoutGroupInput = {
    where: groupMembersScalarWhereInput
    data: XOR<groupMembersUpdateManyMutationInput, groupMembersUncheckedUpdateManyWithoutUsersInput>
  }

  export type groupMembersScalarWhereInput = {
    AND?: Enumerable<groupMembersScalarWhereInput>
    OR?: Enumerable<groupMembersScalarWhereInput>
    NOT?: Enumerable<groupMembersScalarWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    groupId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    joinDate?: DateTimeNullableFilter | Date | string | null
  }

  export type peopleCreateWithoutHouseholdInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdRole?: string | null
    removed?: boolean | null
    groups?: groupMembersCreateNestedManyWithoutPersonInput
  }

  export type peopleUncheckedCreateWithoutHouseholdInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdRole?: string | null
    removed?: boolean | null
    groups?: groupMembersUncheckedCreateNestedManyWithoutPersonInput
  }

  export type peopleCreateOrConnectWithoutHouseholdInput = {
    where: peopleWhereUniqueInput
    create: XOR<peopleCreateWithoutHouseholdInput, peopleUncheckedCreateWithoutHouseholdInput>
  }

  export type peopleCreateManyHouseholdInputEnvelope = {
    data: Enumerable<peopleCreateManyHouseholdInput>
    skipDuplicates?: boolean
  }

  export type peopleUpsertWithWhereUniqueWithoutHouseholdInput = {
    where: peopleWhereUniqueInput
    update: XOR<peopleUpdateWithoutHouseholdInput, peopleUncheckedUpdateWithoutHouseholdInput>
    create: XOR<peopleCreateWithoutHouseholdInput, peopleUncheckedCreateWithoutHouseholdInput>
  }

  export type peopleUpdateWithWhereUniqueWithoutHouseholdInput = {
    where: peopleWhereUniqueInput
    data: XOR<peopleUpdateWithoutHouseholdInput, peopleUncheckedUpdateWithoutHouseholdInput>
  }

  export type peopleUpdateManyWithWhereWithoutHouseholdInput = {
    where: peopleScalarWhereInput
    data: XOR<peopleUpdateManyMutationInput, peopleUncheckedUpdateManyWithoutPeopleInput>
  }

  export type peopleScalarWhereInput = {
    AND?: Enumerable<peopleScalarWhereInput>
    OR?: Enumerable<peopleScalarWhereInput>
    NOT?: Enumerable<peopleScalarWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    displayName?: StringNullableFilter | string | null
    firstName?: StringNullableFilter | string | null
    middleName?: StringNullableFilter | string | null
    lastName?: StringNullableFilter | string | null
    nickName?: StringNullableFilter | string | null
    prefix?: StringNullableFilter | string | null
    suffix?: StringNullableFilter | string | null
    birthDate?: DateTimeNullableFilter | Date | string | null
    gender?: StringNullableFilter | string | null
    maritalStatus?: StringNullableFilter | string | null
    anniversary?: DateTimeNullableFilter | Date | string | null
    membershipStatus?: StringNullableFilter | string | null
    homePhone?: StringNullableFilter | string | null
    mobilePhone?: StringNullableFilter | string | null
    workPhone?: StringNullableFilter | string | null
    email?: StringNullableFilter | string | null
    address1?: StringNullableFilter | string | null
    address2?: StringNullableFilter | string | null
    city?: StringNullableFilter | string | null
    state?: StringNullableFilter | string | null
    zip?: StringNullableFilter | string | null
    photoUpdated?: DateTimeNullableFilter | Date | string | null
    householdId?: StringNullableFilter | string | null
    householdRole?: StringNullableFilter | string | null
    removed?: BoolNullableFilter | boolean | null
  }

  export type groupMembersCreateWithoutPersonInput = {
    id: string
    churchId?: string | null
    joinDate?: Date | string | null
    group?: groupsCreateNestedOneWithoutUsersInput
  }

  export type groupMembersUncheckedCreateWithoutPersonInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersCreateOrConnectWithoutPersonInput = {
    where: groupMembersWhereUniqueInput
    create: XOR<groupMembersCreateWithoutPersonInput, groupMembersUncheckedCreateWithoutPersonInput>
  }

  export type groupMembersCreateManyPersonInputEnvelope = {
    data: Enumerable<groupMembersCreateManyPersonInput>
    skipDuplicates?: boolean
  }

  export type householdsCreateWithoutPeopleInput = {
    id: string
    churchId?: string | null
    name?: string | null
  }

  export type householdsUncheckedCreateWithoutPeopleInput = {
    id: string
    churchId?: string | null
    name?: string | null
  }

  export type householdsCreateOrConnectWithoutPeopleInput = {
    where: householdsWhereUniqueInput
    create: XOR<householdsCreateWithoutPeopleInput, householdsUncheckedCreateWithoutPeopleInput>
  }

  export type groupMembersUpsertWithWhereUniqueWithoutPersonInput = {
    where: groupMembersWhereUniqueInput
    update: XOR<groupMembersUpdateWithoutPersonInput, groupMembersUncheckedUpdateWithoutPersonInput>
    create: XOR<groupMembersCreateWithoutPersonInput, groupMembersUncheckedCreateWithoutPersonInput>
  }

  export type groupMembersUpdateWithWhereUniqueWithoutPersonInput = {
    where: groupMembersWhereUniqueInput
    data: XOR<groupMembersUpdateWithoutPersonInput, groupMembersUncheckedUpdateWithoutPersonInput>
  }

  export type groupMembersUpdateManyWithWhereWithoutPersonInput = {
    where: groupMembersScalarWhereInput
    data: XOR<groupMembersUpdateManyMutationInput, groupMembersUncheckedUpdateManyWithoutGroupsInput>
  }

  export type householdsUpsertWithoutPeopleInput = {
    update: XOR<householdsUpdateWithoutPeopleInput, householdsUncheckedUpdateWithoutPeopleInput>
    create: XOR<householdsCreateWithoutPeopleInput, householdsUncheckedCreateWithoutPeopleInput>
  }

  export type householdsUpdateWithoutPeopleInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type householdsUncheckedUpdateWithoutPeopleInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type donationsCreateWithoutDonationBatchesInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
    fundDonations?: fundDonationsCreateNestedManyWithoutDonationInput
  }

  export type donationsUncheckedCreateWithoutDonationBatchesInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
    fundDonations?: fundDonationsUncheckedCreateNestedManyWithoutDonationInput
  }

  export type donationsCreateOrConnectWithoutDonationBatchesInput = {
    where: donationsWhereUniqueInput
    create: XOR<donationsCreateWithoutDonationBatchesInput, donationsUncheckedCreateWithoutDonationBatchesInput>
  }

  export type donationsCreateManyDonationBatchesInputEnvelope = {
    data: Enumerable<donationsCreateManyDonationBatchesInput>
    skipDuplicates?: boolean
  }

  export type donationsUpsertWithWhereUniqueWithoutDonationBatchesInput = {
    where: donationsWhereUniqueInput
    update: XOR<donationsUpdateWithoutDonationBatchesInput, donationsUncheckedUpdateWithoutDonationBatchesInput>
    create: XOR<donationsCreateWithoutDonationBatchesInput, donationsUncheckedCreateWithoutDonationBatchesInput>
  }

  export type donationsUpdateWithWhereUniqueWithoutDonationBatchesInput = {
    where: donationsWhereUniqueInput
    data: XOR<donationsUpdateWithoutDonationBatchesInput, donationsUncheckedUpdateWithoutDonationBatchesInput>
  }

  export type donationsUpdateManyWithWhereWithoutDonationBatchesInput = {
    where: donationsScalarWhereInput
    data: XOR<donationsUpdateManyMutationInput, donationsUncheckedUpdateManyWithoutDonationsInput>
  }

  export type donationsScalarWhereInput = {
    AND?: Enumerable<donationsScalarWhereInput>
    OR?: Enumerable<donationsScalarWhereInput>
    NOT?: Enumerable<donationsScalarWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    batchId?: StringNullableFilter | string | null
    personId?: StringNullableFilter | string | null
    donationDate?: DateTimeNullableFilter | Date | string | null
    amount?: FloatNullableFilter | number | null
    method?: StringNullableFilter | string | null
    methodDetails?: StringNullableFilter | string | null
    notes?: StringNullableFilter | string | null
  }

  export type donationBatchesCreateWithoutDonationsInput = {
    id: string
    churchId?: string | null
    name?: string | null
    batchDate?: Date | string | null
  }

  export type donationBatchesUncheckedCreateWithoutDonationsInput = {
    id: string
    churchId?: string | null
    name?: string | null
    batchDate?: Date | string | null
  }

  export type donationBatchesCreateOrConnectWithoutDonationsInput = {
    where: donationBatchesWhereUniqueInput
    create: XOR<donationBatchesCreateWithoutDonationsInput, donationBatchesUncheckedCreateWithoutDonationsInput>
  }

  export type fundDonationsCreateWithoutDonationInput = {
    id: string
    churchId?: string | null
    amount?: number | null
    fund?: fundsCreateNestedOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedCreateWithoutDonationInput = {
    id: string
    churchId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type fundDonationsCreateOrConnectWithoutDonationInput = {
    where: fundDonationsWhereUniqueInput
    create: XOR<fundDonationsCreateWithoutDonationInput, fundDonationsUncheckedCreateWithoutDonationInput>
  }

  export type fundDonationsCreateManyDonationInputEnvelope = {
    data: Enumerable<fundDonationsCreateManyDonationInput>
    skipDuplicates?: boolean
  }

  export type donationBatchesUpsertWithoutDonationsInput = {
    update: XOR<donationBatchesUpdateWithoutDonationsInput, donationBatchesUncheckedUpdateWithoutDonationsInput>
    create: XOR<donationBatchesCreateWithoutDonationsInput, donationBatchesUncheckedCreateWithoutDonationsInput>
  }

  export type donationBatchesUpdateWithoutDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type donationBatchesUncheckedUpdateWithoutDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    batchDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type fundDonationsUpsertWithWhereUniqueWithoutDonationInput = {
    where: fundDonationsWhereUniqueInput
    update: XOR<fundDonationsUpdateWithoutDonationInput, fundDonationsUncheckedUpdateWithoutDonationInput>
    create: XOR<fundDonationsCreateWithoutDonationInput, fundDonationsUncheckedCreateWithoutDonationInput>
  }

  export type fundDonationsUpdateWithWhereUniqueWithoutDonationInput = {
    where: fundDonationsWhereUniqueInput
    data: XOR<fundDonationsUpdateWithoutDonationInput, fundDonationsUncheckedUpdateWithoutDonationInput>
  }

  export type fundDonationsUpdateManyWithWhereWithoutDonationInput = {
    where: fundDonationsScalarWhereInput
    data: XOR<fundDonationsUpdateManyMutationInput, fundDonationsUncheckedUpdateManyWithoutFundDonationsInput>
  }

  export type fundDonationsScalarWhereInput = {
    AND?: Enumerable<fundDonationsScalarWhereInput>
    OR?: Enumerable<fundDonationsScalarWhereInput>
    NOT?: Enumerable<fundDonationsScalarWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    donationId?: StringNullableFilter | string | null
    fundId?: StringNullableFilter | string | null
    amount?: FloatNullableFilter | number | null
  }

  export type fundsCreateWithoutFundDonationsInput = {
    id: string
    churchId?: string | null
    name?: string | null
    productId?: string | null
    removed?: boolean | null
  }

  export type fundsUncheckedCreateWithoutFundDonationsInput = {
    id: string
    churchId?: string | null
    name?: string | null
    productId?: string | null
    removed?: boolean | null
  }

  export type fundsCreateOrConnectWithoutFundDonationsInput = {
    where: fundsWhereUniqueInput
    create: XOR<fundsCreateWithoutFundDonationsInput, fundsUncheckedCreateWithoutFundDonationsInput>
  }

  export type donationsCreateWithoutFundDonationsInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
    donationBatches?: donationBatchesCreateNestedOneWithoutDonationsInput
  }

  export type donationsUncheckedCreateWithoutFundDonationsInput = {
    id: string
    churchId?: string | null
    batchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
  }

  export type donationsCreateOrConnectWithoutFundDonationsInput = {
    where: donationsWhereUniqueInput
    create: XOR<donationsCreateWithoutFundDonationsInput, donationsUncheckedCreateWithoutFundDonationsInput>
  }

  export type fundsUpsertWithoutFundDonationsInput = {
    update: XOR<fundsUpdateWithoutFundDonationsInput, fundsUncheckedUpdateWithoutFundDonationsInput>
    create: XOR<fundsCreateWithoutFundDonationsInput, fundsUncheckedCreateWithoutFundDonationsInput>
  }

  export type fundsUpdateWithoutFundDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type fundsUncheckedUpdateWithoutFundDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type donationsUpsertWithoutFundDonationsInput = {
    update: XOR<donationsUpdateWithoutFundDonationsInput, donationsUncheckedUpdateWithoutFundDonationsInput>
    create: XOR<donationsCreateWithoutFundDonationsInput, donationsUncheckedCreateWithoutFundDonationsInput>
  }

  export type donationsUpdateWithoutFundDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    donationBatches?: donationBatchesUpdateOneWithoutDonationsInput
  }

  export type donationsUncheckedUpdateWithoutFundDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    batchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type fundDonationsCreateWithoutFundInput = {
    id: string
    churchId?: string | null
    amount?: number | null
    donation?: donationsCreateNestedOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedCreateWithoutFundInput = {
    id: string
    churchId?: string | null
    donationId?: string | null
    amount?: number | null
  }

  export type fundDonationsCreateOrConnectWithoutFundInput = {
    where: fundDonationsWhereUniqueInput
    create: XOR<fundDonationsCreateWithoutFundInput, fundDonationsUncheckedCreateWithoutFundInput>
  }

  export type fundDonationsCreateManyFundInputEnvelope = {
    data: Enumerable<fundDonationsCreateManyFundInput>
    skipDuplicates?: boolean
  }

  export type fundDonationsUpsertWithWhereUniqueWithoutFundInput = {
    where: fundDonationsWhereUniqueInput
    update: XOR<fundDonationsUpdateWithoutFundInput, fundDonationsUncheckedUpdateWithoutFundInput>
    create: XOR<fundDonationsCreateWithoutFundInput, fundDonationsUncheckedCreateWithoutFundInput>
  }

  export type fundDonationsUpdateWithWhereUniqueWithoutFundInput = {
    where: fundDonationsWhereUniqueInput
    data: XOR<fundDonationsUpdateWithoutFundInput, fundDonationsUncheckedUpdateWithoutFundInput>
  }

  export type fundDonationsUpdateManyWithWhereWithoutFundInput = {
    where: fundDonationsScalarWhereInput
    data: XOR<fundDonationsUpdateManyMutationInput, fundDonationsUncheckedUpdateManyWithoutFundDonationsInput>
  }

  export type visitSessionsCreateWithoutSessionInput = {
    id: string
    churchId?: string | null
    visit?: visitsCreateNestedOneWithoutSessionInput
  }

  export type visitSessionsUncheckedCreateWithoutSessionInput = {
    id: string
    churchId?: string | null
    visitId?: string | null
  }

  export type visitSessionsCreateOrConnectWithoutSessionInput = {
    where: visitSessionsWhereUniqueInput
    create: XOR<visitSessionsCreateWithoutSessionInput, visitSessionsUncheckedCreateWithoutSessionInput>
  }

  export type visitSessionsCreateManySessionInputEnvelope = {
    data: Enumerable<visitSessionsCreateManySessionInput>
    skipDuplicates?: boolean
  }

  export type visitSessionsUpsertWithWhereUniqueWithoutSessionInput = {
    where: visitSessionsWhereUniqueInput
    update: XOR<visitSessionsUpdateWithoutSessionInput, visitSessionsUncheckedUpdateWithoutSessionInput>
    create: XOR<visitSessionsCreateWithoutSessionInput, visitSessionsUncheckedCreateWithoutSessionInput>
  }

  export type visitSessionsUpdateWithWhereUniqueWithoutSessionInput = {
    where: visitSessionsWhereUniqueInput
    data: XOR<visitSessionsUpdateWithoutSessionInput, visitSessionsUncheckedUpdateWithoutSessionInput>
  }

  export type visitSessionsUpdateManyWithWhereWithoutSessionInput = {
    where: visitSessionsScalarWhereInput
    data: XOR<visitSessionsUpdateManyMutationInput, visitSessionsUncheckedUpdateManyWithoutVisitsInput>
  }

  export type visitSessionsScalarWhereInput = {
    AND?: Enumerable<visitSessionsScalarWhereInput>
    OR?: Enumerable<visitSessionsScalarWhereInput>
    NOT?: Enumerable<visitSessionsScalarWhereInput>
    id?: StringFilter | string
    churchId?: StringNullableFilter | string | null
    visitId?: StringNullableFilter | string | null
    sessionId?: StringNullableFilter | string | null
  }

  export type visitsCreateWithoutSessionInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    serviceId?: string | null
    groupId?: string | null
    visitDate?: Date | string | null
    checkinTime?: Date | string | null
    addedBy?: string | null
  }

  export type visitsUncheckedCreateWithoutSessionInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    serviceId?: string | null
    groupId?: string | null
    visitDate?: Date | string | null
    checkinTime?: Date | string | null
    addedBy?: string | null
  }

  export type visitsCreateOrConnectWithoutSessionInput = {
    where: visitsWhereUniqueInput
    create: XOR<visitsCreateWithoutSessionInput, visitsUncheckedCreateWithoutSessionInput>
  }

  export type sessionsCreateWithoutVisitsInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
    sessionDate?: Date | string | null
  }

  export type sessionsUncheckedCreateWithoutVisitsInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    serviceTimeId?: string | null
    sessionDate?: Date | string | null
  }

  export type sessionsCreateOrConnectWithoutVisitsInput = {
    where: sessionsWhereUniqueInput
    create: XOR<sessionsCreateWithoutVisitsInput, sessionsUncheckedCreateWithoutVisitsInput>
  }

  export type visitsUpsertWithoutSessionInput = {
    update: XOR<visitsUpdateWithoutSessionInput, visitsUncheckedUpdateWithoutSessionInput>
    create: XOR<visitsCreateWithoutSessionInput, visitsUncheckedCreateWithoutSessionInput>
  }

  export type visitsUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitsUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    visitDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    checkinTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    addedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type sessionsUpsertWithoutVisitsInput = {
    update: XOR<sessionsUpdateWithoutVisitsInput, sessionsUncheckedUpdateWithoutVisitsInput>
    create: XOR<sessionsCreateWithoutVisitsInput, sessionsUncheckedCreateWithoutVisitsInput>
  }

  export type sessionsUpdateWithoutVisitsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type sessionsUncheckedUpdateWithoutVisitsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    serviceTimeId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type visitSessionsCreateWithoutVisitInput = {
    id: string
    churchId?: string | null
    session?: sessionsCreateNestedOneWithoutVisitsInput
  }

  export type visitSessionsUncheckedCreateWithoutVisitInput = {
    id: string
    churchId?: string | null
    sessionId?: string | null
  }

  export type visitSessionsCreateOrConnectWithoutVisitInput = {
    where: visitSessionsWhereUniqueInput
    create: XOR<visitSessionsCreateWithoutVisitInput, visitSessionsUncheckedCreateWithoutVisitInput>
  }

  export type visitSessionsCreateManyVisitInputEnvelope = {
    data: Enumerable<visitSessionsCreateManyVisitInput>
    skipDuplicates?: boolean
  }

  export type visitSessionsUpsertWithWhereUniqueWithoutVisitInput = {
    where: visitSessionsWhereUniqueInput
    update: XOR<visitSessionsUpdateWithoutVisitInput, visitSessionsUncheckedUpdateWithoutVisitInput>
    create: XOR<visitSessionsCreateWithoutVisitInput, visitSessionsUncheckedCreateWithoutVisitInput>
  }

  export type visitSessionsUpdateWithWhereUniqueWithoutVisitInput = {
    where: visitSessionsWhereUniqueInput
    data: XOR<visitSessionsUpdateWithoutVisitInput, visitSessionsUncheckedUpdateWithoutVisitInput>
  }

  export type visitSessionsUpdateManyWithWhereWithoutVisitInput = {
    where: visitSessionsScalarWhereInput
    data: XOR<visitSessionsUpdateManyMutationInput, visitSessionsUncheckedUpdateManyWithoutSessionInput>
  }

  export type groupMembersCreateManyGroupInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersUpdateWithoutGroupInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    person?: peopleUpdateOneWithoutGroupsInput
  }

  export type groupMembersUncheckedUpdateWithoutGroupInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type groupMembersUncheckedUpdateManyWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type peopleCreateManyHouseholdInput = {
    id: string
    churchId?: string | null
    displayName?: string | null
    firstName?: string | null
    middleName?: string | null
    lastName?: string | null
    nickName?: string | null
    prefix?: string | null
    suffix?: string | null
    birthDate?: Date | string | null
    gender?: string | null
    maritalStatus?: string | null
    anniversary?: Date | string | null
    membershipStatus?: string | null
    homePhone?: string | null
    mobilePhone?: string | null
    workPhone?: string | null
    email?: string | null
    address1?: string | null
    address2?: string | null
    city?: string | null
    state?: string | null
    zip?: string | null
    photoUpdated?: Date | string | null
    householdRole?: string | null
    removed?: boolean | null
  }

  export type peopleUpdateWithoutHouseholdInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    groups?: groupMembersUpdateManyWithoutPersonInput
  }

  export type peopleUncheckedUpdateWithoutHouseholdInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
    groups?: groupMembersUncheckedUpdateManyWithoutPersonInput
  }

  export type peopleUncheckedUpdateManyWithoutPeopleInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    displayName?: NullableStringFieldUpdateOperationsInput | string | null
    firstName?: NullableStringFieldUpdateOperationsInput | string | null
    middleName?: NullableStringFieldUpdateOperationsInput | string | null
    lastName?: NullableStringFieldUpdateOperationsInput | string | null
    nickName?: NullableStringFieldUpdateOperationsInput | string | null
    prefix?: NullableStringFieldUpdateOperationsInput | string | null
    suffix?: NullableStringFieldUpdateOperationsInput | string | null
    birthDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    maritalStatus?: NullableStringFieldUpdateOperationsInput | string | null
    anniversary?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    membershipStatus?: NullableStringFieldUpdateOperationsInput | string | null
    homePhone?: NullableStringFieldUpdateOperationsInput | string | null
    mobilePhone?: NullableStringFieldUpdateOperationsInput | string | null
    workPhone?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    address1?: NullableStringFieldUpdateOperationsInput | string | null
    address2?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip?: NullableStringFieldUpdateOperationsInput | string | null
    photoUpdated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    householdRole?: NullableStringFieldUpdateOperationsInput | string | null
    removed?: NullableBoolFieldUpdateOperationsInput | boolean | null
  }

  export type groupMembersCreateManyPersonInput = {
    id: string
    churchId?: string | null
    groupId?: string | null
    joinDate?: Date | string | null
  }

  export type groupMembersUpdateWithoutPersonInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    group?: groupsUpdateOneWithoutUsersInput
  }

  export type groupMembersUncheckedUpdateWithoutPersonInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type groupMembersUncheckedUpdateManyWithoutGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    groupId?: NullableStringFieldUpdateOperationsInput | string | null
    joinDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type donationsCreateManyDonationBatchesInput = {
    id: string
    churchId?: string | null
    personId?: string | null
    donationDate?: Date | string | null
    amount?: number | null
    method?: string | null
    methodDetails?: string | null
    notes?: string | null
  }

  export type donationsUpdateWithoutDonationBatchesInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    fundDonations?: fundDonationsUpdateManyWithoutDonationInput
  }

  export type donationsUncheckedUpdateWithoutDonationBatchesInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    fundDonations?: fundDonationsUncheckedUpdateManyWithoutDonationInput
  }

  export type donationsUncheckedUpdateManyWithoutDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    personId?: NullableStringFieldUpdateOperationsInput | string | null
    donationDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    method?: NullableStringFieldUpdateOperationsInput | string | null
    methodDetails?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type fundDonationsCreateManyDonationInput = {
    id: string
    churchId?: string | null
    fundId?: string | null
    amount?: number | null
  }

  export type fundDonationsUpdateWithoutDonationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    fund?: fundsUpdateOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedUpdateWithoutDonationInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type fundDonationsUncheckedUpdateManyWithoutFundDonationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    fundId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type fundDonationsCreateManyFundInput = {
    id: string
    churchId?: string | null
    donationId?: string | null
    amount?: number | null
  }

  export type fundDonationsUpdateWithoutFundInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
    donation?: donationsUpdateOneWithoutFundDonationsInput
  }

  export type fundDonationsUncheckedUpdateWithoutFundInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    donationId?: NullableStringFieldUpdateOperationsInput | string | null
    amount?: NullableFloatFieldUpdateOperationsInput | number | null
  }

  export type visitSessionsCreateManySessionInput = {
    id: string
    churchId?: string | null
    visitId?: string | null
  }

  export type visitSessionsUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visit?: visitsUpdateOneWithoutSessionInput
  }

  export type visitSessionsUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visitId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitSessionsUncheckedUpdateManyWithoutVisitsInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    visitId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type visitSessionsCreateManyVisitInput = {
    id: string
    churchId?: string | null
    sessionId?: string | null
  }

  export type visitSessionsUpdateWithoutVisitInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    session?: sessionsUpdateOneWithoutVisitsInput
  }

  export type visitSessionsUncheckedUpdateWithoutVisitInput = {
    id?: StringFieldUpdateOperationsInput | string
    churchId?: NullableStringFieldUpdateOperationsInput | string | null
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.DMMF.Document;
}
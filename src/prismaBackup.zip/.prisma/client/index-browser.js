
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal
} = require('@prisma/client/runtime/index-browser')


const Prisma = {}

exports.Prisma = Prisma

/**
 * Prisma Client JS version: 3.8.1
 * Query Engine version: 34df67547cf5598f5a6cd3eb45f14ee70c3fb86f
 */
Prisma.prismaVersion = {
  client: "3.8.1",
  engine: "34df67547cf5598f5a6cd3eb45f14ee70c3fb86f"
}

Prisma.PrismaClientKnownRequestError = () => {
  throw new Error(`PrismaClientKnownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  throw new Error(`PrismaClientUnknownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientRustPanicError = () => {
  throw new Error(`PrismaClientRustPanicError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientInitializationError = () => {
  throw new Error(`PrismaClientInitializationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientValidationError = () => {
  throw new Error(`PrismaClientValidationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  throw new Error(`sqltag is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.empty = () => {
  throw new Error(`empty is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.join = () => {
  throw new Error(`join is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.raw = () => {
  throw new Error(`raw is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.validator = () => (val) => val

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = 'DbNull'
Prisma.JsonNull = 'JsonNull'
Prisma.AnyNull = 'AnyNull'

/**
 * Enums
 */
// Based on
// https://github.com/microsoft/TypeScript/issues/3192#issuecomment-261720275
function makeEnum(x) { return x; }

exports.Prisma.AnswersScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  formSubmissionId: 'formSubmissionId',
  questionId: 'questionId',
  value: 'value'
});

exports.Prisma.FormSubmissionsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  formId: 'formId',
  contentType: 'contentType',
  contentId: 'contentId',
  submissionDate: 'submissionDate',
  submittedBy: 'submittedBy',
  revisionDate: 'revisionDate',
  revisedBy: 'revisedBy'
});

exports.Prisma.FormsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  name: 'name',
  contentType: 'contentType',
  createdTime: 'createdTime',
  modifiedTime: 'modifiedTime',
  removed: 'removed'
});

exports.Prisma.GroupMembersScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  groupId: 'groupId',
  personId: 'personId',
  joinDate: 'joinDate'
});

exports.Prisma.GroupsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  categoryName: 'categoryName',
  name: 'name',
  trackAttendance: 'trackAttendance',
  parentPickup: 'parentPickup',
  removed: 'removed'
});

exports.Prisma.HouseholdsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  name: 'name'
});

exports.Prisma.NotesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  contentType: 'contentType',
  contentId: 'contentId',
  noteType: 'noteType',
  addedBy: 'addedBy',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  contents: 'contents'
});

exports.Prisma.PeopleScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  displayName: 'displayName',
  firstName: 'firstName',
  middleName: 'middleName',
  lastName: 'lastName',
  nickName: 'nickName',
  prefix: 'prefix',
  suffix: 'suffix',
  birthDate: 'birthDate',
  gender: 'gender',
  maritalStatus: 'maritalStatus',
  anniversary: 'anniversary',
  membershipStatus: 'membershipStatus',
  homePhone: 'homePhone',
  mobilePhone: 'mobilePhone',
  workPhone: 'workPhone',
  email: 'email',
  address1: 'address1',
  address2: 'address2',
  city: 'city',
  state: 'state',
  zip: 'zip',
  photoUpdated: 'photoUpdated',
  householdId: 'householdId',
  householdRole: 'householdRole',
  removed: 'removed'
});

exports.Prisma.QuestionsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  formId: 'formId',
  parentId: 'parentId',
  title: 'title',
  description: 'description',
  fieldType: 'fieldType',
  placeholder: 'placeholder',
  sort: 'sort',
  choices: 'choices',
  removed: 'removed'
});

exports.Prisma.CustomersScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  personId: 'personId'
});

exports.Prisma.DonationBatchesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  name: 'name',
  batchDate: 'batchDate'
});

exports.Prisma.DonationsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  batchId: 'batchId',
  personId: 'personId',
  donationDate: 'donationDate',
  amount: 'amount',
  method: 'method',
  methodDetails: 'methodDetails',
  notes: 'notes'
});

exports.Prisma.EventLogsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  customerId: 'customerId',
  provider: 'provider',
  status: 'status',
  eventType: 'eventType',
  message: 'message',
  created: 'created',
  resolved: 'resolved'
});

exports.Prisma.FundDonationsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  donationId: 'donationId',
  fundId: 'fundId',
  amount: 'amount'
});

exports.Prisma.FundsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  name: 'name',
  productId: 'productId',
  removed: 'removed'
});

exports.Prisma.GatewaysScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  provider: 'provider',
  publicKey: 'publicKey',
  privateKey: 'privateKey',
  webhookKey: 'webhookKey',
  productId: 'productId'
});

exports.Prisma.SubscriptionFundsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  subscriptionId: 'subscriptionId',
  fundId: 'fundId',
  amount: 'amount'
});

exports.Prisma.SubscriptionsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  personId: 'personId',
  customerId: 'customerId'
});

exports.Prisma.CampusesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  name: 'name',
  address1: 'address1',
  address2: 'address2',
  city: 'city',
  state: 'state',
  zip: 'zip',
  removed: 'removed'
});

exports.Prisma.GroupServiceTimesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  groupId: 'groupId',
  serviceTimeId: 'serviceTimeId'
});

exports.Prisma.ServiceTimesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  serviceId: 'serviceId',
  name: 'name',
  removed: 'removed'
});

exports.Prisma.ServicesScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  campusId: 'campusId',
  name: 'name',
  removed: 'removed'
});

exports.Prisma.SessionsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  groupId: 'groupId',
  serviceTimeId: 'serviceTimeId',
  sessionDate: 'sessionDate'
});

exports.Prisma.VisitSessionsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  visitId: 'visitId',
  sessionId: 'sessionId'
});

exports.Prisma.VisitsScalarFieldEnum = makeEnum({
  id: 'id',
  churchId: 'churchId',
  personId: 'personId',
  serviceId: 'serviceId',
  groupId: 'groupId',
  visitDate: 'visitDate',
  checkinTime: 'checkinTime',
  addedBy: 'addedBy'
});

exports.Prisma.SortOrder = makeEnum({
  asc: 'asc',
  desc: 'desc'
});


exports.Prisma.ModelName = makeEnum({
  answers: 'answers',
  formSubmissions: 'formSubmissions',
  forms: 'forms',
  groupMembers: 'groupMembers',
  groups: 'groups',
  households: 'households',
  notes: 'notes',
  people: 'people',
  questions: 'questions',
  customers: 'customers',
  donationBatches: 'donationBatches',
  donations: 'donations',
  eventLogs: 'eventLogs',
  fundDonations: 'fundDonations',
  funds: 'funds',
  gateways: 'gateways',
  subscriptionFunds: 'subscriptionFunds',
  subscriptions: 'subscriptions',
  campuses: 'campuses',
  groupServiceTimes: 'groupServiceTimes',
  serviceTimes: 'serviceTimes',
  services: 'services',
  sessions: 'sessions',
  visitSessions: 'visitSessions',
  visits: 'visits'
});

/**
 * Create the Client
 */
class PrismaClient {
  constructor() {
    throw new Error(
      `PrismaClient is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
    )
  }
}
exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
